﻿namespace SMK_MART
{
    partial class FormTransaksi
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            DataGridViewCellStyle dataGridViewCellStyle1 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle2 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle3 = new DataGridViewCellStyle();
            panel1 = new Panel();
            parrotButton3 = new ReaLTaiizor.Controls.ParrotButton();
            parrotButton1 = new ReaLTaiizor.Controls.ParrotButton();
            label1 = new Label();
            tableLayoutPanel1 = new TableLayoutPanel();
            panel2 = new Panel();
            gridKeranjang = new ReaLTaiizor.Controls.PoisonDataGridView();
            colBarang = new DataGridViewTextBoxColumn();
            colJml = new DataGridViewTextBoxColumn();
            colSubtotal = new DataGridViewTextBoxColumn();
            btnTambah = new ReaLTaiizor.Controls.ParrotButton();
            txtJumlah = new ReaLTaiizor.Controls.HopeTextBox();
            hopeTextBox1 = new ReaLTaiizor.Controls.HopeTextBox();
            label5 = new Label();
            label2 = new Label();
            panel5 = new Panel();
            panel3 = new Panel();
            btnBatal = new ReaLTaiizor.Controls.ParrotButton();
            btnBayar = new ReaLTaiizor.Controls.ParrotButton();
            lblKembalian = new Label();
            txtUangBayar = new ReaLTaiizor.Controls.HopeTextBox();
            label6 = new Label();
            lblTotal = new Label();
            label3 = new Label();
            panel6 = new Panel();
            panel4 = new Panel();
            lblStruk = new Label();
            label4 = new Label();
            panel7 = new Panel();
            panel1.SuspendLayout();
            tableLayoutPanel1.SuspendLayout();
            panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)gridKeranjang).BeginInit();
            panel3.SuspendLayout();
            panel4.SuspendLayout();
            SuspendLayout();
            // 
            // panel1
            // 
            panel1.BackColor = Color.Navy;
            panel1.Controls.Add(parrotButton3);
            panel1.Controls.Add(parrotButton1);
            panel1.Controls.Add(label1);
            panel1.Dock = DockStyle.Top;
            panel1.Location = new Point(0, 0);
            panel1.Name = "panel1";
            panel1.Size = new Size(877, 55);
            panel1.TabIndex = 2;
            // 
            // parrotButton3
            // 
            parrotButton3.BackgroundColor = Color.Gold;
            parrotButton3.ButtonImage = null;
            parrotButton3.ButtonStyle = ReaLTaiizor.Controls.ParrotButton.Style.MaterialRounded;
            parrotButton3.ButtonText = "Kembali";
            parrotButton3.ClickBackColor = Color.FromArgb(195, 195, 195);
            parrotButton3.ClickTextColor = Color.DodgerBlue;
            parrotButton3.CornerRadius = 5;
            parrotButton3.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            parrotButton3.Horizontal_Alignment = StringAlignment.Center;
            parrotButton3.HoverBackgroundColor = Color.FromArgb(225, 225, 225);
            parrotButton3.HoverTextColor = Color.DodgerBlue;
            parrotButton3.ImagePosition = ReaLTaiizor.Controls.ParrotButton.ImgPosition.Left;
            parrotButton3.Location = new Point(18, 9);
            parrotButton3.Name = "parrotButton3";
            parrotButton3.Size = new Size(95, 37);
            parrotButton3.SmoothingType = System.Drawing.Drawing2D.SmoothingMode.HighQuality;
            parrotButton3.TabIndex = 4;
            parrotButton3.TextColor = Color.Black;
            parrotButton3.TextRenderingType = System.Drawing.Text.TextRenderingHint.ClearTypeGridFit;
            parrotButton3.Vertical_Alignment = StringAlignment.Center;
            parrotButton3.Click += parrotButton3_Click;
            // 
            // parrotButton1
            // 
            parrotButton1.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            parrotButton1.BackgroundColor = Color.Gold;
            parrotButton1.ButtonImage = null;
            parrotButton1.ButtonStyle = ReaLTaiizor.Controls.ParrotButton.Style.MaterialRounded;
            parrotButton1.ButtonText = "Log out";
            parrotButton1.ClickBackColor = Color.FromArgb(195, 195, 195);
            parrotButton1.ClickTextColor = Color.Black;
            parrotButton1.CornerRadius = 10;
            parrotButton1.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            parrotButton1.Horizontal_Alignment = StringAlignment.Center;
            parrotButton1.HoverBackgroundColor = Color.FromArgb(225, 225, 225);
            parrotButton1.HoverTextColor = Color.DodgerBlue;
            parrotButton1.ImagePosition = ReaLTaiizor.Controls.ParrotButton.ImgPosition.Left;
            parrotButton1.Location = new Point(777, 9);
            parrotButton1.Name = "parrotButton1";
            parrotButton1.Size = new Size(88, 37);
            parrotButton1.SmoothingType = System.Drawing.Drawing2D.SmoothingMode.HighQuality;
            parrotButton1.TabIndex = 3;
            parrotButton1.TextColor = Color.Black;
            parrotButton1.TextRenderingType = System.Drawing.Text.TextRenderingHint.ClearTypeGridFit;
            parrotButton1.Vertical_Alignment = StringAlignment.Center;
            parrotButton1.Click += parrotButton1_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 20.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.ForeColor = Color.Gold;
            label1.Location = new Point(119, 9);
            label1.Name = "label1";
            label1.Size = new Size(161, 37);
            label1.TabIndex = 0;
            label1.Text = "SMK MART";
            // 
            // tableLayoutPanel1
            // 
            tableLayoutPanel1.BackColor = Color.Gainsboro;
            tableLayoutPanel1.ColumnCount = 3;
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 25F));
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 25F));
            tableLayoutPanel1.Controls.Add(panel2, 0, 0);
            tableLayoutPanel1.Controls.Add(panel3, 1, 0);
            tableLayoutPanel1.Controls.Add(panel4, 2, 0);
            tableLayoutPanel1.Dock = DockStyle.Fill;
            tableLayoutPanel1.Location = new Point(0, 55);
            tableLayoutPanel1.Name = "tableLayoutPanel1";
            tableLayoutPanel1.RowCount = 1;
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 100F));
            tableLayoutPanel1.Size = new Size(877, 407);
            tableLayoutPanel1.TabIndex = 3;
            // 
            // panel2
            // 
            panel2.BackColor = Color.White;
            panel2.Controls.Add(gridKeranjang);
            panel2.Controls.Add(btnTambah);
            panel2.Controls.Add(txtJumlah);
            panel2.Controls.Add(hopeTextBox1);
            panel2.Controls.Add(label5);
            panel2.Controls.Add(label2);
            panel2.Controls.Add(panel5);
            panel2.Dock = DockStyle.Fill;
            panel2.Location = new Point(15, 10);
            panel2.Margin = new Padding(15, 10, 15, 10);
            panel2.Name = "panel2";
            panel2.Size = new Size(408, 387);
            panel2.TabIndex = 0;
            // 
            // gridKeranjang
            // 
            gridKeranjang.AllowUserToAddRows = false;
            gridKeranjang.AllowUserToResizeRows = false;
            gridKeranjang.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            gridKeranjang.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            gridKeranjang.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.DisplayedCellsExceptHeaders;
            gridKeranjang.BackgroundColor = Color.FromArgb(255, 255, 255);
            gridKeranjang.BorderStyle = BorderStyle.None;
            gridKeranjang.CellBorderStyle = DataGridViewCellBorderStyle.None;
            gridKeranjang.ColumnHeadersBorderStyle = DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle1.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = Color.Gainsboro;
            dataGridViewCellStyle1.Font = new Font("Segoe UI Semibold", 15.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            dataGridViewCellStyle1.ForeColor = Color.Navy;
            dataGridViewCellStyle1.SelectionBackColor = Color.Gainsboro;
            dataGridViewCellStyle1.SelectionForeColor = Color.Navy;
            dataGridViewCellStyle1.WrapMode = DataGridViewTriState.True;
            gridKeranjang.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            gridKeranjang.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            gridKeranjang.Columns.AddRange(new DataGridViewColumn[] { colBarang, colJml, colSubtotal });
            dataGridViewCellStyle2.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = Color.FromArgb(255, 255, 255);
            dataGridViewCellStyle2.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            dataGridViewCellStyle2.ForeColor = Color.FromArgb(64, 64, 64);
            dataGridViewCellStyle2.SelectionBackColor = Color.DarkGray;
            dataGridViewCellStyle2.SelectionForeColor = Color.FromArgb(64, 64, 64);
            dataGridViewCellStyle2.WrapMode = DataGridViewTriState.False;
            gridKeranjang.DefaultCellStyle = dataGridViewCellStyle2;
            gridKeranjang.EnableHeadersVisualStyles = false;
            gridKeranjang.Font = new Font("Segoe UI", 11F, FontStyle.Regular, GraphicsUnit.Pixel);
            gridKeranjang.GridColor = Color.Silver;
            gridKeranjang.Location = new Point(16, 150);
            gridKeranjang.Name = "gridKeranjang";
            gridKeranjang.ReadOnly = true;
            gridKeranjang.RowHeadersBorderStyle = DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle3.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = Color.FromArgb(0, 174, 219);
            dataGridViewCellStyle3.Font = new Font("Segoe UI", 11F, FontStyle.Regular, GraphicsUnit.Pixel);
            dataGridViewCellStyle3.ForeColor = Color.FromArgb(255, 255, 255);
            dataGridViewCellStyle3.SelectionBackColor = Color.FromArgb(0, 198, 247);
            dataGridViewCellStyle3.SelectionForeColor = Color.FromArgb(17, 17, 17);
            dataGridViewCellStyle3.WrapMode = DataGridViewTriState.True;
            gridKeranjang.RowHeadersDefaultCellStyle = dataGridViewCellStyle3;
            gridKeranjang.RowHeadersVisible = false;
            gridKeranjang.RowHeadersWidthSizeMode = DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            gridKeranjang.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            gridKeranjang.Size = new Size(380, 218);
            gridKeranjang.TabIndex = 6;
            // 
            // colBarang
            // 
            colBarang.FillWeight = 150F;
            colBarang.HeaderText = "Barang";
            colBarang.Name = "colBarang";
            colBarang.ReadOnly = true;
            // 
            // colJml
            // 
            colJml.FillWeight = 50F;
            colJml.HeaderText = "Jml";
            colJml.Name = "colJml";
            colJml.ReadOnly = true;
            // 
            // colSubtotal
            // 
            colSubtotal.HeaderText = "Subtotal";
            colSubtotal.Name = "colSubtotal";
            colSubtotal.ReadOnly = true;
            // 
            // btnTambah
            // 
            btnTambah.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            btnTambah.BackgroundColor = Color.Navy;
            btnTambah.ButtonImage = null;
            btnTambah.ButtonStyle = ReaLTaiizor.Controls.ParrotButton.Style.MaterialRounded;
            btnTambah.ButtonText = "Tambah";
            btnTambah.ClickBackColor = Color.FromArgb(40, 40, 120);
            btnTambah.ClickTextColor = Color.White;
            btnTambah.CornerRadius = 5;
            btnTambah.Font = new Font("Segoe UI", 15.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btnTambah.Horizontal_Alignment = StringAlignment.Center;
            btnTambah.HoverBackgroundColor = Color.FromArgb(60, 60, 140);
            btnTambah.HoverTextColor = Color.White;
            btnTambah.ImagePosition = ReaLTaiizor.Controls.ParrotButton.ImgPosition.Left;
            btnTambah.Location = new Point(312, 92);
            btnTambah.Name = "btnTambah";
            btnTambah.Size = new Size(91, 44);
            btnTambah.SmoothingType = System.Drawing.Drawing2D.SmoothingMode.HighQuality;
            btnTambah.TabIndex = 5;
            btnTambah.TextColor = Color.White;
            btnTambah.TextRenderingType = System.Drawing.Text.TextRenderingHint.ClearTypeGridFit;
            btnTambah.Vertical_Alignment = StringAlignment.Center;
            btnTambah.Click += btnTambah_Click;
            // 
            // txtJumlah
            // 
            txtJumlah.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            txtJumlah.BackColor = Color.White;
            txtJumlah.BaseColor = Color.White;
            txtJumlah.BorderColorA = Color.DarkGray;
            txtJumlah.BorderColorB = Color.DarkGray;
            txtJumlah.Font = new Font("Segoe UI", 15.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txtJumlah.ForeColor = Color.FromArgb(48, 49, 51);
            txtJumlah.Hint = "Jml";
            txtJumlah.Location = new Point(248, 92);
            txtJumlah.MaxLength = 32767;
            txtJumlah.Multiline = false;
            txtJumlah.Name = "txtJumlah";
            txtJumlah.PasswordChar = '\0';
            txtJumlah.ScrollBars = ScrollBars.None;
            txtJumlah.SelectedText = "";
            txtJumlah.SelectionLength = 0;
            txtJumlah.SelectionStart = 0;
            txtJumlah.Size = new Size(58, 44);
            txtJumlah.TabIndex = 4;
            txtJumlah.TabStop = false;
            txtJumlah.Text = "1";
            txtJumlah.UseSystemPasswordChar = false;
            // 
            // hopeTextBox1
            // 
            hopeTextBox1.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            hopeTextBox1.BackColor = Color.White;
            hopeTextBox1.BaseColor = Color.White;
            hopeTextBox1.BorderColorA = Color.DarkGray;
            hopeTextBox1.BorderColorB = Color.DarkGray;
            hopeTextBox1.Font = new Font("Segoe UI", 15.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            hopeTextBox1.ForeColor = Color.FromArgb(48, 49, 51);
            hopeTextBox1.Hint = "Kode atau nama barang";
            hopeTextBox1.Location = new Point(16, 92);
            hopeTextBox1.MaxLength = 32767;
            hopeTextBox1.Multiline = false;
            hopeTextBox1.Name = "hopeTextBox1";
            hopeTextBox1.PasswordChar = '\0';
            hopeTextBox1.ScrollBars = ScrollBars.None;
            hopeTextBox1.SelectedText = "";
            hopeTextBox1.SelectionLength = 0;
            hopeTextBox1.SelectionStart = 0;
            hopeTextBox1.Size = new Size(224, 44);
            hopeTextBox1.TabIndex = 2;
            hopeTextBox1.TabStop = false;
            hopeTextBox1.UseSystemPasswordChar = false;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label5.ForeColor = Color.FromArgb(64, 64, 64);
            label5.Location = new Point(16, 66);
            label5.Name = "label5";
            label5.Size = new Size(117, 21);
            label5.TabIndex = 3;
            label5.Text = "Tambah barang";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI Semibold", 24F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label2.ForeColor = Color.Navy;
            label2.Location = new Point(14, 20);
            label2.Name = "label2";
            label2.Size = new Size(168, 45);
            label2.TabIndex = 1;
            label2.Text = "Keranjang";
            // 
            // panel5
            // 
            panel5.BackColor = Color.Navy;
            panel5.Dock = DockStyle.Top;
            panel5.Location = new Point(0, 0);
            panel5.Name = "panel5";
            panel5.Size = new Size(408, 10);
            panel5.TabIndex = 0;
            // 
            // panel3
            // 
            panel3.BackColor = Color.White;
            panel3.Controls.Add(btnBatal);
            panel3.Controls.Add(btnBayar);
            panel3.Controls.Add(lblKembalian);
            panel3.Controls.Add(txtUangBayar);
            panel3.Controls.Add(label6);
            panel3.Controls.Add(lblTotal);
            panel3.Controls.Add(label3);
            panel3.Controls.Add(panel6);
            panel3.Dock = DockStyle.Fill;
            panel3.Location = new Point(453, 10);
            panel3.Margin = new Padding(15, 10, 15, 10);
            panel3.Name = "panel3";
            panel3.Size = new Size(189, 387);
            panel3.TabIndex = 1;
            // 
            // btnBatal
            // 
            btnBatal.Anchor = AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            btnBatal.BackgroundColor = Color.FromArgb(5, 150, 105);
            btnBatal.ButtonImage = null;
            btnBatal.ButtonStyle = ReaLTaiizor.Controls.ParrotButton.Style.MaterialRounded;
            btnBatal.ButtonText = "Batal";
            btnBatal.ClickBackColor = Color.FromArgb(195, 195, 195);
            btnBatal.ClickTextColor = Color.Gray;
            btnBatal.CornerRadius = 10;
            btnBatal.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btnBatal.Horizontal_Alignment = StringAlignment.Center;
            btnBatal.HoverBackgroundColor = Color.FromArgb(210, 210, 210);
            btnBatal.HoverTextColor = Color.Navy;
            btnBatal.ImagePosition = ReaLTaiizor.Controls.ParrotButton.ImgPosition.Left;
            btnBatal.Location = new Point(13, 323);
            btnBatal.Name = "btnBatal";
            btnBatal.Size = new Size(163, 44);
            btnBatal.SmoothingType = System.Drawing.Drawing2D.SmoothingMode.HighQuality;
            btnBatal.TabIndex = 7;
            btnBatal.TextColor = Color.White;
            btnBatal.TextRenderingType = System.Drawing.Text.TextRenderingHint.ClearTypeGridFit;
            btnBatal.Vertical_Alignment = StringAlignment.Center;
            btnBatal.Click += btnBatal_Click;
            // 
            // btnBayar
            // 
            btnBayar.Anchor = AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            btnBayar.BackgroundColor = Color.FromArgb(255, 128, 0);
            btnBayar.ButtonImage = null;
            btnBayar.ButtonStyle = ReaLTaiizor.Controls.ParrotButton.Style.MaterialRounded;
            btnBayar.ButtonText = "Bayar dan cetak struk";
            btnBayar.ClickBackColor = Color.FromArgb(220, 105, 0);
            btnBayar.ClickTextColor = Color.White;
            btnBayar.CornerRadius = 10;
            btnBayar.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btnBayar.Horizontal_Alignment = StringAlignment.Center;
            btnBayar.HoverBackgroundColor = Color.FromArgb(255, 150, 50);
            btnBayar.HoverTextColor = Color.White;
            btnBayar.ImagePosition = ReaLTaiizor.Controls.ParrotButton.ImgPosition.Left;
            btnBayar.Location = new Point(13, 260);
            btnBayar.Name = "btnBayar";
            btnBayar.Size = new Size(163, 50);
            btnBayar.SmoothingType = System.Drawing.Drawing2D.SmoothingMode.HighQuality;
            btnBayar.TabIndex = 6;
            btnBayar.TextColor = Color.Black;
            btnBayar.TextRenderingType = System.Drawing.Text.TextRenderingHint.ClearTypeGridFit;
            btnBayar.Vertical_Alignment = StringAlignment.Center;
            btnBayar.Click += btnBayar_Click;
            // 
            // lblKembalian
            // 
            lblKembalian.AutoSize = true;
            lblKembalian.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblKembalian.ForeColor = Color.FromArgb(64, 64, 64);
            lblKembalian.Location = new Point(13, 200);
            lblKembalian.Name = "lblKembalian";
            lblKembalian.Size = new Size(118, 21);
            lblKembalian.TabIndex = 5;
            lblKembalian.Text = "Kembalian: Rp0";
            // 
            // txtUangBayar
            // 
            txtUangBayar.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            txtUangBayar.BackColor = Color.White;
            txtUangBayar.BaseColor = Color.White;
            txtUangBayar.BorderColorA = Color.DarkGray;
            txtUangBayar.BorderColorB = Color.DarkGray;
            txtUangBayar.Font = new Font("Segoe UI", 12F);
            txtUangBayar.ForeColor = Color.FromArgb(48, 49, 51);
            txtUangBayar.Hint = "";
            txtUangBayar.Location = new Point(13, 150);
            txtUangBayar.MaxLength = 32767;
            txtUangBayar.Multiline = false;
            txtUangBayar.Name = "txtUangBayar";
            txtUangBayar.PasswordChar = '\0';
            txtUangBayar.ScrollBars = ScrollBars.None;
            txtUangBayar.SelectedText = "";
            txtUangBayar.SelectionLength = 0;
            txtUangBayar.SelectionStart = 0;
            txtUangBayar.Size = new Size(163, 38);
            txtUangBayar.TabIndex = 4;
            txtUangBayar.TabStop = false;
            txtUangBayar.UseSystemPasswordChar = false;
            txtUangBayar.Leave += txtUangBayar_TextChanged;
            txtUangBayar.TextChanged += txtUangBayar_TextChanged;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label6.ForeColor = Color.FromArgb(64, 64, 64);
            label6.Location = new Point(13, 125);
            label6.Name = "label6";
            label6.Size = new Size(90, 21);
            label6.TabIndex = 3;
            label6.Text = "Uang bayar";
            // 
            // lblTotal
            // 
            lblTotal.AutoSize = true;
            lblTotal.Font = new Font("Segoe UI Semibold", 24F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblTotal.ForeColor = Color.FromArgb(5, 150, 105);
            lblTotal.Location = new Point(10, 62);
            lblTotal.Name = "lblTotal";
            lblTotal.Size = new Size(77, 45);
            lblTotal.TabIndex = 2;
            lblTotal.Text = "Rp0";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI Semibold", 21.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label3.ForeColor = Color.FromArgb(5, 150, 105);
            label3.Location = new Point(3, 22);
            label3.Name = "label3";
            label3.Size = new Size(179, 40);
            label3.TabIndex = 1;
            label3.Text = "Pembayaran";
            // 
            // panel6
            // 
            panel6.BackColor = Color.FromArgb(5, 150, 105);
            panel6.Dock = DockStyle.Top;
            panel6.Location = new Point(0, 0);
            panel6.Name = "panel6";
            panel6.Size = new Size(189, 10);
            panel6.TabIndex = 0;
            // 
            // panel4
            // 
            panel4.BackColor = Color.White;
            panel4.Controls.Add(lblStruk);
            panel4.Controls.Add(label4);
            panel4.Controls.Add(panel7);
            panel4.Dock = DockStyle.Fill;
            panel4.Location = new Point(672, 10);
            panel4.Margin = new Padding(15, 10, 15, 10);
            panel4.Name = "panel4";
            panel4.Size = new Size(190, 387);
            panel4.TabIndex = 2;
            // 
            // lblStruk
            // 
            lblStruk.Font = new Font("Consolas", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblStruk.ForeColor = Color.FromArgb(64, 64, 64);
            lblStruk.Location = new Point(13, 66);
            lblStruk.Name = "lblStruk";
            lblStruk.Size = new Size(164, 279);
            lblStruk.TabIndex = 2;
            lblStruk.UseMnemonic = false;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI Semibold", 24F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label4.ForeColor = Color.FromArgb(255, 128, 0);
            label4.Location = new Point(13, 20);
            label4.Name = "label4";
            label4.Size = new Size(96, 45);
            label4.TabIndex = 1;
            label4.Text = "Struk";
            // 
            // panel7
            // 
            panel7.BackColor = Color.FromArgb(255, 128, 0);
            panel7.Dock = DockStyle.Top;
            panel7.Location = new Point(0, 0);
            panel7.Name = "panel7";
            panel7.Size = new Size(190, 10);
            panel7.TabIndex = 0;
            // 
            // FormTransaksi
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(877, 462);
            Controls.Add(tableLayoutPanel1);
            Controls.Add(panel1);
            Name = "FormTransaksi";
            Text = "FormTransaksi";
            WindowState = FormWindowState.Maximized;
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            tableLayoutPanel1.ResumeLayout(false);
            panel2.ResumeLayout(false);
            panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)gridKeranjang).EndInit();
            panel3.ResumeLayout(false);
            panel3.PerformLayout();
            panel4.ResumeLayout(false);
            panel4.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private Panel panel1;
        private ReaLTaiizor.Controls.ParrotButton parrotButton1;
        private ReaLTaiizor.Controls.ParrotButton parrotButton3;
        private Label label1;
        private TableLayoutPanel tableLayoutPanel1;
        private Panel panel2;
        private Panel panel3;
        private Panel panel4;
        private Panel panel5;
        private Panel panel6;
        private Panel panel7;
        private Label label2;
        private Label label3;
        private Label label4;
        private Label label5;
        private Label label6;
        private Label lblTotal;
        private Label lblKembalian;
        private Label lblStruk;
        private ReaLTaiizor.Controls.HopeTextBox hopeTextBox1;
        private ReaLTaiizor.Controls.HopeTextBox txtJumlah;
        private ReaLTaiizor.Controls.HopeTextBox txtUangBayar;
        private ReaLTaiizor.Controls.ParrotButton btnTambah;
        private ReaLTaiizor.Controls.ParrotButton btnBayar;
        private ReaLTaiizor.Controls.ParrotButton btnBatal;
        private ReaLTaiizor.Controls.PoisonDataGridView gridKeranjang;
        private DataGridViewTextBoxColumn colBarang;
        private DataGridViewTextBoxColumn colJml;
        private DataGridViewTextBoxColumn colSubtotal;
    }
}
