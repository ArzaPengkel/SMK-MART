﻿namespace SMK_MART
{
    internal static class Program
    {
        /// <summary>
        ///  The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            // To customize application configuration such as set high DPI settings or default font,
            // see https://aka.ms/applicationconfiguration.
            ApplicationConfiguration.Initialize();
            Application.Run(new KonteksAplikasi(new FormLogin()));
        }
    }

    // Aplikasi berjalan sampai semua form tertutup. Berpindah halaman cukup dengan
    // menampilkan form baru lalu menutup (Close) form lama, tanpa menyembunyikannya.
    internal sealed class KonteksAplikasi : ApplicationContext
    {
        public KonteksAplikasi(Form formAwal)
        {
            formAwal.Show();
            Application.Idle += CekSemuaFormTutup;
        }

        private void CekSemuaFormTutup(object? sender, EventArgs e)
        {
            if (Application.OpenForms.Count == 0)
            {
                Application.Idle -= CekSemuaFormTutup;
                ExitThread();
            }
        }
    }
}
