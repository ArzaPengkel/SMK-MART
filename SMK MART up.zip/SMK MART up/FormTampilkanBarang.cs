﻿namespace SMK_MART
{
    public partial class FormTampilkanBarang : Form
    {
        // ==========================================
        // DATA & FILE (tanpa DataStore)
        // ==========================================
        private class BarangData
        {
            public string Kode = "";
            public string Nama = "";
            public int Harga;
            public int Stok;
            public string Status = "aktif";
            public bool Aktif => Status == "aktif";
        }

        private readonly string folder = Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.UserProfile),
            @"Downloads\Ngoding\Pyhton SMK MART");

        private string FileBarang => Path.Combine(folder, "barang.txt");

        private FileSystemWatcher? pemantauFile;
        private System.Windows.Forms.Timer? timerMuatUlang;   // menggabungkan beberapa kejadian file menjadi satu kali muat

        // Kondisi barang.txt saat terakhir dibaca (waktu ubah + ukuran), untuk mengenali perubahan dari luar
        private string tandaFileTerakhir = "";

        // Pengaturan tampilan terakhir (dipertahankan saat file barang.txt berubah)
        private string kataCari = "";
        private string? kunciUrut = null;   // "stok", "harga", atau "nama"
        private bool urutTurun = false;

        public FormTampilkanBarang()
        {
            InitializeComponent();



            cyberTextBox1.ForeColor = Color.Black;
            cyberTextBox1.TextButton = "";

            parrotButton4.Click += parrotButton4_Click;
            Load += FormTampilkanBarang_Load;

            AktifkanDoubleBuffer(poisonDataGridView2);

            // Pemantau file selalu dimatikan saat form ditutup, apa pun caranya
            FormClosed += (s, e) => HentikanPemantauFile();
        }

        // ==========================================
        // BANTUAN TABEL (supaya cepat)
        // ==========================================
        // Menggambar tabel lewat buffer ganda: scroll dan muat ulang lebih halus
        private static void AktifkanDoubleBuffer(DataGridView tabel)
        {
            typeof(DataGridView).GetProperty("DoubleBuffered",
                System.Reflection.BindingFlags.Instance | System.Reflection.BindingFlags.NonPublic)
                ?.SetValue(tabel, true);
        }

        private static DataGridViewRow BuatBaris(DataGridView tabel, params object[] nilai)
        {
            var baris = new DataGridViewRow();
            baris.CreateCells(tabel, nilai);
            return baris;
        }

        // Mengisi tabel sekaligus: jauh lebih cepat daripada Rows.Add satu per satu
        private static void IsiTabel(DataGridView tabel, List<DataGridViewRow> isi)
        {
            tabel.SuspendLayout();
            tabel.Rows.Clear();
            tabel.Rows.AddRange(isi.ToArray());
            tabel.ResumeLayout();
        }

        private string TandaFile()
        {
            try
            {
                var info = new FileInfo(FileBarang);
                return info.Exists ? info.LastWriteTimeUtc.Ticks + ":" + info.Length : "";
            }
            catch (IOException) { return ""; }
        }

        // Baca barang.txt (format: kode|nama|harga_beli|harga_jual|stok|status)
        private List<BarangData> BacaBarang()
        {
            var hasil = new List<BarangData>();
            if (!File.Exists(FileBarang)) return hasil;

            try
            {
                using var fs = new FileStream(FileBarang, FileMode.Open, FileAccess.Read, FileShare.ReadWrite);
                using var sr = new StreamReader(fs);
                string? baris;
                while ((baris = sr.ReadLine()) != null)
                {
                    string[] d = baris.Trim().Split('|');
                    if (TryBacaBarang(d, out string kode, out string nama, out _, out int harga, out int stok, out string status))
                        hasil.Add(new BarangData { Kode = kode, Nama = nama, Harga = harga, Stok = stok, Status = status });
                }
            }
            catch (IOException) { }

            return hasil;
        }

        // Format barang.txt (hanya satu format): kode|nama|harga_beli|harga_jual|stok|status
        private static bool TryBacaBarang(string[] d, out string kode, out string nama,
            out int hargaBeli, out int harga, out int stok, out string status)
        {
            kode = nama = status = "";
            hargaBeli = harga = stok = 0;

            if (d.Length != 6) return false;

            kode = d[0];
            nama = d[1];
            status = d[5];

            return int.TryParse(d[2], out hargaBeli)
                && int.TryParse(d[3], out harga)
                && int.TryParse(d[4], out stok)
                && AdalahStatus(status);
        }

        private static bool AdalahStatus(string teks) => teks == "aktif" || teks == "nonaktif";

        private void FormTampilkanBarang_Load(object? sender, EventArgs e)
        {
            // 1. Memuat data awal dari file .txt ke tabel
            MuatDataDariTxt();

            // 2. Mengaktifkan pemantau file otomatis (jika Python mengedit file .txt)
            MulaiPemantauFile();
        }

        // Tampilkan barang aktif, lalu terapkan pencarian dan pengurutan (jika ada)
        private int MuatDataDariTxt()
        {
            tandaFileTerakhir = TandaFile();   // dicatat sebelum membaca
            List<BarangData> data = BacaBarang().Where(b => b.Aktif).ToList();

            // Cari berdasarkan kode atau nama (sebagian kata, tanpa membedakan huruf besar/kecil)
            if (kataCari != "")
            {
                data = data.Where(b => b.Kode.ToLower().Contains(kataCari) ||
                                       b.Nama.ToLower().Contains(kataCari)).ToList();
            }

            // Quick sort seperti di Python
            if (kunciUrut != null)
            {
                data = QuickSort(data, kunciUrut);
                if (urutTurun) data.Reverse();
            }

            var isi = new List<DataGridViewRow>(data.Count);
            foreach (BarangData b in data)
            {
                string harga = "Rp" + b.Harga.ToString("N0");
                isi.Add(BuatBaris(poisonDataGridView2, b.Kode, b.Nama, harga, b.Stok.ToString()));
            }
            IsiTabel(poisonDataGridView2, isi);

            return data.Count;
        }

        // ==========================================
        // QUICK SORT (sama dengan quick_sort di Python)
        // ==========================================
        private static int Bandingkan(BarangData a, BarangData b, string kunci)
        {
            if (kunci == "nama")
                return string.CompareOrdinal(a.Nama.ToLower(), b.Nama.ToLower());
            if (kunci == "harga")
                return a.Harga.CompareTo(b.Harga);
            return a.Stok.CompareTo(b.Stok);
        }

        private static List<BarangData> QuickSort(List<BarangData> data, string kunci)
        {
            if (data.Count <= 1) return data;

            BarangData pivot = data[0];
            List<BarangData> kiri = new();
            List<BarangData> kanan = new();

            foreach (BarangData barang in data.Skip(1))
            {
                if (Bandingkan(barang, pivot, kunci) <= 0)
                    kiri.Add(barang);
                else
                    kanan.Add(barang);
            }

            List<BarangData> hasil = QuickSort(kiri, kunci);
            hasil.Add(pivot);
            hasil.AddRange(QuickSort(kanan, kunci));
            return hasil;
        }

        // Tombol "Terapkan": baca isian cari, urutkan, dan arah
        private void parrotButton4_Click(object? sender, EventArgs e)
        {
            kataCari = cyberTextBox1.TextButton.Trim().ToLower();

            int jumlah = MuatDataDariTxt();

            if (jumlah == 0 && kataCari != "")
            {
                MessageBox.Show("Barang yang dicari tidak ditemukan.", "Informasi",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        // ==========================================
        // PEMANTAU FILE
        // ==========================================
        private void MulaiPemantauFile()
        {
            if (!Directory.Exists(folder) || pemantauFile != null) return;

            // Beberapa kejadian "Changed" digabung jadi satu kali muat ulang, dan hanya jika file benar-benar berubah
            timerMuatUlang = new System.Windows.Forms.Timer { Interval = 300 };
            timerMuatUlang.Tick += (s, ev) =>
            {
                timerMuatUlang?.Stop();
                if (TandaFile() != tandaFileTerakhir) MuatDataDariTxt();
            };

            pemantauFile = new FileSystemWatcher(folder, "barang.txt");
            pemantauFile.NotifyFilter = NotifyFilters.LastWrite | NotifyFilters.Size;
            pemantauFile.Changed += (s, ev) =>
            {
                try
                {
                    if (IsHandleCreated && !IsDisposed)
                        BeginInvoke((MethodInvoker)(() =>
                        {
                            timerMuatUlang?.Stop();
                            timerMuatUlang?.Start();
                        }));
                }
                catch (InvalidOperationException) { }   // form sedang ditutup
            };
            pemantauFile.EnableRaisingEvents = true;
        }

        private void HentikanPemantauFile()
        {
            if (pemantauFile != null)
            {
                pemantauFile.EnableRaisingEvents = false;
                pemantauFile.Dispose();
                pemantauFile = null;
            }

            if (timerMuatUlang != null)
            {
                timerMuatUlang.Stop();
                timerMuatUlang.Dispose();
                timerMuatUlang = null;
            }
        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void parrotButton2_Click(object sender, EventArgs e)
        {
            DialogResult konfirmasi = MessageBox.Show(
                "Apakah Anda yakin ingin Log out dari akun ini?",
                "Konfirmasi Log Out",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Question
            );

            if (konfirmasi == DialogResult.Yes)
            {
                HentikanPemantauFile();

                FormLogin halamanLogin = new FormLogin();
                halamanLogin.Show();
                this.Close();
            }
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void poisonDataGridView2_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void parrotButton3_Click(object sender, EventArgs e)
        {
            HentikanPemantauFile();

            FormMenuAdmin halamanMenu = new FormMenuAdmin();
            halamanMenu.Show();
            this.Close();
        }

        private void cyberTextBox1_Load(object sender, EventArgs e)
        {

        }

        private void tableLayoutPanel2_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
