﻿namespace SMK_MART
{
    public partial class FormDaftarUser : Form
    {
        // ==========================================
        // DATA & FILE (tanpa DataStore)
        // ==========================================
        private class UserData
        {
            public string Id = "";
            public string Nama = "";
            public string Password = "";
            public string Posisi = "";
            public string Status = "aktif";
            public bool Aktif => Status == "aktif";
            public bool AdminAktif => Aktif && Posisi.ToLower() == "admin";
        }

        private readonly string folder = Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.UserProfile),
            @"Downloads\Ngoding\Pyhton SMK MART");

        private string FileUsers => Path.Combine(folder, "users.txt");

        // ID yang sedang ditampilkan di kolom "ID User" (kolom ini tidak bisa diketik manual)
        private string idTampil = "";

        // ID user yang sedang diedit; null berarti sedang mode "Tambah"
        private string? idDiedit = null;

        public FormDaftarUser()
        {
            InitializeComponent();

            parrotButton1.Click += LogOut_Click;
            parrotButton2.Click += LogOut_Click;
            parrotButton3.Click += Kembali_Click;

            // Tombol "Tambah" / "Simpan"
            parrotButton4.Click += parrotButton4_Click;
            btnStatusUser.Click += btnStatusUser_Click;
            btnBatalEdit.Click += (s, e) => KeluarModeEdit();

            // Klik baris tabel -> edit user tersebut
            poisonDataGridView2.ReadOnly = true;
            poisonDataGridView2.CellClick += poisonDataGridView2_CellClick;
            AktifkanDoubleBuffer(poisonDataGridView2);

            // ID User dibuat otomatis: isian tidak boleh diubah dengan mengetik
            hopeTextBox1.TextChanged += (s, e) =>
            {
                if (hopeTextBox1.Text != idTampil) hopeTextBox1.Text = idTampil;
            };

            Load += (s, e) =>
            {
                MuatUser();
                TampilkanIdBaru();
            };
        }

        // ==========================================
        // FILE users.txt (id|nama|password|posisi|status)
        // Format lama tanpa kolom status tetap terbaca (dianggap aktif).
        // ==========================================
        private List<UserData> BacaUsers()
        {
            var hasil = new List<UserData>();
            if (!File.Exists(FileUsers)) return hasil;

            try
            {
                using var fs = new FileStream(FileUsers, FileMode.Open, FileAccess.Read, FileShare.ReadWrite);
                using var sr = new StreamReader(fs);
                string? baris;
                while ((baris = sr.ReadLine()) != null)
                {
                    string[] d = baris.Trim().Split('|');
                    if (d.Length == 4 || d.Length == 5)
                        hasil.Add(new UserData
                        {
                            Id = d[0],
                            Nama = d[1],
                            Password = d[2],
                            Posisi = d[3],
                            Status = d.Length == 5 ? d[4] : "aktif"
                        });
                }
            }
            catch (IOException) { }

            return hasil;
        }

        private void SimpanUsers(List<UserData> daftar)
        {
            Directory.CreateDirectory(folder);
            File.WriteAllLines(FileUsers,
                daftar.Select(u => $"{u.Id}|{u.Nama}|{u.Password}|{u.Posisi}|{u.Status}"));
        }

        private static string Bersihkan(string teks) => teks.Replace("|", "/").Trim();

        // ID user: 6 digit angka acak (100000 - 999999) yang belum dipakai
        private static string BuatIdUser(List<UserData> daftar)
        {
            while (true)
            {
                string idBaru = Random.Shared.Next(100000, 1000000).ToString();
                if (!daftar.Any(u => u.Id == idBaru)) return idBaru;
            }
        }

        private void SetIdTampil(string id)
        {
            idTampil = id;
            hopeTextBox1.Text = id;
        }

        private void TampilkanIdBaru() => SetIdTampil(BuatIdUser(BacaUsers()));

        // ==========================================
        // POSISI (RadioButton)
        // ==========================================
        // Posisi yang dipilih: "admin" / "kasir" / "gudang", atau "" jika belum dipilih
        private string PosisiDipilih()
        {
            if (radioAdmin.Checked) return "admin";
            if (radioKasir.Checked) return "kasir";
            if (radioGudang.Checked) return "gudang";
            return "";
        }

        private void PilihPosisi(string posisi)
        {
            radioAdmin.Checked = posisi.ToLower() == "admin";
            radioKasir.Checked = posisi.ToLower() == "kasir";
            radioGudang.Checked = posisi.ToLower() == "gudang";
        }

        private void KosongkanPosisi() => PilihPosisi("");

        // ==========================================
        // TAMPILAN
        // ==========================================
        private void MuatUser()
        {
            var isi = new List<DataGridViewRow>();

            foreach (UserData u in BacaUsers())
            {
                // Password disamarkan
                DataGridViewRow baris = BuatBaris(poisonDataGridView2, u.Id, u.Nama, "********", u.Posisi, u.Status);
                if (!u.Aktif)
                    baris.DefaultCellStyle.ForeColor = Color.Gray;
                isi.Add(baris);
            }

            IsiTabel(poisonDataGridView2, isi);
        }

        // ==========================================
        // BANTUAN TABEL (supaya cepat)
        // ==========================================
        // Menggambar tabel lewat buffer ganda: scroll dan muat ulang lebih halus
        private static void AktifkanDoubleBuffer(DataGridView tabel)
        {
            typeof(DataGridView).GetProperty("DoubleBuffered",
                System.Reflection.BindingFlags.Instance | System.Reflection.BindingFlags.NonPublic)
                ?.SetValue(tabel, true);
        }

        private static DataGridViewRow BuatBaris(DataGridView tabel, params object[] nilai)
        {
            var baris = new DataGridViewRow();
            baris.CreateCells(tabel, nilai);
            return baris;
        }

        // Mengisi tabel sekaligus: jauh lebih cepat daripada Rows.Add satu per satu
        private static void IsiTabel(DataGridView tabel, List<DataGridViewRow> isi)
        {
            int posisiGulir = tabel.FirstDisplayedScrollingRowIndex;   // -1 jika tabel kosong

            tabel.SuspendLayout();
            tabel.Rows.Clear();
            tabel.Rows.AddRange(isi.ToArray());
            tabel.ResumeLayout();

            // Tetap di posisi gulir yang sama, tidak loncat ke atas setelah diubah
            if (posisiGulir > 0 && posisiGulir < tabel.Rows.Count)
            {
                try { tabel.FirstDisplayedScrollingRowIndex = posisiGulir; }
                catch (InvalidOperationException) { }
            }
        }

        private void Peringatan(string pesan) =>
            MessageBox.Show(pesan, "Peringatan", MessageBoxButtons.OK, MessageBoxIcon.Warning);

        // Validasi password: minimal 8 karakter dan ada angka. Mengembalikan pesan error atau null.
        private static string? ValidasiPassword(string password)
        {
            if (password.Length < 8) return "Password minimal 8 karakter.";
            if (!password.Any(char.IsDigit)) return "Password harus mengandung minimal 1 angka.";
            return null;
        }

        // ==========================================
        // MODE TAMBAH / MODE EDIT
        // ==========================================
        private void poisonDataGridView2_CellClick(object? sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0) return;

            string id = poisonDataGridView2.Rows[e.RowIndex].Cells[0].Value?.ToString() ?? "";
            UserData? user = BacaUsers().FirstOrDefault(u => u.Id == id);
            if (user != null) MasukModeEdit(user);
        }

        private void MasukModeEdit(UserData user)
        {
            idDiedit = user.Id;
            SetIdTampil(user.Id);

            hopeTextBox2.Text = user.Nama;
            hopeTextBox3.Clear();
            hopeTextBox3.Hint = "Kosongkan jika tidak diganti";
            PilihPosisi(user.Posisi);

            label2.Text = "Edit User";
            parrotButton4.ButtonText = "Simpan";
            btnStatusUser.ButtonText = user.Aktif ? "Nonaktifkan" : "Aktifkan";
            btnStatusUser.Visible = true;
            btnBatalEdit.Visible = true;
        }

        private void KeluarModeEdit()
        {
            idDiedit = null;

            hopeTextBox2.Clear();
            hopeTextBox3.Clear();
            hopeTextBox3.Hint = "";
            KosongkanPosisi();

            label2.Text = "Tambah User";
            parrotButton4.ButtonText = "Tambah";
            btnStatusUser.Visible = false;
            btnBatalEdit.Visible = false;

            poisonDataGridView2.ClearSelection();
            TampilkanIdBaru();
        }

        // Tombol utama: "Tambah" (mode tambah) atau "Simpan" (mode edit)
        private void parrotButton4_Click(object? sender, EventArgs e)
        {
            if (idDiedit == null)
                TambahUser();
            else
                SimpanPerubahanUser();
        }

        // ==========================================
        // TAMBAH USER
        // ==========================================
        private void TambahUser()
        {
            string nama = Bersihkan(hopeTextBox2.Text);
            if (nama == "")
            {
                Peringatan("Nama User tidak boleh kosong.");
                return;
            }

            string password = Bersihkan(hopeTextBox3.Text);
            string? errorPassword = ValidasiPassword(password);
            if (errorPassword != null)
            {
                Peringatan(errorPassword);
                return;
            }

            string posisi = PosisiDipilih();
            if (posisi == "")
            {
                Peringatan("Posisi harus Admin, Kasir, atau Gudang.");
                return;
            }

            List<UserData> daftar = BacaUsers();

            // Pakai ID yang ditampilkan; jika sudah terpakai (berubah dari luar) buat yang baru
            string idBaru = (idTampil != "" && !daftar.Any(u => u.Id == idTampil)) ? idTampil : BuatIdUser(daftar);

            daftar.Add(new UserData { Id = idBaru, Nama = nama, Password = password, Posisi = posisi, Status = "aktif" });

            try
            {
                SimpanUsers(daftar);
            }
            catch (IOException ex)
            {
                Peringatan("Gagal menyimpan data: " + ex.Message);
                return;
            }

            hopeTextBox2.Clear();
            hopeTextBox3.Clear();
            KosongkanPosisi();
            MuatUser();
            TampilkanIdBaru();   // siapkan ID acak berikutnya

            MessageBox.Show($"Pendaftaran berhasil!\nID User: {idBaru}\nID User ini dipakai untuk login",
                "Sukses", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        // ==========================================
        // EDIT USER
        // ==========================================
        private void SimpanPerubahanUser()
        {
            string nama = Bersihkan(hopeTextBox2.Text);
            if (nama == "")
            {
                Peringatan("Nama User tidak boleh kosong.");
                return;
            }

            // Password boleh kosong (artinya tidak diganti)
            string passwordBaru = Bersihkan(hopeTextBox3.Text);
            if (passwordBaru != "")
            {
                string? errorPassword = ValidasiPassword(passwordBaru);
                if (errorPassword != null)
                {
                    Peringatan(errorPassword);
                    return;
                }
            }

            string posisi = PosisiDipilih();
            if (posisi == "")
            {
                Peringatan("Posisi harus Admin, Kasir, atau Gudang.");
                return;
            }

            List<UserData> daftar = BacaUsers();
            UserData? user = daftar.FirstOrDefault(u => u.Id == idDiedit);
            if (user == null)
            {
                Peringatan("User tidak ditemukan.");
                KeluarModeEdit();
                MuatUser();
                return;
            }

            // Jangan sampai tidak ada admin aktif sama sekali
            bool masihAdmin = user.Aktif && posisi == "admin";
            if (user.AdminAktif && !masihAdmin && !daftar.Any(u => u != user && u.AdminAktif))
            {
                Peringatan("Tidak bisa mengubah posisi admin aktif terakhir.");
                return;
            }

            user.Nama = nama;
            user.Posisi = posisi;
            if (passwordBaru != "") user.Password = passwordBaru;

            try
            {
                SimpanUsers(daftar);
            }
            catch (IOException ex)
            {
                Peringatan("Gagal menyimpan data: " + ex.Message);
                return;
            }

            string id = user.Id;
            KeluarModeEdit();
            MuatUser();

            MessageBox.Show($"Data user {id} berhasil diperbarui.", "Sukses",
                MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        // ==========================================
        // AKTIFKAN / NONAKTIFKAN USER
        // ==========================================
        private void btnStatusUser_Click(object? sender, EventArgs e)
        {
            if (idDiedit == null) return;

            List<UserData> daftar = BacaUsers();
            UserData? user = daftar.FirstOrDefault(u => u.Id == idDiedit);
            if (user == null)
            {
                Peringatan("User tidak ditemukan.");
                KeluarModeEdit();
                MuatUser();
                return;
            }

            bool akanNonaktif = user.Aktif;

            if (akanNonaktif && user.AdminAktif && !daftar.Any(u => u != user && u.AdminAktif))
            {
                Peringatan("Tidak bisa menonaktifkan admin aktif terakhir.");
                return;
            }

            DialogResult konfirmasi = MessageBox.Show(
                akanNonaktif
                    ? $"Nonaktifkan user {user.Nama} ({user.Id})?\nUser ini tidak akan bisa login."
                    : $"Aktifkan kembali user {user.Nama} ({user.Id})?",
                "Konfirmasi",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Question);

            if (konfirmasi != DialogResult.Yes) return;

            user.Status = akanNonaktif ? "nonaktif" : "aktif";

            try
            {
                SimpanUsers(daftar);
            }
            catch (IOException ex)
            {
                Peringatan("Gagal menyimpan data: " + ex.Message);
                return;
            }

            KeluarModeEdit();
            MuatUser();
        }

        // ==========================================
        // NAVIGASI
        // ==========================================
        private void Kembali_Click(object? sender, EventArgs e)
        {
            FormMenuAdmin halamanMenu = new FormMenuAdmin();
            halamanMenu.Show();
            this.Close();
        }

        private void LogOut_Click(object? sender, EventArgs e)
        {
            DialogResult konfirmasi = MessageBox.Show(
                "Apakah Anda yakin ingin Log out dari akun ini?",
                "Konfirmasi Log Out",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Question
            );

            if (konfirmasi == DialogResult.Yes)
            {
                FormLogin halamanLogin = new FormLogin();
                halamanLogin.Show();
                this.Close();
            }
        }

        private void poisonDataGridView2_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void FormDaftarUser_Load(object sender, EventArgs e)
        {

        }

        private void parrotButton5_Click(object sender, EventArgs e)
        {
            FormLogin halamanLogin = new FormLogin();
            halamanLogin.Show();
            this.Close();
        }

        private void btnStatusUser_Click_1(object sender, EventArgs e)
        {

        }
    }
}
