﻿namespace SMK_MART
{
    partial class FormKelolaBarang
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            DataGridViewCellStyle dataGridViewCellStyle1 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle2 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle3 = new DataGridViewCellStyle();
            tableLayoutPanel1 = new TableLayoutPanel();
            panel1 = new Panel();
            poisonDataGridView1 = new ReaLTaiizor.Controls.PoisonDataGridView();
            Column1 = new DataGridViewTextBoxColumn();
            Column2 = new DataGridViewTextBoxColumn();
            Column8 = new DataGridViewTextBoxColumn();
            Column7 = new DataGridViewTextBoxColumn();
            Column4 = new DataGridViewTextBoxColumn();
            Column5 = new DataGridViewTextBoxColumn();
            Column6 = new DataGridViewTextBoxColumn();
            panel4 = new Panel();
            label1 = new Label();
            panel2 = new Panel();
            label8 = new Label();
            TextStok = new ReaLTaiizor.Controls.HopeTextBox();
            panel5 = new Panel();
            btnBatalEdit = new ReaLTaiizor.Controls.ParrotButton();
            parrotButton2 = new ReaLTaiizor.Controls.ParrotButton();
            TextHargaJual = new ReaLTaiizor.Controls.HopeTextBox();
            TextHargaBeli = new ReaLTaiizor.Controls.HopeTextBox();
            label7 = new Label();
            label6 = new Label();
            TextBarang = new ReaLTaiizor.Controls.HopeTextBox();
            label5 = new Label();
            label4 = new Label();
            label2 = new Label();
            panel3 = new Panel();
            parrotButton3 = new ReaLTaiizor.Controls.ParrotButton();
            parrotButton1 = new ReaLTaiizor.Controls.ParrotButton();
            label3 = new Label();
            tableLayoutPanel1.SuspendLayout();
            panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)poisonDataGridView1).BeginInit();
            panel2.SuspendLayout();
            panel3.SuspendLayout();
            SuspendLayout();
            // 
            // tableLayoutPanel1
            // 
            tableLayoutPanel1.BackColor = Color.Gainsboro;
            tableLayoutPanel1.ColumnCount = 2;
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 64.75316F));
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 35.24684F));
            tableLayoutPanel1.Controls.Add(panel1, 0, 0);
            tableLayoutPanel1.Controls.Add(panel2, 1, 0);
            tableLayoutPanel1.Dock = DockStyle.Fill;
            tableLayoutPanel1.Location = new Point(0, 55);
            tableLayoutPanel1.Name = "tableLayoutPanel1";
            tableLayoutPanel1.RowCount = 1;
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 100F));
            tableLayoutPanel1.Size = new Size(871, 481);
            tableLayoutPanel1.TabIndex = 0;
            // 
            // panel1
            // 
            panel1.BackColor = Color.White;
            panel1.Controls.Add(poisonDataGridView1);
            panel1.Controls.Add(panel4);
            panel1.Controls.Add(label1);
            panel1.Dock = DockStyle.Fill;
            panel1.Location = new Point(20, 20);
            panel1.Margin = new Padding(20);
            panel1.Name = "panel1";
            panel1.Padding = new Padding(20, 20, 10, 20);
            panel1.Size = new Size(524, 441);
            panel1.TabIndex = 0;
            // 
            // poisonDataGridView1
            // 
            poisonDataGridView1.AllowUserToAddRows = false;
            poisonDataGridView1.AllowUserToResizeRows = false;
            poisonDataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            poisonDataGridView1.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.DisplayedCellsExceptHeaders;
            poisonDataGridView1.BackgroundColor = Color.FromArgb(255, 255, 255);
            poisonDataGridView1.BorderStyle = BorderStyle.None;
            poisonDataGridView1.CellBorderStyle = DataGridViewCellBorderStyle.None;
            poisonDataGridView1.ColumnHeadersBorderStyle = DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle1.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = Color.Gainsboro;
            dataGridViewCellStyle1.Font = new Font("Segoe UI Semibold", 13F, FontStyle.Bold, GraphicsUnit.Point, 0);
            dataGridViewCellStyle1.ForeColor = Color.Navy;
            dataGridViewCellStyle1.SelectionBackColor = Color.Gainsboro;
            dataGridViewCellStyle1.SelectionForeColor = Color.Navy;
            dataGridViewCellStyle1.WrapMode = DataGridViewTriState.True;
            poisonDataGridView1.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            poisonDataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            poisonDataGridView1.Columns.AddRange(new DataGridViewColumn[] { Column1, Column2, Column8, Column7, Column4, Column5, Column6 });
            dataGridViewCellStyle2.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = Color.FromArgb(255, 255, 255);
            dataGridViewCellStyle2.Font = new Font("Segoe UI", 13F, FontStyle.Regular, GraphicsUnit.Point, 0);
            dataGridViewCellStyle2.ForeColor = Color.FromArgb(64, 64, 64);
            dataGridViewCellStyle2.SelectionBackColor = Color.DarkGray;
            dataGridViewCellStyle2.SelectionForeColor = Color.FromArgb(64, 64, 64);
            dataGridViewCellStyle2.WrapMode = DataGridViewTriState.False;
            poisonDataGridView1.DefaultCellStyle = dataGridViewCellStyle2;
            poisonDataGridView1.Dock = DockStyle.Fill;
            poisonDataGridView1.EnableHeadersVisualStyles = false;
            poisonDataGridView1.Font = new Font("Segoe UI", 11F, FontStyle.Regular, GraphicsUnit.Pixel);
            poisonDataGridView1.GridColor = Color.Silver;
            poisonDataGridView1.Location = new Point(20, 65);
            poisonDataGridView1.Name = "poisonDataGridView1";
            poisonDataGridView1.RowHeadersBorderStyle = DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle3.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = Color.FromArgb(0, 174, 219);
            dataGridViewCellStyle3.Font = new Font("Segoe UI", 11F, FontStyle.Regular, GraphicsUnit.Pixel);
            dataGridViewCellStyle3.ForeColor = Color.FromArgb(255, 255, 255);
            dataGridViewCellStyle3.SelectionBackColor = Color.FromArgb(0, 198, 247);
            dataGridViewCellStyle3.SelectionForeColor = Color.FromArgb(17, 17, 17);
            dataGridViewCellStyle3.WrapMode = DataGridViewTriState.True;
            poisonDataGridView1.RowHeadersDefaultCellStyle = dataGridViewCellStyle3;
            poisonDataGridView1.RowHeadersVisible = false;
            poisonDataGridView1.RowHeadersWidthSizeMode = DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            poisonDataGridView1.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            poisonDataGridView1.Size = new Size(494, 356);
            poisonDataGridView1.TabIndex = 1;
            poisonDataGridView1.CellContentClick += poisonDataGridView1_CellContentClick;
            // 
            // Column1
            // 
            Column1.FillWeight = 70F;
            Column1.HeaderText = "Kode";
            Column1.MinimumWidth = 70;
            Column1.Name = "Column1";
            Column1.SortMode = DataGridViewColumnSortMode.NotSortable;
            // 
            // Column2
            // 
            Column2.FillWeight = 150F;
            Column2.HeaderText = "Nama";
            Column2.MinimumWidth = 120;
            Column2.Name = "Column2";
            Column2.SortMode = DataGridViewColumnSortMode.NotSortable;
            // 
            // Column8
            // 
            Column8.HeaderText = "H.Beli";
            Column8.MinimumWidth = 90;
            Column8.Name = "Column8";
            // 
            // Column7
            // 
            Column7.HeaderText = "H.Jual";
            Column7.MinimumWidth = 90;
            Column7.Name = "Column7";
            // 
            // Column4
            // 
            Column4.FillWeight = 70F;
            Column4.HeaderText = "Stok";
            Column4.MinimumWidth = 70;
            Column4.Name = "Column4";
            Column4.SortMode = DataGridViewColumnSortMode.NotSortable;
            // 
            // Column5
            // 
            Column5.HeaderText = "Status";
            Column5.MinimumWidth = 90;
            Column5.Name = "Column5";
            Column5.SortMode = DataGridViewColumnSortMode.NotSortable;
            // 
            // Column6
            // 
            Column6.FillWeight = 120F;
            Column6.HeaderText = "Aksi";
            Column6.MinimumWidth = 120;
            Column6.Name = "Column6";
            Column6.SortMode = DataGridViewColumnSortMode.NotSortable;
            // 
            // panel4
            // 
            panel4.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            panel4.BackColor = Color.Navy;
            panel4.Location = new Point(0, 0);
            panel4.Name = "panel4";
            panel4.Size = new Size(524, 10);
            panel4.TabIndex = 2;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Dock = DockStyle.Top;
            label1.Font = new Font("Segoe UI Semibold", 24F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.ForeColor = Color.Navy;
            label1.Location = new Point(20, 20);
            label1.Name = "label1";
            label1.Size = new Size(299, 45);
            label1.TabIndex = 0;
            label1.Text = "Kelola Data Barang";
            label1.TextAlign = ContentAlignment.TopCenter;
            // 
            // panel2
            // 
            panel2.BackColor = Color.White;
            panel2.Controls.Add(label8);
            panel2.Controls.Add(TextStok);
            panel2.Controls.Add(panel5);
            panel2.Controls.Add(btnBatalEdit);
            panel2.Controls.Add(parrotButton2);
            panel2.Controls.Add(TextHargaJual);
            panel2.Controls.Add(TextHargaBeli);
            panel2.Controls.Add(label7);
            panel2.Controls.Add(label6);
            panel2.Controls.Add(TextBarang);
            panel2.Controls.Add(label5);
            panel2.Controls.Add(label4);
            panel2.Controls.Add(label2);
            panel2.Dock = DockStyle.Fill;
            panel2.Location = new Point(574, 20);
            panel2.Margin = new Padding(10, 20, 20, 20);
            panel2.Name = "panel2";
            panel2.Padding = new Padding(20, 15, 20, 20);
            panel2.Size = new Size(277, 441);
            panel2.TabIndex = 1;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label8.ForeColor = Color.DimGray;
            label8.Location = new Point(13, 140);
            label8.Name = "label8";
            label8.Size = new Size(56, 21);
            label8.TabIndex = 17;
            label8.Text = "H.Beli :";
            // 
            // TextStok
            // 
            TextStok.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            TextStok.BackColor = Color.White;
            TextStok.BaseColor = Color.White;
            TextStok.BorderColorA = Color.DarkGray;
            TextStok.BorderColorB = Color.DarkGray;
            TextStok.Font = new Font("Segoe UI", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            TextStok.ForeColor = Color.FromArgb(48, 49, 51);
            TextStok.Hint = "";
            TextStok.Location = new Point(13, 284);
            TextStok.MaxLength = 32767;
            TextStok.Multiline = false;
            TextStok.Name = "TextStok";
            TextStok.PasswordChar = '\0';
            TextStok.ScrollBars = ScrollBars.None;
            TextStok.SelectedText = "";
            TextStok.SelectionLength = 0;
            TextStok.SelectionStart = 0;
            TextStok.Size = new Size(249, 34);
            TextStok.TabIndex = 16;
            TextStok.TabStop = false;
            TextStok.UseSystemPasswordChar = false;
            // 
            // panel5
            // 
            panel5.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            panel5.BackColor = Color.FromArgb(5, 150, 105);
            panel5.Location = new Point(0, 0);
            panel5.Name = "panel5";
            panel5.Size = new Size(277, 12);
            panel5.TabIndex = 3;
            // 
            // btnBatalEdit
            // 
            btnBatalEdit.Anchor = AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            btnBatalEdit.BackgroundColor = Color.Gainsboro;
            btnBatalEdit.ButtonImage = null;
            btnBatalEdit.ButtonStyle = ReaLTaiizor.Controls.ParrotButton.Style.MaterialRounded;
            btnBatalEdit.ButtonText = "Batal Edit";
            btnBatalEdit.ClickBackColor = Color.FromArgb(195, 195, 195);
            btnBatalEdit.ClickTextColor = Color.DodgerBlue;
            btnBatalEdit.CornerRadius = 5;
            btnBatalEdit.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btnBatalEdit.Horizontal_Alignment = StringAlignment.Center;
            btnBatalEdit.HoverBackgroundColor = Color.FromArgb(225, 225, 225);
            btnBatalEdit.HoverTextColor = Color.DodgerBlue;
            btnBatalEdit.ImagePosition = ReaLTaiizor.Controls.ParrotButton.ImgPosition.Left;
            btnBatalEdit.Location = new Point(14, 390);
            btnBatalEdit.Name = "btnBatalEdit";
            btnBatalEdit.Size = new Size(250, 40);
            btnBatalEdit.SmoothingType = System.Drawing.Drawing2D.SmoothingMode.HighQuality;
            btnBatalEdit.TabIndex = 15;
            btnBatalEdit.TextColor = Color.Black;
            btnBatalEdit.TextRenderingType = System.Drawing.Text.TextRenderingHint.ClearTypeGridFit;
            btnBatalEdit.Vertical_Alignment = StringAlignment.Center;
            btnBatalEdit.Visible = false;
            // 
            // parrotButton2
            // 
            parrotButton2.Anchor = AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            parrotButton2.BackgroundColor = Color.FromArgb(255, 128, 0);
            parrotButton2.ButtonImage = null;
            parrotButton2.ButtonStyle = ReaLTaiizor.Controls.ParrotButton.Style.MaterialRounded;
            parrotButton2.ButtonText = "Tambah Barang";
            parrotButton2.ClickBackColor = Color.DimGray;
            parrotButton2.ClickTextColor = Color.DimGray;
            parrotButton2.CornerRadius = 5;
            parrotButton2.Font = new Font("Segoe UI", 14.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            parrotButton2.Horizontal_Alignment = StringAlignment.Center;
            parrotButton2.HoverBackgroundColor = Color.FromArgb(225, 225, 225);
            parrotButton2.HoverTextColor = Color.DodgerBlue;
            parrotButton2.ImagePosition = ReaLTaiizor.Controls.ParrotButton.ImgPosition.Left;
            parrotButton2.Location = new Point(14, 342);
            parrotButton2.Name = "parrotButton2";
            parrotButton2.Size = new Size(250, 42);
            parrotButton2.SmoothingType = System.Drawing.Drawing2D.SmoothingMode.HighQuality;
            parrotButton2.TabIndex = 8;
            parrotButton2.TextColor = Color.Black;
            parrotButton2.TextRenderingType = System.Drawing.Text.TextRenderingHint.ClearTypeGridFit;
            parrotButton2.Vertical_Alignment = StringAlignment.Center;
            parrotButton2.Click += parrotButton2_Click;
            // 
            // TextHargaJual
            // 
            TextHargaJual.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            TextHargaJual.BackColor = Color.White;
            TextHargaJual.BaseColor = Color.White;
            TextHargaJual.BorderColorA = Color.DarkGray;
            TextHargaJual.BorderColorB = Color.DarkGray;
            TextHargaJual.Font = new Font("Segoe UI", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            TextHargaJual.ForeColor = Color.FromArgb(48, 49, 51);
            TextHargaJual.Hint = "";
            TextHargaJual.Location = new Point(14, 223);
            TextHargaJual.MaxLength = 32767;
            TextHargaJual.Multiline = false;
            TextHargaJual.Name = "TextHargaJual";
            TextHargaJual.PasswordChar = '\0';
            TextHargaJual.ScrollBars = ScrollBars.None;
            TextHargaJual.SelectedText = "";
            TextHargaJual.SelectionLength = 0;
            TextHargaJual.SelectionStart = 0;
            TextHargaJual.Size = new Size(249, 34);
            TextHargaJual.TabIndex = 7;
            TextHargaJual.TabStop = false;
            TextHargaJual.UseSystemPasswordChar = false;
            TextHargaJual.Click += hopeTextBox3_Click;
            // 
            // TextHargaBeli
            // 
            TextHargaBeli.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            TextHargaBeli.BackColor = Color.White;
            TextHargaBeli.BaseColor = Color.White;
            TextHargaBeli.BorderColorA = Color.DarkGray;
            TextHargaBeli.BorderColorB = Color.DarkGray;
            TextHargaBeli.Font = new Font("Segoe UI", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            TextHargaBeli.ForeColor = Color.FromArgb(48, 49, 51);
            TextHargaBeli.Hint = "";
            TextHargaBeli.Location = new Point(13, 164);
            TextHargaBeli.MaxLength = 32767;
            TextHargaBeli.Multiline = false;
            TextHargaBeli.Name = "TextHargaBeli";
            TextHargaBeli.PasswordChar = '\0';
            TextHargaBeli.ScrollBars = ScrollBars.None;
            TextHargaBeli.SelectedText = "";
            TextHargaBeli.SelectionLength = 0;
            TextHargaBeli.SelectionStart = 0;
            TextHargaBeli.Size = new Size(249, 34);
            TextHargaBeli.TabIndex = 6;
            TextHargaBeli.TabStop = false;
            TextHargaBeli.UseSystemPasswordChar = false;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label7.ForeColor = Color.DimGray;
            label7.Location = new Point(14, 260);
            label7.Name = "label7";
            label7.Size = new Size(47, 21);
            label7.TabIndex = 5;
            label7.Text = "Stok :";
            label7.Click += label7_Click;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label6.ForeColor = Color.DimGray;
            label6.Location = new Point(13, 201);
            label6.Name = "label6";
            label6.Size = new Size(58, 21);
            label6.TabIndex = 4;
            label6.Text = "H.Jual :";
            // 
            // TextBarang
            // 
            TextBarang.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            TextBarang.BackColor = Color.White;
            TextBarang.BaseColor = Color.White;
            TextBarang.BorderColorA = Color.DarkGray;
            TextBarang.BorderColorB = Color.DarkGray;
            TextBarang.Font = new Font("Segoe UI", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            TextBarang.ForeColor = Color.Black;
            TextBarang.Hint = "";
            TextBarang.Location = new Point(14, 103);
            TextBarang.MaxLength = 32767;
            TextBarang.Multiline = false;
            TextBarang.Name = "TextBarang";
            TextBarang.PasswordChar = '\0';
            TextBarang.ScrollBars = ScrollBars.None;
            TextBarang.SelectedText = "";
            TextBarang.SelectionLength = 0;
            TextBarang.SelectionStart = 0;
            TextBarang.Size = new Size(249, 34);
            TextBarang.TabIndex = 3;
            TextBarang.TabStop = false;
            TextBarang.UseSystemPasswordChar = false;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.BackColor = Color.Transparent;
            label5.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label5.ForeColor = Color.DimGray;
            label5.Location = new Point(13, 79);
            label5.Name = "label5";
            label5.Size = new Size(112, 21);
            label5.TabIndex = 2;
            label5.Text = "Nama Barang :";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label4.ForeColor = Color.DimGray;
            label4.Location = new Point(13, 50);
            label4.Name = "label4";
            label4.Size = new Size(52, 21);
            label4.TabIndex = 1;
            label4.Text = "Kode :";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Dock = DockStyle.Top;
            label2.Font = new Font("Segoe UI Semibold", 20.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label2.ForeColor = Color.FromArgb(5, 150, 105);
            label2.Location = new Point(20, 15);
            label2.Name = "label2";
            label2.Size = new Size(250, 37);
            label2.TabIndex = 0;
            label2.Text = "Tambahkan Barang";
            label2.Click += label2_Click;
            // 
            // panel3
            // 
            panel3.BackColor = Color.Navy;
            panel3.Controls.Add(parrotButton3);
            panel3.Controls.Add(parrotButton1);
            panel3.Controls.Add(label3);
            panel3.Dock = DockStyle.Top;
            panel3.Location = new Point(0, 0);
            panel3.Name = "panel3";
            panel3.Size = new Size(871, 55);
            panel3.TabIndex = 2;
            // 
            // parrotButton3
            // 
            parrotButton3.BackgroundColor = Color.Gold;
            parrotButton3.ButtonImage = null;
            parrotButton3.ButtonStyle = ReaLTaiizor.Controls.ParrotButton.Style.MaterialRounded;
            parrotButton3.ButtonText = "Kembali";
            parrotButton3.ClickBackColor = Color.FromArgb(195, 195, 195);
            parrotButton3.ClickTextColor = Color.DodgerBlue;
            parrotButton3.CornerRadius = 5;
            parrotButton3.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            parrotButton3.Horizontal_Alignment = StringAlignment.Center;
            parrotButton3.HoverBackgroundColor = Color.FromArgb(225, 225, 225);
            parrotButton3.HoverTextColor = Color.DodgerBlue;
            parrotButton3.ImagePosition = ReaLTaiizor.Controls.ParrotButton.ImgPosition.Left;
            parrotButton3.Location = new Point(12, 9);
            parrotButton3.Name = "parrotButton3";
            parrotButton3.Size = new Size(95, 37);
            parrotButton3.SmoothingType = System.Drawing.Drawing2D.SmoothingMode.HighQuality;
            parrotButton3.TabIndex = 4;
            parrotButton3.TextColor = Color.Black;
            parrotButton3.TextRenderingType = System.Drawing.Text.TextRenderingHint.ClearTypeGridFit;
            parrotButton3.Vertical_Alignment = StringAlignment.Center;
            parrotButton3.Click += parrotButton3_Click;
            // 
            // parrotButton1
            // 
            parrotButton1.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            parrotButton1.BackgroundColor = Color.Gold;
            parrotButton1.ButtonImage = null;
            parrotButton1.ButtonStyle = ReaLTaiizor.Controls.ParrotButton.Style.MaterialRounded;
            parrotButton1.ButtonText = "Log out";
            parrotButton1.ClickBackColor = Color.FromArgb(195, 195, 195);
            parrotButton1.ClickTextColor = Color.Black;
            parrotButton1.CornerRadius = 10;
            parrotButton1.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            parrotButton1.Horizontal_Alignment = StringAlignment.Center;
            parrotButton1.HoverBackgroundColor = Color.FromArgb(225, 225, 225);
            parrotButton1.HoverTextColor = Color.DodgerBlue;
            parrotButton1.ImagePosition = ReaLTaiizor.Controls.ParrotButton.ImgPosition.Left;
            parrotButton1.Location = new Point(772, 9);
            parrotButton1.Name = "parrotButton1";
            parrotButton1.Size = new Size(88, 37);
            parrotButton1.SmoothingType = System.Drawing.Drawing2D.SmoothingMode.HighQuality;
            parrotButton1.TabIndex = 3;
            parrotButton1.TextColor = Color.Black;
            parrotButton1.TextRenderingType = System.Drawing.Text.TextRenderingHint.ClearTypeGridFit;
            parrotButton1.Vertical_Alignment = StringAlignment.Center;
            parrotButton1.Click += parrotButton1_Click;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI", 20.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label3.ForeColor = Color.Gold;
            label3.Location = new Point(113, 9);
            label3.Name = "label3";
            label3.Size = new Size(161, 37);
            label3.TabIndex = 0;
            label3.Text = "SMK MART";
            // 
            // FormKelolaBarang
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(871, 536);
            Controls.Add(tableLayoutPanel1);
            Controls.Add(panel3);
            Name = "FormKelolaBarang";
            Text = "FormKelolaBarang";
            WindowState = FormWindowState.Maximized;
            Load += FormKelolaBarang_Load;
            tableLayoutPanel1.ResumeLayout(false);
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)poisonDataGridView1).EndInit();
            panel2.ResumeLayout(false);
            panel2.PerformLayout();
            panel3.ResumeLayout(false);
            panel3.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private TableLayoutPanel tableLayoutPanel1;
        private Panel panel1;
        private Label label1;
        private ReaLTaiizor.Controls.PoisonDataGridView poisonDataGridView1;
        private Panel panel2;
        private Label label2;
        private Panel panel3;
        private ReaLTaiizor.Controls.ParrotButton parrotButton1;
        private Label label3;
        private Label label4;
        private Label label5;
        private ReaLTaiizor.Controls.HopeTextBox TextBarang;
        private ReaLTaiizor.Controls.HopeTextBox TextHargaJual;
        private ReaLTaiizor.Controls.HopeTextBox TextHargaBeli;
        private Label label7;
        private Label label6;
        private ReaLTaiizor.Controls.ParrotButton parrotButton2;
        private ReaLTaiizor.Controls.ParrotButton btnBatalEdit;
        private Panel panel4;
        private Panel panel5;
        private ReaLTaiizor.Controls.ParrotButton parrotButton3;
        private Label label8;
        private ReaLTaiizor.Controls.HopeTextBox TextStok;
        private DataGridViewTextBoxColumn Column1;
        private DataGridViewTextBoxColumn Column2;
        private DataGridViewTextBoxColumn Column8;
        private DataGridViewTextBoxColumn Column7;
        private DataGridViewTextBoxColumn Column4;
        private DataGridViewTextBoxColumn Column5;
        private DataGridViewTextBoxColumn Column6;
    }
}