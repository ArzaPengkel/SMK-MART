﻿namespace SMK_MART
{
    partial class FormLaporan
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            DataGridViewCellStyle dataGridViewCellStyle1 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle2 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle3 = new DataGridViewCellStyle();
            panel3 = new Panel();
            parrotButton4 = new ReaLTaiizor.Controls.ParrotButton();
            parrotButton2 = new ReaLTaiizor.Controls.ParrotButton();
            parrotButton3 = new ReaLTaiizor.Controls.ParrotButton();
            parrotButton1 = new ReaLTaiizor.Controls.ParrotButton();
            label3 = new Label();
            tableLayoutPanel1 = new TableLayoutPanel();
            panel1 = new Panel();
            lblSampai = new Label();
            lblDari = new Label();
            dtpSampai = new DateTimePicker();
            dateTimePicker1 = new DateTimePicker();
            gridKeranjang = new ReaLTaiizor.Controls.PoisonDataGridView();
            colTanggal = new DataGridViewTextBoxColumn();
            colBarang = new DataGridViewTextBoxColumn();
            colJml = new DataGridViewTextBoxColumn();
            colSubtotal = new DataGridViewTextBoxColumn();
            label1 = new Label();
            panel4 = new Panel();
            panel2 = new Panel();
            tableLayoutPanel2 = new TableLayoutPanel();
            pnlPenjualan = new Panel();
            lblPenjualan = new Label();
            lblPenjualanKet = new Label();
            lblPenjualanJudul = new Label();
            pnlModal = new Panel();
            lblModal = new Label();
            lblModalKet = new Label();
            lblModalJudul = new Label();
            pnlLaba = new Panel();
            lblLaba = new Label();
            lblLabaKet = new Label();
            lblLabaJudul = new Label();
            pnlMargin = new Panel();
            lblMargin = new Label();
            lblMarginKet = new Label();
            lblMarginJudul = new Label();
            panel3.SuspendLayout();
            tableLayoutPanel1.SuspendLayout();
            panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)gridKeranjang).BeginInit();
            panel2.SuspendLayout();
            tableLayoutPanel2.SuspendLayout();
            pnlPenjualan.SuspendLayout();
            pnlModal.SuspendLayout();
            pnlLaba.SuspendLayout();
            pnlMargin.SuspendLayout();
            SuspendLayout();
            // 
            // panel3
            // 
            panel3.BackColor = Color.Navy;
            panel3.Controls.Add(parrotButton4);
            panel3.Controls.Add(parrotButton2);
            panel3.Controls.Add(parrotButton3);
            panel3.Controls.Add(parrotButton1);
            panel3.Controls.Add(label3);
            panel3.Dock = DockStyle.Top;
            panel3.Location = new Point(0, 0);
            panel3.Name = "panel3";
            panel3.Size = new Size(891, 70);
            panel3.TabIndex = 4;
            // 
            // parrotButton4
            // 
            parrotButton4.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            parrotButton4.BackgroundColor = Color.Gold;
            parrotButton4.ButtonImage = null;
            parrotButton4.ButtonStyle = ReaLTaiizor.Controls.ParrotButton.Style.MaterialRounded;
            parrotButton4.ButtonText = "Log out";
            parrotButton4.ClickBackColor = Color.FromArgb(195, 195, 195);
            parrotButton4.ClickTextColor = Color.Black;
            parrotButton4.CornerRadius = 10;
            parrotButton4.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            parrotButton4.Horizontal_Alignment = StringAlignment.Center;
            parrotButton4.HoverBackgroundColor = Color.FromArgb(225, 225, 225);
            parrotButton4.HoverTextColor = Color.DodgerBlue;
            parrotButton4.ImagePosition = ReaLTaiizor.Controls.ParrotButton.ImgPosition.Left;
            parrotButton4.Location = new Point(791, 12);
            parrotButton4.Name = "parrotButton4";
            parrotButton4.Size = new Size(88, 45);
            parrotButton4.SmoothingType = System.Drawing.Drawing2D.SmoothingMode.HighQuality;
            parrotButton4.TabIndex = 6;
            parrotButton4.TextColor = Color.Black;
            parrotButton4.TextRenderingType = System.Drawing.Text.TextRenderingHint.ClearTypeGridFit;
            parrotButton4.Vertical_Alignment = StringAlignment.Center;
            parrotButton4.Click += parrotButton4_Click;
            // 
            // parrotButton2
            // 
            parrotButton2.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            parrotButton2.BackgroundColor = Color.Gold;
            parrotButton2.ButtonImage = null;
            parrotButton2.ButtonStyle = ReaLTaiizor.Controls.ParrotButton.Style.MaterialRounded;
            parrotButton2.ButtonText = "Log out";
            parrotButton2.ClickBackColor = Color.FromArgb(195, 195, 195);
            parrotButton2.ClickTextColor = Color.Black;
            parrotButton2.CornerRadius = 10;
            parrotButton2.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            parrotButton2.Horizontal_Alignment = StringAlignment.Center;
            parrotButton2.HoverBackgroundColor = Color.FromArgb(225, 225, 225);
            parrotButton2.HoverTextColor = Color.DodgerBlue;
            parrotButton2.ImagePosition = ReaLTaiizor.Controls.ParrotButton.ImgPosition.Left;
            parrotButton2.Location = new Point(1391, 9);
            parrotButton2.Name = "parrotButton2";
            parrotButton2.Size = new Size(88, 37);
            parrotButton2.SmoothingType = System.Drawing.Drawing2D.SmoothingMode.HighQuality;
            parrotButton2.TabIndex = 5;
            parrotButton2.TextColor = Color.Black;
            parrotButton2.TextRenderingType = System.Drawing.Text.TextRenderingHint.ClearTypeGridFit;
            parrotButton2.Vertical_Alignment = StringAlignment.Center;
            // 
            // parrotButton3
            // 
            parrotButton3.BackgroundColor = Color.Gold;
            parrotButton3.ButtonImage = null;
            parrotButton3.ButtonStyle = ReaLTaiizor.Controls.ParrotButton.Style.MaterialRounded;
            parrotButton3.ButtonText = "Kembali";
            parrotButton3.ClickBackColor = Color.FromArgb(195, 195, 195);
            parrotButton3.ClickTextColor = Color.DodgerBlue;
            parrotButton3.CornerRadius = 5;
            parrotButton3.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            parrotButton3.Horizontal_Alignment = StringAlignment.Center;
            parrotButton3.HoverBackgroundColor = Color.FromArgb(225, 225, 225);
            parrotButton3.HoverTextColor = Color.DodgerBlue;
            parrotButton3.ImagePosition = ReaLTaiizor.Controls.ParrotButton.ImgPosition.Left;
            parrotButton3.Location = new Point(15, 12);
            parrotButton3.Name = "parrotButton3";
            parrotButton3.Size = new Size(99, 44);
            parrotButton3.SmoothingType = System.Drawing.Drawing2D.SmoothingMode.HighQuality;
            parrotButton3.TabIndex = 4;
            parrotButton3.TextColor = Color.Black;
            parrotButton3.TextRenderingType = System.Drawing.Text.TextRenderingHint.ClearTypeGridFit;
            parrotButton3.Vertical_Alignment = StringAlignment.Center;
            // 
            // parrotButton1
            // 
            parrotButton1.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            parrotButton1.BackgroundColor = Color.Gold;
            parrotButton1.ButtonImage = null;
            parrotButton1.ButtonStyle = ReaLTaiizor.Controls.ParrotButton.Style.MaterialRounded;
            parrotButton1.ButtonText = "Log out";
            parrotButton1.ClickBackColor = Color.FromArgb(195, 195, 195);
            parrotButton1.ClickTextColor = Color.Black;
            parrotButton1.CornerRadius = 10;
            parrotButton1.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            parrotButton1.Horizontal_Alignment = StringAlignment.Center;
            parrotButton1.HoverBackgroundColor = Color.FromArgb(225, 225, 225);
            parrotButton1.HoverTextColor = Color.DodgerBlue;
            parrotButton1.ImagePosition = ReaLTaiizor.Controls.ParrotButton.ImgPosition.Left;
            parrotButton1.Location = new Point(2093, 9);
            parrotButton1.Name = "parrotButton1";
            parrotButton1.Size = new Size(88, 37);
            parrotButton1.SmoothingType = System.Drawing.Drawing2D.SmoothingMode.HighQuality;
            parrotButton1.TabIndex = 3;
            parrotButton1.TextColor = Color.Black;
            parrotButton1.TextRenderingType = System.Drawing.Text.TextRenderingHint.ClearTypeGridFit;
            parrotButton1.Vertical_Alignment = StringAlignment.Center;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI", 24F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label3.ForeColor = Color.Gold;
            label3.Location = new Point(120, 12);
            label3.Name = "label3";
            label3.Size = new Size(192, 45);
            label3.TabIndex = 0;
            label3.Text = "SMK MART";
            // 
            // tableLayoutPanel1
            // 
            tableLayoutPanel1.BackColor = Color.Gainsboro;
            tableLayoutPanel1.ColumnCount = 2;
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 55.5035133F));
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 44.4964867F));
            tableLayoutPanel1.Controls.Add(panel1, 0, 0);
            tableLayoutPanel1.Controls.Add(panel2, 1, 0);
            tableLayoutPanel1.Dock = DockStyle.Fill;
            tableLayoutPanel1.Location = new Point(0, 70);
            tableLayoutPanel1.Name = "tableLayoutPanel1";
            tableLayoutPanel1.RowCount = 1;
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 100F));
            tableLayoutPanel1.Size = new Size(891, 391);
            tableLayoutPanel1.TabIndex = 5;
            // 
            // panel1
            // 
            panel1.BackColor = Color.White;
            panel1.Controls.Add(lblSampai);
            panel1.Controls.Add(lblDari);
            panel1.Controls.Add(dtpSampai);
            panel1.Controls.Add(dateTimePicker1);
            panel1.Controls.Add(gridKeranjang);
            panel1.Controls.Add(label1);
            panel1.Controls.Add(panel4);
            panel1.Dock = DockStyle.Fill;
            panel1.Location = new Point(15, 10);
            panel1.Margin = new Padding(15, 10, 15, 10);
            panel1.Name = "panel1";
            panel1.Size = new Size(464, 371);
            panel1.TabIndex = 0;
            panel1.Paint += panel1_Paint;
            // 
            // lblSampai
            // 
            lblSampai.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            lblSampai.AutoSize = true;
            lblSampai.Font = new Font("Segoe UI", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblSampai.ForeColor = Color.DimGray;
            lblSampai.Location = new Point(274, 74);
            lblSampai.Name = "lblSampai";
            lblSampai.Size = new Size(99, 17);
            lblSampai.TabIndex = 9;
            lblSampai.Text = "Sampai tanggal";
            // 
            // lblDari
            // 
            lblDari.AutoSize = true;
            lblDari.Font = new Font("Segoe UI", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblDari.ForeColor = Color.DimGray;
            lblDari.Location = new Point(13, 74);
            lblDari.Name = "lblDari";
            lblDari.Size = new Size(80, 17);
            lblDari.TabIndex = 8;
            lblDari.Text = "Dari tanggal";
            // 
            // dtpSampai
            // 
            dtpSampai.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            dtpSampai.CalendarTitleBackColor = Color.DarkGray;
            dtpSampai.CalendarTrailingForeColor = Color.DarkGray;
            dtpSampai.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            dtpSampai.Format = DateTimePickerFormat.Short;
            dtpSampai.Location = new Point(233, 94);
            dtpSampai.Name = "dtpSampai";
            dtpSampai.Size = new Size(211, 29);
            dtpSampai.TabIndex = 3;
            // 
            // dateTimePicker1
            // 
            dateTimePicker1.CalendarTitleBackColor = Color.DarkGray;
            dateTimePicker1.CalendarTrailingForeColor = Color.DarkGray;
            dateTimePicker1.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            dateTimePicker1.Format = DateTimePickerFormat.Short;
            dateTimePicker1.Location = new Point(13, 94);
            dateTimePicker1.Name = "dateTimePicker1";
            dateTimePicker1.Size = new Size(198, 29);
            dateTimePicker1.TabIndex = 2;
            // 
            // gridKeranjang
            // 
            gridKeranjang.AllowUserToAddRows = false;
            gridKeranjang.AllowUserToResizeRows = false;
            gridKeranjang.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            gridKeranjang.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            gridKeranjang.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.DisplayedCellsExceptHeaders;
            gridKeranjang.BackgroundColor = Color.FromArgb(255, 255, 255);
            gridKeranjang.BorderStyle = BorderStyle.None;
            gridKeranjang.CellBorderStyle = DataGridViewCellBorderStyle.None;
            gridKeranjang.ColumnHeadersBorderStyle = DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle1.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = Color.Gainsboro;
            dataGridViewCellStyle1.Font = new Font("Segoe UI Semibold", 15.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            dataGridViewCellStyle1.ForeColor = Color.Navy;
            dataGridViewCellStyle1.SelectionBackColor = Color.Gainsboro;
            dataGridViewCellStyle1.SelectionForeColor = Color.Navy;
            dataGridViewCellStyle1.WrapMode = DataGridViewTriState.True;
            gridKeranjang.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            gridKeranjang.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            gridKeranjang.Columns.AddRange(new DataGridViewColumn[] { colTanggal, colBarang, colJml, colSubtotal });
            dataGridViewCellStyle2.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = Color.FromArgb(255, 255, 255);
            dataGridViewCellStyle2.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            dataGridViewCellStyle2.ForeColor = Color.FromArgb(64, 64, 64);
            dataGridViewCellStyle2.SelectionBackColor = Color.DarkGray;
            dataGridViewCellStyle2.SelectionForeColor = Color.FromArgb(64, 64, 64);
            dataGridViewCellStyle2.WrapMode = DataGridViewTriState.False;
            gridKeranjang.DefaultCellStyle = dataGridViewCellStyle2;
            gridKeranjang.EnableHeadersVisualStyles = false;
            gridKeranjang.Font = new Font("Segoe UI", 11F, FontStyle.Regular, GraphicsUnit.Pixel);
            gridKeranjang.GridColor = Color.Silver;
            gridKeranjang.Location = new Point(13, 137);
            gridKeranjang.Name = "gridKeranjang";
            gridKeranjang.ReadOnly = true;
            gridKeranjang.RowHeadersBorderStyle = DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle3.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = Color.FromArgb(0, 174, 219);
            dataGridViewCellStyle3.Font = new Font("Segoe UI", 11F, FontStyle.Regular, GraphicsUnit.Pixel);
            dataGridViewCellStyle3.ForeColor = Color.FromArgb(255, 255, 255);
            dataGridViewCellStyle3.SelectionBackColor = Color.FromArgb(0, 198, 247);
            dataGridViewCellStyle3.SelectionForeColor = Color.FromArgb(17, 17, 17);
            dataGridViewCellStyle3.WrapMode = DataGridViewTriState.True;
            gridKeranjang.RowHeadersDefaultCellStyle = dataGridViewCellStyle3;
            gridKeranjang.RowHeadersVisible = false;
            gridKeranjang.RowHeadersWidthSizeMode = DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            gridKeranjang.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            gridKeranjang.Size = new Size(431, 194);
            gridKeranjang.TabIndex = 7;
            // 
            // colTanggal
            // 
            colTanggal.FillWeight = 85F;
            colTanggal.HeaderText = "Tanggal";
            colTanggal.Name = "colTanggal";
            colTanggal.ReadOnly = true;
            // 
            // colBarang
            // 
            colBarang.FillWeight = 150F;
            colBarang.HeaderText = "Barang";
            colBarang.Name = "colBarang";
            colBarang.ReadOnly = true;
            // 
            // colJml
            // 
            colJml.FillWeight = 50F;
            colJml.HeaderText = "Jml";
            colJml.Name = "colJml";
            colJml.ReadOnly = true;
            // 
            // colSubtotal
            // 
            colSubtotal.HeaderText = "Subtotal";
            colSubtotal.Name = "colSubtotal";
            colSubtotal.ReadOnly = true;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI Semibold", 27.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.ForeColor = Color.Navy;
            label1.Location = new Point(3, 22);
            label1.Name = "label1";
            label1.Size = new Size(333, 50);
            label1.TabIndex = 1;
            label1.Text = "Laporan Penjualan";
            // 
            // panel4
            // 
            panel4.BackColor = Color.Navy;
            panel4.Dock = DockStyle.Top;
            panel4.Location = new Point(0, 0);
            panel4.Name = "panel4";
            panel4.Size = new Size(464, 10);
            panel4.TabIndex = 0;
            // 
            // panel2
            // 
            panel2.BackColor = Color.White;
            panel2.Controls.Add(tableLayoutPanel2);
            panel2.Dock = DockStyle.Fill;
            panel2.Location = new Point(509, 10);
            panel2.Margin = new Padding(15, 10, 15, 10);
            panel2.Name = "panel2";
            panel2.Size = new Size(367, 371);
            panel2.TabIndex = 1;
            // 
            // tableLayoutPanel2
            // 
            tableLayoutPanel2.ColumnCount = 2;
            tableLayoutPanel2.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));
            tableLayoutPanel2.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));
            tableLayoutPanel2.Controls.Add(pnlPenjualan, 0, 0);
            tableLayoutPanel2.Controls.Add(pnlModal, 1, 0);
            tableLayoutPanel2.Controls.Add(pnlLaba, 0, 1);
            tableLayoutPanel2.Controls.Add(pnlMargin, 1, 1);
            tableLayoutPanel2.Dock = DockStyle.Fill;
            tableLayoutPanel2.Location = new Point(0, 0);
            tableLayoutPanel2.Name = "tableLayoutPanel2";
            tableLayoutPanel2.RowCount = 2;
            tableLayoutPanel2.RowStyles.Add(new RowStyle(SizeType.Percent, 50F));
            tableLayoutPanel2.RowStyles.Add(new RowStyle(SizeType.Percent, 50F));
            tableLayoutPanel2.Size = new Size(367, 371);
            tableLayoutPanel2.TabIndex = 0;
            // 
            // pnlPenjualan
            // 
            pnlPenjualan.BackColor = Color.FromArgb(192, 255, 192);
            pnlPenjualan.Controls.Add(lblPenjualan);
            pnlPenjualan.Controls.Add(lblPenjualanKet);
            pnlPenjualan.Controls.Add(lblPenjualanJudul);
            pnlPenjualan.Dock = DockStyle.Fill;
            pnlPenjualan.Location = new Point(10, 10);
            pnlPenjualan.Margin = new Padding(10);
            pnlPenjualan.Name = "pnlPenjualan";
            pnlPenjualan.Padding = new Padding(6);
            pnlPenjualan.Size = new Size(163, 165);
            pnlPenjualan.TabIndex = 0;
            // 
            // lblPenjualan
            // 
            lblPenjualan.Dock = DockStyle.Fill;
            lblPenjualan.Font = new Font("Segoe UI", 15.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblPenjualan.ForeColor = Color.FromArgb(32, 32, 32);
            lblPenjualan.Location = new Point(6, 36);
            lblPenjualan.Name = "lblPenjualan";
            lblPenjualan.Size = new Size(151, 79);
            lblPenjualan.TabIndex = 1;
            lblPenjualan.Text = "Rp0";
            lblPenjualan.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // lblPenjualanKet
            // 
            lblPenjualanKet.Dock = DockStyle.Bottom;
            lblPenjualanKet.Font = new Font("Segoe UI", 11.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblPenjualanKet.ForeColor = Color.FromArgb(80, 80, 80);
            lblPenjualanKet.Location = new Point(6, 115);
            lblPenjualanKet.Name = "lblPenjualanKet";
            lblPenjualanKet.Size = new Size(151, 44);
            lblPenjualanKet.TabIndex = 2;
            lblPenjualanKet.TextAlign = ContentAlignment.TopCenter;
            lblPenjualanKet.Click += lblPenjualanKet_Click;
            // 
            // lblPenjualanJudul
            // 
            lblPenjualanJudul.Dock = DockStyle.Top;
            lblPenjualanJudul.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblPenjualanJudul.ForeColor = Color.FromArgb(64, 64, 64);
            lblPenjualanJudul.Location = new Point(6, 6);
            lblPenjualanJudul.Name = "lblPenjualanJudul";
            lblPenjualanJudul.Size = new Size(151, 30);
            lblPenjualanJudul.TabIndex = 0;
            lblPenjualanJudul.Text = "Penjualan";
            lblPenjualanJudul.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // pnlModal
            // 
            pnlModal.BackColor = Color.FromArgb(255, 224, 192);
            pnlModal.Controls.Add(lblModal);
            pnlModal.Controls.Add(lblModalKet);
            pnlModal.Controls.Add(lblModalJudul);
            pnlModal.Dock = DockStyle.Fill;
            pnlModal.Location = new Point(193, 10);
            pnlModal.Margin = new Padding(10);
            pnlModal.Name = "pnlModal";
            pnlModal.Padding = new Padding(6);
            pnlModal.Size = new Size(164, 165);
            pnlModal.TabIndex = 1;
            // 
            // lblModal
            // 
            lblModal.Dock = DockStyle.Fill;
            lblModal.Font = new Font("Segoe UI", 15.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblModal.ForeColor = Color.FromArgb(32, 32, 32);
            lblModal.Location = new Point(6, 36);
            lblModal.Name = "lblModal";
            lblModal.Size = new Size(152, 79);
            lblModal.TabIndex = 4;
            lblModal.Text = "Rp0";
            lblModal.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // lblModalKet
            // 
            lblModalKet.Dock = DockStyle.Bottom;
            lblModalKet.Font = new Font("Segoe UI", 11.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblModalKet.ForeColor = Color.FromArgb(80, 80, 80);
            lblModalKet.Location = new Point(6, 115);
            lblModalKet.Name = "lblModalKet";
            lblModalKet.Size = new Size(152, 44);
            lblModalKet.TabIndex = 5;
            lblModalKet.TextAlign = ContentAlignment.TopCenter;
            // 
            // lblModalJudul
            // 
            lblModalJudul.Dock = DockStyle.Top;
            lblModalJudul.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblModalJudul.ForeColor = Color.FromArgb(64, 64, 64);
            lblModalJudul.Location = new Point(6, 6);
            lblModalJudul.Name = "lblModalJudul";
            lblModalJudul.Size = new Size(152, 30);
            lblModalJudul.TabIndex = 3;
            lblModalJudul.Text = "Modal";
            lblModalJudul.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // pnlLaba
            // 
            pnlLaba.BackColor = Color.FromArgb(192, 192, 255);
            pnlLaba.Controls.Add(lblLaba);
            pnlLaba.Controls.Add(lblLabaKet);
            pnlLaba.Controls.Add(lblLabaJudul);
            pnlLaba.Dock = DockStyle.Fill;
            pnlLaba.Location = new Point(10, 195);
            pnlLaba.Margin = new Padding(10);
            pnlLaba.Name = "pnlLaba";
            pnlLaba.Padding = new Padding(6);
            pnlLaba.Size = new Size(163, 166);
            pnlLaba.TabIndex = 2;
            // 
            // lblLaba
            // 
            lblLaba.Dock = DockStyle.Fill;
            lblLaba.Font = new Font("Segoe UI", 15.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblLaba.ForeColor = Color.FromArgb(32, 32, 32);
            lblLaba.Location = new Point(6, 36);
            lblLaba.Name = "lblLaba";
            lblLaba.Size = new Size(151, 80);
            lblLaba.TabIndex = 7;
            lblLaba.Text = "Rp0";
            lblLaba.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // lblLabaKet
            // 
            lblLabaKet.Dock = DockStyle.Bottom;
            lblLabaKet.Font = new Font("Segoe UI", 11.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblLabaKet.ForeColor = Color.FromArgb(80, 80, 80);
            lblLabaKet.Location = new Point(6, 116);
            lblLabaKet.Name = "lblLabaKet";
            lblLabaKet.Size = new Size(151, 44);
            lblLabaKet.TabIndex = 8;
            lblLabaKet.TextAlign = ContentAlignment.TopCenter;
            // 
            // lblLabaJudul
            // 
            lblLabaJudul.Dock = DockStyle.Top;
            lblLabaJudul.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblLabaJudul.ForeColor = Color.FromArgb(64, 64, 64);
            lblLabaJudul.Location = new Point(6, 6);
            lblLabaJudul.Name = "lblLabaJudul";
            lblLabaJudul.Size = new Size(151, 30);
            lblLabaJudul.TabIndex = 6;
            lblLabaJudul.Text = "Laba";
            lblLabaJudul.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // pnlMargin
            // 
            pnlMargin.BackColor = Color.FromArgb(255, 192, 192);
            pnlMargin.Controls.Add(lblMargin);
            pnlMargin.Controls.Add(lblMarginKet);
            pnlMargin.Controls.Add(lblMarginJudul);
            pnlMargin.Dock = DockStyle.Fill;
            pnlMargin.Location = new Point(193, 195);
            pnlMargin.Margin = new Padding(10);
            pnlMargin.Name = "pnlMargin";
            pnlMargin.Padding = new Padding(6);
            pnlMargin.Size = new Size(164, 166);
            pnlMargin.TabIndex = 3;
            // 
            // lblMargin
            // 
            lblMargin.Dock = DockStyle.Fill;
            lblMargin.Font = new Font("Segoe UI", 15.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblMargin.ForeColor = Color.FromArgb(32, 32, 32);
            lblMargin.Location = new Point(6, 36);
            lblMargin.Name = "lblMargin";
            lblMargin.Size = new Size(152, 80);
            lblMargin.TabIndex = 10;
            lblMargin.Text = "Rp0";
            lblMargin.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // lblMarginKet
            // 
            lblMarginKet.Dock = DockStyle.Bottom;
            lblMarginKet.Font = new Font("Segoe UI", 11.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblMarginKet.ForeColor = Color.FromArgb(80, 80, 80);
            lblMarginKet.Location = new Point(6, 116);
            lblMarginKet.Name = "lblMarginKet";
            lblMarginKet.Size = new Size(152, 44);
            lblMarginKet.TabIndex = 11;
            lblMarginKet.TextAlign = ContentAlignment.TopCenter;
            // 
            // lblMarginJudul
            // 
            lblMarginJudul.Dock = DockStyle.Top;
            lblMarginJudul.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblMarginJudul.ForeColor = Color.FromArgb(64, 64, 64);
            lblMarginJudul.Location = new Point(6, 6);
            lblMarginJudul.Name = "lblMarginJudul";
            lblMarginJudul.Size = new Size(152, 30);
            lblMarginJudul.TabIndex = 9;
            lblMarginJudul.Text = "Margin";
            lblMarginJudul.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // FormLaporan
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(891, 461);
            Controls.Add(tableLayoutPanel1);
            Controls.Add(panel3);
            Name = "FormLaporan";
            Text = "FormLaporan";
            WindowState = FormWindowState.Maximized;
            Load += FormLaporan_Load;
            panel3.ResumeLayout(false);
            panel3.PerformLayout();
            tableLayoutPanel1.ResumeLayout(false);
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)gridKeranjang).EndInit();
            panel2.ResumeLayout(false);
            tableLayoutPanel2.ResumeLayout(false);
            pnlPenjualan.ResumeLayout(false);
            pnlModal.ResumeLayout(false);
            pnlLaba.ResumeLayout(false);
            pnlMargin.ResumeLayout(false);
            ResumeLayout(false);
        }

        #endregion
        private Panel panel3;
        private ReaLTaiizor.Controls.ParrotButton parrotButton2;
        private ReaLTaiizor.Controls.ParrotButton parrotButton3;
        private ReaLTaiizor.Controls.ParrotButton parrotButton1;
        private Label label3;
        private TableLayoutPanel tableLayoutPanel1;
        private Panel panel1;
        private Panel panel4;
        private Label label1;
        private ReaLTaiizor.Controls.PoisonDataGridView gridKeranjang;
        private DataGridViewTextBoxColumn colTanggal;
        private DataGridViewTextBoxColumn colBarang;
        private DateTimePicker dtpSampai;
        private Label lblDari;
        private Label lblSampai;
        private DataGridViewTextBoxColumn colJml;
        private DataGridViewTextBoxColumn colSubtotal;
        private DateTimePicker dateTimePicker1;
        private ReaLTaiizor.Controls.ParrotButton parrotButton4;
        private Panel panel2;
        private TableLayoutPanel tableLayoutPanel2;
        private Panel pnlPenjualan;
        private Panel pnlModal;
        private Panel pnlLaba;
        private Panel pnlMargin;
        private Label lblPenjualanJudul;
        private Label lblPenjualan;
        private Label lblPenjualanKet;
        private Label lblModalJudul;
        private Label lblModal;
        private Label lblModalKet;
        private Label lblLabaJudul;
        private Label lblLaba;
        private Label lblLabaKet;
        private Label lblMarginJudul;
        private Label lblMargin;
        private Label lblMarginKet;
    }
}