﻿namespace SMK_MART
{
    partial class FormLogin
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            tableLayoutPanel1 = new TableLayoutPanel();
            panelBrand = new Panel();
            panelKanan = new Panel();
            panel2 = new Panel();
            label9 = new Label();
            lblSub = new Label();
            label8 = new Label();
            hopeTextBox1 = new ReaLTaiizor.Controls.HopeTextBox();
            label7 = new Label();
            hopeTextBox2 = new ReaLTaiizor.Controls.HopeTextBox();
            chkTampilkan = new CheckBox();
            button2 = new Button();
            lblFooter = new Label();
            tableLayoutPanel1.SuspendLayout();
            panelKanan.SuspendLayout();
            panel2.SuspendLayout();
            SuspendLayout();
            // 
            // tableLayoutPanel1
            // 
            tableLayoutPanel1.ColumnCount = 2;
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));
            tableLayoutPanel1.Controls.Add(panelBrand, 0, 0);
            tableLayoutPanel1.Controls.Add(panelKanan, 1, 0);
            tableLayoutPanel1.Dock = DockStyle.Fill;
            tableLayoutPanel1.Location = new Point(0, 0);
            tableLayoutPanel1.Margin = new Padding(0);
            tableLayoutPanel1.Name = "tableLayoutPanel1";
            tableLayoutPanel1.RowCount = 1;
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 100F));
            tableLayoutPanel1.Size = new Size(900, 481);
            tableLayoutPanel1.TabIndex = 0;
            // 
            // panelBrand
            // 
            panelBrand.BackColor = Color.Navy;
            panelBrand.Dock = DockStyle.Fill;
            panelBrand.Location = new Point(0, 0);
            panelBrand.Margin = new Padding(0);
            panelBrand.Name = "panelBrand";
            panelBrand.Size = new Size(450, 481);
            panelBrand.TabIndex = 0;
            panelBrand.Paint += panelBrand_Paint;
            panelBrand.Resize += panelBrand_Resize;
            // 
            // panelKanan
            // 
            panelKanan.BackColor = Color.FromArgb(244, 246, 251);
            panelKanan.Controls.Add(panel2);
            panelKanan.Dock = DockStyle.Fill;
            panelKanan.Location = new Point(450, 0);
            panelKanan.Margin = new Padding(0);
            panelKanan.Name = "panelKanan";
            panelKanan.Size = new Size(450, 481);
            panelKanan.TabIndex = 1;
            // 
            // panel2
            // 
            panel2.BackColor = Color.White;
            panel2.BorderStyle = BorderStyle.FixedSingle;
            panel2.Controls.Add(label9);
            panel2.Controls.Add(lblSub);
            panel2.Controls.Add(label8);
            panel2.Controls.Add(hopeTextBox1);
            panel2.Controls.Add(label7);
            panel2.Controls.Add(hopeTextBox2);
            panel2.Controls.Add(chkTampilkan);
            panel2.Controls.Add(button2);
            panel2.Controls.Add(lblFooter);
            panel2.Dock = DockStyle.Fill;
            panel2.Location = new Point(0, 0);
            panel2.Margin = new Padding(0);
            panel2.Name = "panel2";
            panel2.Size = new Size(450, 481);
            panel2.TabIndex = 0;
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Font = new Font("Segoe UI", 26.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label9.ForeColor = Color.Navy;
            label9.Location = new Point(24, 27);
            label9.Name = "label9";
            label9.Size = new Size(284, 47);
            label9.TabIndex = 0;
            label9.Text = "Selamat Datang";
            // 
            // lblSub
            // 
            lblSub.AutoSize = true;
            lblSub.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblSub.ForeColor = Color.DimGray;
            lblSub.Location = new Point(27, 83);
            lblSub.Name = "lblSub";
            lblSub.Size = new Size(244, 21);
            lblSub.TabIndex = 1;
            lblSub.Text = "Silakan masuk untuk melanjutkan";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Font = new Font("Segoe UI Semibold", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label8.ForeColor = Color.FromArgb(50, 50, 70);
            label8.Location = new Point(27, 132);
            label8.Name = "label8";
            label8.Size = new Size(73, 25);
            label8.TabIndex = 2;
            label8.Text = "ID user";
            // 
            // hopeTextBox1
            // 
            hopeTextBox1.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            hopeTextBox1.BackColor = Color.White;
            hopeTextBox1.BaseColor = Color.White;
            hopeTextBox1.BorderColorA = Color.FromArgb(41, 57, 178);
            hopeTextBox1.BorderColorB = Color.FromArgb(190, 195, 210);
            hopeTextBox1.Font = new Font("Segoe UI", 15.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            hopeTextBox1.ForeColor = Color.FromArgb(64, 64, 64);
            hopeTextBox1.Hint = "Masukkan ID user";
            hopeTextBox1.Location = new Point(24, 160);
            hopeTextBox1.MaxLength = 32767;
            hopeTextBox1.Multiline = false;
            hopeTextBox1.Name = "hopeTextBox1";
            hopeTextBox1.PasswordChar = '\0';
            hopeTextBox1.ScrollBars = ScrollBars.None;
            hopeTextBox1.SelectedText = "";
            hopeTextBox1.SelectionLength = 0;
            hopeTextBox1.SelectionStart = 0;
            hopeTextBox1.Size = new Size(394, 44);
            hopeTextBox1.TabIndex = 0;
            hopeTextBox1.TabStop = false;
            hopeTextBox1.UseSystemPasswordChar = true;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Segoe UI Semibold", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label7.ForeColor = Color.FromArgb(50, 50, 70);
            label7.Location = new Point(24, 227);
            label7.Name = "label7";
            label7.Size = new Size(91, 25);
            label7.TabIndex = 3;
            label7.Text = "Password";
            // 
            // hopeTextBox2
            // 
            hopeTextBox2.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            hopeTextBox2.BackColor = Color.White;
            hopeTextBox2.BaseColor = Color.White;
            hopeTextBox2.BorderColorA = Color.FromArgb(41, 57, 178);
            hopeTextBox2.BorderColorB = Color.FromArgb(190, 195, 210);
            hopeTextBox2.Font = new Font("Segoe UI", 15.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            hopeTextBox2.ForeColor = Color.FromArgb(64, 64, 64);
            hopeTextBox2.Hint = "Masukkan password";
            hopeTextBox2.Location = new Point(24, 255);
            hopeTextBox2.MaxLength = 32767;
            hopeTextBox2.Multiline = false;
            hopeTextBox2.Name = "hopeTextBox2";
            hopeTextBox2.PasswordChar = '\0';
            hopeTextBox2.ScrollBars = ScrollBars.None;
            hopeTextBox2.SelectedText = "";
            hopeTextBox2.SelectionLength = 0;
            hopeTextBox2.SelectionStart = 0;
            hopeTextBox2.Size = new Size(394, 44);
            hopeTextBox2.TabIndex = 1;
            hopeTextBox2.TabStop = false;
            hopeTextBox2.UseSystemPasswordChar = true;
            // 
            // chkTampilkan
            // 
            chkTampilkan.AutoSize = true;
            chkTampilkan.Cursor = Cursors.Hand;
            chkTampilkan.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            chkTampilkan.ForeColor = Color.DimGray;
            chkTampilkan.Location = new Point(29, 305);
            chkTampilkan.Name = "chkTampilkan";
            chkTampilkan.Size = new Size(170, 25);
            chkTampilkan.TabIndex = 2;
            chkTampilkan.TabStop = false;
            chkTampilkan.Text = "Tampilkan password";
            chkTampilkan.UseVisualStyleBackColor = true;
            chkTampilkan.CheckedChanged += chkTampilkan_CheckedChanged;
            // 
            // button2
            // 
            button2.Anchor = AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            button2.BackColor = Color.Navy;
            button2.Cursor = Cursors.Hand;
            button2.FlatAppearance.BorderSize = 0;
            button2.FlatAppearance.MouseDownBackColor = Color.FromArgb(10, 15, 80);
            button2.FlatAppearance.MouseOverBackColor = Color.FromArgb(41, 57, 178);
            button2.FlatStyle = FlatStyle.Flat;
            button2.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button2.ForeColor = Color.White;
            button2.Location = new Point(24, 366);
            button2.Name = "button2";
            button2.Size = new Size(394, 46);
            button2.TabIndex = 3;
            button2.Text = "Masuk";
            button2.UseVisualStyleBackColor = false;
            button2.Click += button2_Click;
            // 
            // lblFooter
            // 
            lblFooter.AutoSize = true;
            lblFooter.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblFooter.ForeColor = Color.Gray;
            lblFooter.Location = new Point(29, 437);
            lblFooter.Name = "lblFooter";
            lblFooter.Size = new Size(219, 15);
            lblFooter.TabIndex = 8;
            lblFooter.Text = "© SMK MART - Sistem Manajemen Toko";
            lblFooter.Click += lblFooter_Click;
            // 
            // FormLogin
            // 
            AcceptButton = button2;
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.Navy;
            ClientSize = new Size(900, 481);
            Controls.Add(tableLayoutPanel1);
            MinimumSize = new Size(780, 520);
            Name = "FormLogin";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Login - SMK MART";
            WindowState = FormWindowState.Maximized;
            tableLayoutPanel1.ResumeLayout(false);
            panelKanan.ResumeLayout(false);
            panel2.ResumeLayout(false);
            panel2.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private TableLayoutPanel tableLayoutPanel1;
        private Panel panelBrand;
        private Panel panelKanan;
        private Panel panel2;
        private Label label9;
        private Label lblSub;
        private Label label8;
        private ReaLTaiizor.Controls.HopeTextBox hopeTextBox1;
        private Label label7;
        private ReaLTaiizor.Controls.HopeTextBox hopeTextBox2;
        private CheckBox chkTampilkan;
        private Button button2;
        private Label lblFooter;
    }
}
