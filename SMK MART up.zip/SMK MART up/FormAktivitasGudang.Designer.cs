﻿namespace SMK_MART
{
    partial class FormAktivitasGudang
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            DataGridViewCellStyle dataGridViewCellStyle1 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle2 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle3 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle4 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle5 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle6 = new DataGridViewCellStyle();
            panelAtas = new Panel();
            parrotButton3 = new ReaLTaiizor.Controls.ParrotButton();
            parrotButton4 = new ReaLTaiizor.Controls.ParrotButton();
            label3 = new Label();
            tlpUtama = new TableLayoutPanel();
            panelFilter = new Panel();
            label1 = new Label();
            lblDari = new Label();
            lblSampai = new Label();
            lblCari = new Label();
            dateTimePicker1 = new DateTimePicker();
            dateTimePicker2 = new DateTimePicker();
            txtCari = new TextBox();
            btnReset = new ReaLTaiizor.Controls.ParrotButton();
            btnMuatUlang = new ReaLTaiizor.Controls.ParrotButton();
            tlpData = new TableLayoutPanel();
            panelMasuk = new Panel();
            gridMasuk = new DataGridView();
            lblRingkasMasuk = new Label();
            label2 = new Label();
            panelKeluar = new Panel();
            gridKeluar = new DataGridView();
            lblRingkasKeluar = new Label();
            label4 = new Label();
            panelAtas.SuspendLayout();
            tlpUtama.SuspendLayout();
            panelFilter.SuspendLayout();
            tlpData.SuspendLayout();
            panelMasuk.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)gridMasuk).BeginInit();
            panelKeluar.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)gridKeluar).BeginInit();
            SuspendLayout();
            // 
            // panelAtas
            // 
            panelAtas.BackColor = Color.Navy;
            panelAtas.Controls.Add(parrotButton3);
            panelAtas.Controls.Add(parrotButton4);
            panelAtas.Controls.Add(label3);
            panelAtas.Dock = DockStyle.Top;
            panelAtas.Location = new Point(0, 0);
            panelAtas.Name = "panelAtas";
            panelAtas.Size = new Size(1100, 58);
            panelAtas.TabIndex = 0;
            // 
            // parrotButton3
            // 
            parrotButton3.BackgroundColor = Color.Gold;
            parrotButton3.ButtonImage = null;
            parrotButton3.ButtonStyle = ReaLTaiizor.Controls.ParrotButton.Style.MaterialRounded;
            parrotButton3.ButtonText = "Kembali";
            parrotButton3.ClickBackColor = Color.FromArgb(195, 195, 195);
            parrotButton3.ClickTextColor = Color.DodgerBlue;
            parrotButton3.CornerRadius = 6;
            parrotButton3.Cursor = Cursors.Hand;
            parrotButton3.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            parrotButton3.Horizontal_Alignment = StringAlignment.Center;
            parrotButton3.HoverBackgroundColor = Color.FromArgb(225, 225, 225);
            parrotButton3.HoverTextColor = Color.DodgerBlue;
            parrotButton3.ImagePosition = ReaLTaiizor.Controls.ParrotButton.ImgPosition.Left;
            parrotButton3.Location = new Point(14, 10);
            parrotButton3.Name = "parrotButton3";
            parrotButton3.Size = new Size(100, 38);
            parrotButton3.SmoothingType = System.Drawing.Drawing2D.SmoothingMode.HighQuality;
            parrotButton3.TabIndex = 0;
            parrotButton3.TextColor = Color.Black;
            parrotButton3.TextRenderingType = System.Drawing.Text.TextRenderingHint.ClearTypeGridFit;
            parrotButton3.Vertical_Alignment = StringAlignment.Center;
            // 
            // parrotButton4
            // 
            parrotButton4.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            parrotButton4.BackgroundColor = Color.Gold;
            parrotButton4.ButtonImage = null;
            parrotButton4.ButtonStyle = ReaLTaiizor.Controls.ParrotButton.Style.MaterialRounded;
            parrotButton4.ButtonText = "Log out";
            parrotButton4.ClickBackColor = Color.FromArgb(195, 195, 195);
            parrotButton4.ClickTextColor = Color.DodgerBlue;
            parrotButton4.CornerRadius = 10;
            parrotButton4.Cursor = Cursors.Hand;
            parrotButton4.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            parrotButton4.Horizontal_Alignment = StringAlignment.Center;
            parrotButton4.HoverBackgroundColor = Color.FromArgb(225, 225, 225);
            parrotButton4.HoverTextColor = Color.DodgerBlue;
            parrotButton4.ImagePosition = ReaLTaiizor.Controls.ParrotButton.ImgPosition.Left;
            parrotButton4.Location = new Point(998, 10);
            parrotButton4.Name = "parrotButton4";
            parrotButton4.Size = new Size(88, 38);
            parrotButton4.SmoothingType = System.Drawing.Drawing2D.SmoothingMode.HighQuality;
            parrotButton4.TabIndex = 1;
            parrotButton4.TextColor = Color.Black;
            parrotButton4.TextRenderingType = System.Drawing.Text.TextRenderingHint.ClearTypeGridFit;
            parrotButton4.Vertical_Alignment = StringAlignment.Center;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI", 20.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label3.ForeColor = Color.Gold;
            label3.Location = new Point(126, 10);
            label3.Name = "label3";
            label3.Size = new Size(161, 37);
            label3.TabIndex = 2;
            label3.Text = "SMK MART";
            // 
            // tlpUtama
            // 
            tlpUtama.BackColor = Color.Gainsboro;
            tlpUtama.ColumnCount = 1;
            tlpUtama.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
            tlpUtama.Controls.Add(panelFilter, 0, 0);
            tlpUtama.Controls.Add(tlpData, 0, 1);
            tlpUtama.Dock = DockStyle.Fill;
            tlpUtama.Location = new Point(0, 58);
            tlpUtama.Name = "tlpUtama";
            tlpUtama.Padding = new Padding(15);
            tlpUtama.RowCount = 2;
            tlpUtama.RowStyles.Add(new RowStyle(SizeType.Absolute, 135F));
            tlpUtama.RowStyles.Add(new RowStyle(SizeType.Percent, 100F));
            tlpUtama.Size = new Size(1100, 592);
            tlpUtama.TabIndex = 1;
            // 
            // panelFilter
            // 
            panelFilter.BackColor = Color.White;
            panelFilter.Controls.Add(label1);
            panelFilter.Controls.Add(lblDari);
            panelFilter.Controls.Add(lblSampai);
            panelFilter.Controls.Add(lblCari);
            panelFilter.Controls.Add(dateTimePicker1);
            panelFilter.Controls.Add(dateTimePicker2);
            panelFilter.Controls.Add(txtCari);
            panelFilter.Controls.Add(btnReset);
            panelFilter.Controls.Add(btnMuatUlang);
            panelFilter.Dock = DockStyle.Fill;
            panelFilter.Location = new Point(15, 15);
            panelFilter.Margin = new Padding(0, 0, 0, 12);
            panelFilter.Name = "panelFilter";
            panelFilter.Size = new Size(1070, 123);
            panelFilter.TabIndex = 0;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI Semibold", 22F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.ForeColor = Color.FromArgb(5, 150, 105);
            label1.Location = new Point(14, 8);
            label1.Name = "label1";
            label1.Size = new Size(253, 41);
            label1.TabIndex = 0;
            label1.Text = "Aktivitas Gudang";
            // 
            // lblDari
            // 
            lblDari.AutoSize = true;
            lblDari.Font = new Font("Segoe UI", 9.75F);
            lblDari.ForeColor = Color.DimGray;
            lblDari.Location = new Point(16, 62);
            lblDari.Name = "lblDari";
            lblDari.Size = new Size(80, 17);
            lblDari.TabIndex = 1;
            lblDari.Text = "Dari tanggal";
            // 
            // lblSampai
            // 
            lblSampai.AutoSize = true;
            lblSampai.Font = new Font("Segoe UI", 9.75F);
            lblSampai.ForeColor = Color.DimGray;
            lblSampai.Location = new Point(206, 62);
            lblSampai.Name = "lblSampai";
            lblSampai.Size = new Size(99, 17);
            lblSampai.TabIndex = 2;
            lblSampai.Text = "Sampai tanggal";
            // 
            // lblCari
            // 
            lblCari.AutoSize = true;
            lblCari.Font = new Font("Segoe UI", 9.75F);
            lblCari.ForeColor = Color.DimGray;
            lblCari.Location = new Point(396, 62);
            lblCari.Name = "lblCari";
            lblCari.Size = new Size(163, 17);
            lblCari.TabIndex = 3;
            lblCari.Text = "Cari barang (kode / nama)";
            // 
            // dateTimePicker1
            // 
            dateTimePicker1.Font = new Font("Segoe UI", 11F, FontStyle.Regular, GraphicsUnit.Point, 0);
            dateTimePicker1.Format = DateTimePickerFormat.Short;
            dateTimePicker1.Location = new Point(16, 82);
            dateTimePicker1.Name = "dateTimePicker1";
            dateTimePicker1.Size = new Size(170, 27);
            dateTimePicker1.TabIndex = 4;
            // 
            // dateTimePicker2
            // 
            dateTimePicker2.Font = new Font("Segoe UI", 11F, FontStyle.Regular, GraphicsUnit.Point, 0);
            dateTimePicker2.Format = DateTimePickerFormat.Short;
            dateTimePicker2.Location = new Point(206, 82);
            dateTimePicker2.Name = "dateTimePicker2";
            dateTimePicker2.Size = new Size(170, 27);
            dateTimePicker2.TabIndex = 5;
            // 
            // txtCari
            // 
            txtCari.Font = new Font("Segoe UI", 11F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txtCari.Location = new Point(396, 82);
            txtCari.Name = "txtCari";
            txtCari.PlaceholderText = "Ketik kode atau nama barang";
            txtCari.Size = new Size(280, 27);
            txtCari.TabIndex = 6;
            // 
            // btnReset
            // 
            btnReset.BackgroundColor = Color.Gold;
            btnReset.ButtonImage = null;
            btnReset.ButtonStyle = ReaLTaiizor.Controls.ParrotButton.Style.MaterialRounded;
            btnReset.ButtonText = "Reset";
            btnReset.ClickBackColor = Color.FromArgb(195, 195, 195);
            btnReset.ClickTextColor = Color.DodgerBlue;
            btnReset.CornerRadius = 8;
            btnReset.Cursor = Cursors.Hand;
            btnReset.Font = new Font("Segoe UI", 11F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btnReset.Horizontal_Alignment = StringAlignment.Center;
            btnReset.HoverBackgroundColor = Color.FromArgb(225, 225, 225);
            btnReset.HoverTextColor = Color.DodgerBlue;
            btnReset.ImagePosition = ReaLTaiizor.Controls.ParrotButton.ImgPosition.Left;
            btnReset.Location = new Point(696, 74);
            btnReset.Name = "btnReset";
            btnReset.Size = new Size(100, 36);
            btnReset.SmoothingType = System.Drawing.Drawing2D.SmoothingMode.HighQuality;
            btnReset.TabIndex = 7;
            btnReset.TextColor = Color.Black;
            btnReset.TextRenderingType = System.Drawing.Text.TextRenderingHint.ClearTypeGridFit;
            btnReset.Vertical_Alignment = StringAlignment.Center;
            // 
            // btnMuatUlang
            // 
            btnMuatUlang.BackgroundColor = Color.Gold;
            btnMuatUlang.ButtonImage = null;
            btnMuatUlang.ButtonStyle = ReaLTaiizor.Controls.ParrotButton.Style.MaterialRounded;
            btnMuatUlang.ButtonText = "Muat ulang";
            btnMuatUlang.ClickBackColor = Color.FromArgb(195, 195, 195);
            btnMuatUlang.ClickTextColor = Color.DodgerBlue;
            btnMuatUlang.CornerRadius = 8;
            btnMuatUlang.Cursor = Cursors.Hand;
            btnMuatUlang.Font = new Font("Segoe UI", 11F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btnMuatUlang.Horizontal_Alignment = StringAlignment.Center;
            btnMuatUlang.HoverBackgroundColor = Color.FromArgb(225, 225, 225);
            btnMuatUlang.HoverTextColor = Color.DodgerBlue;
            btnMuatUlang.ImagePosition = ReaLTaiizor.Controls.ParrotButton.ImgPosition.Left;
            btnMuatUlang.Location = new Point(806, 74);
            btnMuatUlang.Name = "btnMuatUlang";
            btnMuatUlang.Size = new Size(120, 36);
            btnMuatUlang.SmoothingType = System.Drawing.Drawing2D.SmoothingMode.HighQuality;
            btnMuatUlang.TabIndex = 8;
            btnMuatUlang.TextColor = Color.Black;
            btnMuatUlang.TextRenderingType = System.Drawing.Text.TextRenderingHint.ClearTypeGridFit;
            btnMuatUlang.Vertical_Alignment = StringAlignment.Center;
            // 
            // tlpData
            // 
            tlpData.ColumnCount = 2;
            tlpData.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));
            tlpData.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));
            tlpData.Controls.Add(panelMasuk, 0, 0);
            tlpData.Controls.Add(panelKeluar, 1, 0);
            tlpData.Dock = DockStyle.Fill;
            tlpData.Location = new Point(15, 150);
            tlpData.Margin = new Padding(0);
            tlpData.Name = "tlpData";
            tlpData.RowCount = 1;
            tlpData.RowStyles.Add(new RowStyle(SizeType.Percent, 100F));
            tlpData.Size = new Size(1070, 427);
            tlpData.TabIndex = 1;
            // 
            // panelMasuk
            // 
            panelMasuk.BackColor = Color.White;
            panelMasuk.Controls.Add(gridMasuk);
            panelMasuk.Controls.Add(lblRingkasMasuk);
            panelMasuk.Controls.Add(label2);
            panelMasuk.Dock = DockStyle.Fill;
            panelMasuk.Location = new Point(0, 0);
            panelMasuk.Margin = new Padding(0, 0, 6, 0);
            panelMasuk.Name = "panelMasuk";
            panelMasuk.Size = new Size(529, 427);
            panelMasuk.TabIndex = 0;
            // 
            // gridMasuk
            // 
            gridMasuk.AllowUserToAddRows = false;
            gridMasuk.AllowUserToDeleteRows = false;
            gridMasuk.AllowUserToResizeRows = false;
            dataGridViewCellStyle1.BackColor = Color.FromArgb(245, 247, 255);
            gridMasuk.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            gridMasuk.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            gridMasuk.BackgroundColor = Color.White;
            gridMasuk.BorderStyle = BorderStyle.None;
            gridMasuk.CellBorderStyle = DataGridViewCellBorderStyle.SingleHorizontal;
            gridMasuk.ColumnHeadersBorderStyle = DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle2.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = Color.Navy;
            dataGridViewCellStyle2.Font = new Font("Segoe UI", 10F, FontStyle.Bold, GraphicsUnit.Point, 0);
            dataGridViewCellStyle2.ForeColor = Color.White;
            dataGridViewCellStyle2.SelectionBackColor = Color.Navy;
            dataGridViewCellStyle2.SelectionForeColor = Color.White;
            gridMasuk.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            gridMasuk.ColumnHeadersHeight = 36;
            gridMasuk.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            dataGridViewCellStyle3.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = Color.White;
            dataGridViewCellStyle3.Font = new Font("Segoe UI", 10F, FontStyle.Regular, GraphicsUnit.Point, 0);
            dataGridViewCellStyle3.ForeColor = Color.FromArgb(40, 40, 40);
            dataGridViewCellStyle3.SelectionBackColor = Color.FromArgb(220, 228, 255);
            dataGridViewCellStyle3.SelectionForeColor = Color.Black;
            dataGridViewCellStyle3.WrapMode = DataGridViewTriState.False;
            gridMasuk.DefaultCellStyle = dataGridViewCellStyle3;
            gridMasuk.Dock = DockStyle.Fill;
            gridMasuk.EnableHeadersVisualStyles = false;
            gridMasuk.GridColor = Color.FromArgb(230, 230, 235);
            gridMasuk.Location = new Point(0, 72);
            gridMasuk.MultiSelect = false;
            gridMasuk.Name = "gridMasuk";
            gridMasuk.ReadOnly = true;
            gridMasuk.RowHeadersVisible = false;
            gridMasuk.RowTemplate.Height = 32;
            gridMasuk.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            gridMasuk.Size = new Size(529, 355);
            gridMasuk.TabIndex = 2;
            // 
            // lblRingkasMasuk
            // 
            lblRingkasMasuk.Dock = DockStyle.Top;
            lblRingkasMasuk.Font = new Font("Segoe UI", 9.75F);
            lblRingkasMasuk.ForeColor = Color.DimGray;
            lblRingkasMasuk.Location = new Point(0, 44);
            lblRingkasMasuk.Name = "lblRingkasMasuk";
            lblRingkasMasuk.Padding = new Padding(14, 0, 0, 0);
            lblRingkasMasuk.Size = new Size(529, 28);
            lblRingkasMasuk.TabIndex = 3;
            lblRingkasMasuk.TextAlign = ContentAlignment.MiddleLeft;
            // 
            // label2
            // 
            label2.Dock = DockStyle.Top;
            label2.Font = new Font("Segoe UI Semibold", 15.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label2.ForeColor = Color.Navy;
            label2.Location = new Point(0, 0);
            label2.Name = "label2";
            label2.Padding = new Padding(14, 0, 0, 0);
            label2.Size = new Size(529, 44);
            label2.TabIndex = 4;
            label2.Text = "Barang Masuk";
            label2.TextAlign = ContentAlignment.MiddleLeft;
            // 
            // panelKeluar
            // 
            panelKeluar.BackColor = Color.White;
            panelKeluar.Controls.Add(gridKeluar);
            panelKeluar.Controls.Add(lblRingkasKeluar);
            panelKeluar.Controls.Add(label4);
            panelKeluar.Dock = DockStyle.Fill;
            panelKeluar.Location = new Point(541, 0);
            panelKeluar.Margin = new Padding(6, 0, 0, 0);
            panelKeluar.Name = "panelKeluar";
            panelKeluar.Size = new Size(529, 427);
            panelKeluar.TabIndex = 1;
            // 
            // gridKeluar
            // 
            gridKeluar.AllowUserToAddRows = false;
            gridKeluar.AllowUserToDeleteRows = false;
            gridKeluar.AllowUserToResizeRows = false;
            dataGridViewCellStyle4.BackColor = Color.White;
            gridKeluar.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle4;
            gridKeluar.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            gridKeluar.BackgroundColor = Color.White;
            gridKeluar.BorderStyle = BorderStyle.None;
            gridKeluar.CellBorderStyle = DataGridViewCellBorderStyle.SingleHorizontal;
            gridKeluar.ColumnHeadersBorderStyle = DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle5.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle5.BackColor = Color.FromArgb(255, 128, 0);
            dataGridViewCellStyle5.Font = new Font("Segoe UI", 10F, FontStyle.Bold, GraphicsUnit.Point, 0);
            dataGridViewCellStyle5.ForeColor = Color.White;
            dataGridViewCellStyle5.SelectionBackColor = Color.FromArgb(255, 128, 0);
            dataGridViewCellStyle5.SelectionForeColor = Color.White;
            gridKeluar.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle5;
            gridKeluar.ColumnHeadersHeight = 36;
            gridKeluar.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            dataGridViewCellStyle6.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle6.BackColor = Color.White;
            dataGridViewCellStyle6.Font = new Font("Segoe UI", 10F, FontStyle.Regular, GraphicsUnit.Point, 0);
            dataGridViewCellStyle6.ForeColor = Color.FromArgb(40, 40, 40);
            dataGridViewCellStyle6.SelectionBackColor = Color.FromArgb(220, 228, 255);
            dataGridViewCellStyle6.SelectionForeColor = Color.Black;
            dataGridViewCellStyle6.WrapMode = DataGridViewTriState.False;
            gridKeluar.DefaultCellStyle = dataGridViewCellStyle6;
            gridKeluar.Dock = DockStyle.Fill;
            gridKeluar.EnableHeadersVisualStyles = false;
            gridKeluar.GridColor = Color.FromArgb(230, 230, 235);
            gridKeluar.Location = new Point(0, 72);
            gridKeluar.MultiSelect = false;
            gridKeluar.Name = "gridKeluar";
            gridKeluar.ReadOnly = true;
            gridKeluar.RowHeadersVisible = false;
            gridKeluar.RowTemplate.Height = 32;
            gridKeluar.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            gridKeluar.Size = new Size(529, 355);
            gridKeluar.TabIndex = 2;
            // 
            // lblRingkasKeluar
            // 
            lblRingkasKeluar.Dock = DockStyle.Top;
            lblRingkasKeluar.Font = new Font("Segoe UI", 9.75F);
            lblRingkasKeluar.ForeColor = Color.DimGray;
            lblRingkasKeluar.Location = new Point(0, 44);
            lblRingkasKeluar.Name = "lblRingkasKeluar";
            lblRingkasKeluar.Padding = new Padding(14, 0, 0, 0);
            lblRingkasKeluar.Size = new Size(529, 28);
            lblRingkasKeluar.TabIndex = 3;
            lblRingkasKeluar.TextAlign = ContentAlignment.MiddleLeft;
            // 
            // label4
            // 
            label4.Dock = DockStyle.Top;
            label4.Font = new Font("Segoe UI Semibold", 15.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label4.ForeColor = Color.FromArgb(255, 128, 0);
            label4.Location = new Point(0, 0);
            label4.Name = "label4";
            label4.Padding = new Padding(14, 0, 0, 0);
            label4.Size = new Size(529, 44);
            label4.TabIndex = 4;
            label4.Text = "Barang Keluar";
            label4.TextAlign = ContentAlignment.MiddleLeft;
            // 
            // FormAktivitasGudang
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.White;
            ClientSize = new Size(1100, 650);
            Controls.Add(tlpUtama);
            Controls.Add(panelAtas);
            MinimumSize = new Size(900, 520);
            Name = "FormAktivitasGudang";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Aktivitas Gudang - SMK MART";
            WindowState = FormWindowState.Maximized;
            panelAtas.ResumeLayout(false);
            panelAtas.PerformLayout();
            tlpUtama.ResumeLayout(false);
            panelFilter.ResumeLayout(false);
            panelFilter.PerformLayout();
            tlpData.ResumeLayout(false);
            panelMasuk.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)gridMasuk).EndInit();
            panelKeluar.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)gridKeluar).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private Panel panelAtas;
        private ReaLTaiizor.Controls.ParrotButton parrotButton3;
        private ReaLTaiizor.Controls.ParrotButton parrotButton4;
        private Label label3;
        private TableLayoutPanel tlpUtama;
        private Panel panelFilter;
        private Label label1;
        private Label lblDari;
        private Label lblSampai;
        private Label lblCari;
        private DateTimePicker dateTimePicker1;
        private DateTimePicker dateTimePicker2;
        private TextBox txtCari;
        private ReaLTaiizor.Controls.ParrotButton btnReset;
        private ReaLTaiizor.Controls.ParrotButton btnMuatUlang;
        private TableLayoutPanel tlpData;
        private Panel panelMasuk;
        private Label label2;
        private Label lblRingkasMasuk;
        private DataGridView gridMasuk;
        private Panel panelKeluar;
        private Label label4;
        private Label lblRingkasKeluar;
        private DataGridView gridKeluar;
    }
}
