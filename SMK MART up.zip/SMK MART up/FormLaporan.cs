﻿using System.Globalization;

namespace SMK_MART
{
    public partial class FormLaporan : Form
    {
        // ==========================================
        // DATA & FILE (tanpa DataStore)
        // ==========================================
        private class TransaksiData
        {
            public string Waktu = "";
            public string Nama = "";
            public string Kode = "";
            public int Jumlah;
            public int Total;
        }

        private class BarangData
        {
            public string Kode = "";
            public int Harga;       // harga jual
            public int HargaBeli;   // harga beli (modal)
        }

        private readonly string folder = Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.UserProfile),
            @"Downloads\Ngoding\Pyhton SMK MART");

        // Data yang sudah dibaca disimpan; file hanya dibaca ulang jika isinya berubah
        private List<TransaksiData>? cacheTransaksi;
        private string tandaTransaksi = "";
        private List<BarangData>? cacheBarang;
        private string tandaBarang = "";

        // Menggabungkan beberapa perubahan tanggal beruntun menjadi satu kali muat laporan
        private readonly System.Windows.Forms.Timer timerMuat = new() { Interval = 150 };

        // Format waktu di transaksi.txt: Python menulis "HH:mm:ss"; Windows berbahasa Indonesia
        // bisa menulis "HH.mm.ss". Keduanya dibaca di sini.
        private static readonly string[] FormatWaktu = { "yyyy-MM-dd HH:mm:ss", "yyyy-MM-dd HH.mm.ss" };

        public FormLaporan()
        {
            InitializeComponent();

            parrotButton1.Click += LogOut_Click;
            parrotButton2.Click += LogOut_Click;
            parrotButton3.Click += Kembali_Click;

            // Ganti tanggal awal / akhir -> laporan penjualan ikut berubah
            dateTimePicker1.ValueChanged += dateTimePicker1_ValueChanged;
            dateTimePicker1.CloseUp += dateTimePicker1_ValueChanged;
            dtpSampai.ValueChanged += dtpSampai_ValueChanged;
            dtpSampai.CloseUp += dtpSampai_ValueChanged;

            timerMuat.Tick += (s, e) =>
            {
                timerMuat.Stop();
                MuatPenjualan();
            };
            FormClosed += (s, e) => timerMuat.Dispose();

            AktifkanDoubleBuffer(gridKeranjang);
        }

        private void JadwalkanMuat()
        {
            timerMuat.Stop();
            timerMuat.Start();
        }

        // ==========================================
        // BANTUAN TABEL (supaya cepat)
        // ==========================================
        // Menggambar tabel lewat buffer ganda: scroll dan muat ulang lebih halus
        private static void AktifkanDoubleBuffer(DataGridView tabel)
        {
            typeof(DataGridView).GetProperty("DoubleBuffered",
                System.Reflection.BindingFlags.Instance | System.Reflection.BindingFlags.NonPublic)
                ?.SetValue(tabel, true);
        }

        private static DataGridViewRow BuatBaris(DataGridView tabel, params object[] nilai)
        {
            var baris = new DataGridViewRow();
            baris.CreateCells(tabel, nilai);
            return baris;
        }

        // Mengisi tabel sekaligus: jauh lebih cepat daripada Rows.Add satu per satu
        private static void IsiTabel(DataGridView tabel, List<DataGridViewRow> isi)
        {
            tabel.SuspendLayout();
            tabel.Rows.Clear();
            tabel.Rows.AddRange(isi.ToArray());
            tabel.ResumeLayout();
        }

        // Mencegah pemuatan berulang saat satu tanggal disesuaikan otomatis oleh tanggal lainnya
        private bool sedangMenyesuaikan = false;

        // Baca semua baris file dengan jumlah kolom tertentu (dipisah "|")
        private List<string[]> BacaBaris(string namaFile, int jumlahKolom) =>
            BacaBaris(namaFile, jumlahKolom, jumlahKolom);

        // Versi untuk file yang boleh punya jumlah kolom antara minKolom dan maxKolom
        private List<string[]> BacaBaris(string namaFile, int minKolom, int maxKolom)
        {
            var hasil = new List<string[]>();
            string path = Path.Combine(folder, namaFile);
            if (!File.Exists(path)) return hasil;

            try
            {
                // FileShare.ReadWrite supaya tetap bisa dibaca saat Python sedang menulis
                using var fs = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.ReadWrite);
                using var sr = new StreamReader(fs);
                string? baris;
                while ((baris = sr.ReadLine()) != null)
                {
                    string[] d = baris.Trim().Split('|');
                    if (d.Length >= minKolom && d.Length <= maxKolom) hasil.Add(d);
                }
            }
            catch (IOException) { }

            return hasil;
        }

        // barang.txt (kode|nama|harga_beli|harga_jual|stok|status)
        private List<BarangData> BacaBarang()
        {
            var hasil = new List<BarangData>();
            foreach (string[] d in BacaBaris("barang.txt", 6))
            {
                if (TryBacaBarang(d, out string kode, out _, out int hargaBeli, out int harga, out _, out _))
                    hasil.Add(new BarangData { Kode = kode, Harga = harga, HargaBeli = hargaBeli });
            }
            return hasil;
        }

        // Format barang.txt (hanya satu format): kode|nama|harga_beli|harga_jual|stok|status
        private static bool TryBacaBarang(string[] d, out string kode, out string nama,
            out int hargaBeli, out int harga, out int stok, out string status)
        {
            kode = nama = status = "";
            hargaBeli = harga = stok = 0;

            if (d.Length != 6) return false;

            kode = d[0];
            nama = d[1];
            status = d[5];

            return int.TryParse(d[2], out hargaBeli)
                && int.TryParse(d[3], out harga)
                && int.TryParse(d[4], out stok)
                && AdalahStatus(status);
        }

        private static bool AdalahStatus(string teks) => teks == "aktif" || teks == "nonaktif";

        // transaksi.txt (waktu|nama|kode|jumlah|total)
        private List<TransaksiData> BacaTransaksi()
        {
            var hasil = new List<TransaksiData>();
            foreach (string[] d in BacaBaris("transaksi.txt", 5))
            {
                if (int.TryParse(d[3], out int jumlah) && int.TryParse(d[4], out int total))
                    hasil.Add(new TransaksiData { Waktu = d[0], Nama = d[1], Kode = d[2], Jumlah = jumlah, Total = total });
            }
            return hasil;
        }

        // Waktu ubah + ukuran file: berubah jika isi file berubah
        private string TandaFile(string namaFile)
        {
            try
            {
                var info = new FileInfo(Path.Combine(folder, namaFile));
                return info.Exists ? info.LastWriteTimeUtc.Ticks + ":" + info.Length : "";
            }
            catch (IOException) { return ""; }
        }

        private List<TransaksiData> AmbilTransaksi()
        {
            string tanda = TandaFile("transaksi.txt");
            if (cacheTransaksi == null || tanda != tandaTransaksi)
            {
                cacheTransaksi = BacaTransaksi();
                tandaTransaksi = tanda;
            }
            return cacheTransaksi;
        }

        private List<BarangData> AmbilBarang()
        {
            string tanda = TandaFile("barang.txt");
            if (cacheBarang == null || tanda != tandaBarang)
            {
                cacheBarang = BacaBarang();
                tandaBarang = tanda;
            }
            return cacheBarang;
        }

        private bool AdaFile(string namaFile) =>
            File.Exists(Path.Combine(folder, namaFile));

        private static bool TryParseWaktu(string teks, out DateTime waktu) =>
            DateTime.TryParseExact(teks, FormatWaktu, CultureInfo.InvariantCulture, DateTimeStyles.None, out waktu);

        // ==========================================
        // TAMPILAN
        // ==========================================
        private void FormLaporan_Load(object sender, EventArgs e)
        {
            if (!Directory.Exists(folder))
            {
                MessageBox.Show("Folder data tidak ditemukan:\n" + folder,
                    "Peringatan", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }

            // Jika hari ini belum ada transaksi, tampilkan tanggal transaksi terakhir
            try
            {
                bool adaHariIni = false;
                DateTime? terakhir = null;
                foreach (TransaksiData t in AmbilTransaksi())
                {
                    if (!TryParseWaktu(t.Waktu, out DateTime w)) continue;
                    if (w.Date == DateTime.Today) adaHariIni = true;
                    if (terakhir == null || w > terakhir) terakhir = w;
                }

                if (!adaHariIni && terakhir != null)
                {
                    sedangMenyesuaikan = true;
                    dateTimePicker1.Value = terakhir.Value.Date;
                    dtpSampai.Value = terakhir.Value.Date;
                    sedangMenyesuaikan = false;
                }
            }
            catch (Exception) { }

            MuatPenjualan();
        }

        // ==========================================
        // LAPORAN PENJUALAN (rentang tanggal: dari - sampai)
        // ==========================================
        private void dateTimePicker1_ValueChanged(object? sender, EventArgs e)
        {
            if (sedangMenyesuaikan) return;

            // Tanggal awal tidak boleh melewati tanggal akhir
            if (dateTimePicker1.Value.Date > dtpSampai.Value.Date)
            {
                sedangMenyesuaikan = true;
                dtpSampai.Value = dateTimePicker1.Value;
                sedangMenyesuaikan = false;
            }

            JadwalkanMuat();
        }

        private void dtpSampai_ValueChanged(object? sender, EventArgs e)
        {
            if (sedangMenyesuaikan) return;

            // Tanggal akhir tidak boleh sebelum tanggal awal
            if (dtpSampai.Value.Date < dateTimePicker1.Value.Date)
            {
                sedangMenyesuaikan = true;
                dateTimePicker1.Value = dtpSampai.Value;
                sedangMenyesuaikan = false;
            }

            JadwalkanMuat();
        }

        // Baris pesan di tabel penjualan (ditaruh di kolom Barang yang lebar, boleh turun baris)
        private void TambahPesan(List<DataGridViewRow> isi, string pesan)
        {
            DataGridViewRow baris = BuatBaris(gridKeranjang, "", pesan, "", "");
            baris.Cells[1].Style.WrapMode = DataGridViewTriState.True;
            isi.Add(baris);
        }

        private static string FormatTanggal(DateTime tanggal) =>
            tanggal.ToString("yyyy-MM-dd", CultureInfo.InvariantCulture);

        private void MuatPenjualan()
        {
            var isi = new List<DataGridViewRow>();

            try
            {
                // Kartu laba dikosongkan dulu; diisi lagi jika ada transaksi pada rentang ini
                TampilkanLaba(new List<TransaksiData>());
                BuatLaporanPenjualan(isi);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Gagal memuat laporan penjualan:\n" + ex.Message,
                    "Peringatan", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }

            // Tabel diisi sekaligus (sekali gambar), bukan baris demi baris
            IsiTabel(gridKeranjang, isi);
        }

        // Menyusun baris laporan penjualan untuk rentang tanggal yang dipilih
        private void BuatLaporanPenjualan(List<DataGridViewRow> isi)
        {
            DateTime awal = dateTimePicker1.Value.Date;
            DateTime akhir = dtpSampai.Value.Date;

            List<TransaksiData> semua = AmbilTransaksi();

            if (!AdaFile("transaksi.txt"))
            {
                TambahPesan(isi, "File transaksi.txt tidak ditemukan");
                return;
            }

            if (semua.Count == 0)
            {
                TambahPesan(isi, "Belum ada transaksi");
                return;
            }

            // Transaksi yang waktunya bisa dibaca
            var dikenali = new List<(TransaksiData Data, DateTime Waktu)>();
            foreach (TransaksiData t in semua)
            {
                if (TryParseWaktu(t.Waktu, out DateTime w))
                    dikenali.Add((t, w));
            }

            if (dikenali.Count == 0)
            {
                TambahPesan(isi, "Format waktu di transaksi.txt tidak dikenali");
                TambahPesan(isi, "Contoh isi: " + semua[0].Waktu);
                return;
            }

            // Transaksi dalam rentang tanggal (termasuk tanggal awal dan akhir), urut waktu
            var dalamRentang = dikenali
                .Where(x => x.Waktu.Date >= awal && x.Waktu.Date <= akhir)
                .OrderBy(x => x.Waktu)
                .ToList();

            if (dalamRentang.Count == 0)
            {
                TambahPesan(isi, "Tidak ada transaksi pada rentang tanggal ini");
                TambahPesan(isi, $"Transaksi ada pada {FormatTanggal(dikenali.Min(x => x.Waktu))} s/d {FormatTanggal(dikenali.Max(x => x.Waktu))}");
                return;
            }

            // Kartu Penjualan, Modal, Laba, dan Margin untuk rentang tanggal yang sama
            TampilkanLaba(dalamRentang.Select(x => x.Data).ToList());

            long totalPenjualan = 0;
            foreach (var x in dalamRentang)
            {
                isi.Add(BuatBaris(gridKeranjang,
                    x.Waktu.ToString("dd/MM/yyyy", CultureInfo.InvariantCulture),
                    x.Data.Nama,
                    x.Data.Jumlah.ToString(),
                    "Rp" + x.Data.Total.ToString("N0")));
                totalPenjualan += x.Data.Total;
            }

            // Baris terakhir: total penjualan pada rentang tersebut
            isi.Add(BuatBaris(gridKeranjang, "", "Total penjualan", "", "Rp" + totalPenjualan.ToString("N0")));
        }

        // ==========================================
        // LAPORAN LABA (kartu di panel kanan)
        // Laba = Penjualan - Modal, Modal = harga beli x jumlah terjual
        // ==========================================
        private static string Rupiah(long nilai) =>
            (nilai < 0 ? "-Rp" : "Rp") + Math.Abs(nilai).ToString("N0");

        private void TampilkanLaba(List<TransaksiData> transaksi)
        {
            // Harga beli memakai data barang saat ini (barang.txt)
            var daftarBarang = new Dictionary<string, BarangData>();
            foreach (BarangData br in AmbilBarang())
                daftarBarang.TryAdd(br.Kode, br);

            long penjualan = 0;
            long modal = 0;
            int jumlahBarang = 0;
            var tanpaHargaBeli = new HashSet<string>();   // kode barang yang harga belinya belum terisi

            foreach (TransaksiData t in transaksi)
            {
                penjualan += t.Total;
                jumlahBarang += t.Jumlah;

                if (daftarBarang.TryGetValue(t.Kode, out BarangData? barang))
                {
                    modal += (long)barang.HargaBeli * t.Jumlah;
                    if (barang.HargaBeli == 0) tanpaHargaBeli.Add(t.Kode);
                }
                else
                {
                    // Barang tidak ada di barang.txt: modalnya tidak diketahui (dihitung 0) dan masuk peringatan
                    tanpaHargaBeli.Add(t.Kode);
                }
            }

            long laba = penjualan - modal;
            int jumlahTransaksi = transaksi.Select(t => t.Waktu).Distinct().Count();

            // Penjualan
            lblPenjualan.Text = Rupiah(penjualan);
            lblPenjualanKet.Text = transaksi.Count == 0
                ? "Tidak ada transaksi"
                : $"{jumlahTransaksi} transaksi\n{jumlahBarang} barang terjual";

            // Modal
            lblModal.Text = Rupiah(modal);
            if (tanpaHargaBeli.Count > 0)
            {
                lblModalKet.Text = $"(!) {tanpaHargaBeli.Count} barang belum ada harga beli";
                lblModalKet.ForeColor = Color.Firebrick;
            }
            else
            {
                lblModalKet.Text = "Harga beli x jumlah terjual";
                lblModalKet.ForeColor = Color.FromArgb(80, 80, 80);
            }

            // Laba (hijau jika untung, merah jika rugi)
            lblLaba.Text = Rupiah(laba);
            lblLaba.ForeColor = laba < 0 ? Color.Firebrick : Color.FromArgb(0, 110, 50);
            lblLabaKet.Text = laba < 0 ? "Rugi (Penjualan - Modal)" : "Penjualan - Modal";

            // Margin = laba dibagi penjualan
            lblMargin.Text = penjualan > 0
                ? (laba * 100.0 / penjualan).ToString("0.0", CultureInfo.InvariantCulture) + "%"
                : "0%";
            lblMargin.ForeColor = laba < 0 ? Color.Firebrick : Color.FromArgb(32, 32, 32);
            lblMarginKet.Text = "Laba / Penjualan";
        }

        // ==========================================
        // NAVIGASI
        // ==========================================
        private void Kembali_Click(object? sender, EventArgs e)
        {
            FormMenuAdmin halamanMenu = new FormMenuAdmin();
            halamanMenu.Show();
            this.Close();
        }

        private void LogOut_Click(object? sender, EventArgs e)
        {
            DialogResult konfirmasi = MessageBox.Show(
                "Apakah Anda yakin ingin Log out dari akun ini?",
                "Konfirmasi Log Out",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Question
            );

            if (konfirmasi == DialogResult.Yes)
            {
                FormLogin halamanLogin = new FormLogin();
                halamanLogin.Show();
                this.Close();
            }
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void poisonDataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void parrotButton4_Click(object sender, EventArgs e)
        {
            FormLogin halamanLogin = new FormLogin();
            halamanLogin.Show();
            this.Close();
        }

        private void lblPenjualanKet_Click(object sender, EventArgs e)
        {

        }
    }
}
