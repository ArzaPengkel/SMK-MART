﻿namespace SMK_MART
{
    public partial class FormTransaksi : Form
    {
        // ==========================================
        // DATA & FILE (tanpa DataStore)
        // ==========================================
        private class BarangData
        {
            public string Kode = "";
            public string Nama = "";
            public int Harga;
            public int HargaBeli;
            public int Stok;
            public string Status = "aktif";
        }

        private class ItemBeli
        {
            public string Kode = "";
            public string Nama = "";
            public int Harga;
            public int Jumlah;
            public int Subtotal => Harga * Jumlah;
        }

        private readonly string folder = Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.UserProfile),
            @"Downloads\Ngoding\Pyhton SMK MART");

        private string FileBarang => Path.Combine(folder, "barang.txt");

        // Baris barang.txt yang formatnya salah pada pembacaan terakhir (dicatat agar tidak hilang saat menyimpan)
        private int barisSalah = 0;
        private string contohBarisSalah = "";
        private string FileTransaksi => Path.Combine(folder, "transaksi.txt");

        private readonly List<ItemBeli> keranjang = new();

        public FormTransaksi()
        {
            InitializeComponent();
        }

        // Baca barang.txt (format: kode|nama|harga_beli|harga_jual|stok|status)
        private List<BarangData> BacaBarang()
        {
            var hasil = new List<BarangData>();
            barisSalah = 0;
            contohBarisSalah = "";
            if (!File.Exists(FileBarang)) return hasil;

            try
            {
                using var fs = new FileStream(FileBarang, FileMode.Open, FileAccess.Read, FileShare.ReadWrite);
                using var sr = new StreamReader(fs);
                string? baris;
                while ((baris = sr.ReadLine()) != null)
                {
                    string teks = baris.Trim();
                    if (teks == "") continue;

                    string[] d = teks.Split('|');
                    if (TryBacaBarang(d, out string kode, out string nama, out int hargaBeli, out int harga, out int stok, out string status))
                    {
                        hasil.Add(new BarangData { Kode = kode, Nama = nama, Harga = harga, HargaBeli = hargaBeli, Stok = stok, Status = status });
                    }
                    else
                    {
                        barisSalah++;
                        if (contohBarisSalah == "") contohBarisSalah = teks;
                    }
                }
            }
            catch (IOException) { }

            return hasil;
        }

        // Format barang.txt (hanya satu format): kode|nama|harga_beli|harga_jual|stok|status
        private static bool TryBacaBarang(string[] d, out string kode, out string nama,
            out int hargaBeli, out int harga, out int stok, out string status)
        {
            kode = nama = status = "";
            hargaBeli = harga = stok = 0;

            if (d.Length != 6) return false;

            kode = d[0];
            nama = d[1];
            status = d[5];

            return int.TryParse(d[2], out hargaBeli)
                && int.TryParse(d[3], out harga)
                && int.TryParse(d[4], out stok)
                && AdalahStatus(status);
        }

        private static bool AdalahStatus(string teks) => teks == "aktif" || teks == "nonaktif";

        private void SimpanBarang(List<BarangData> daftar)
        {
            // Jangan menimpa file jika ada baris yang formatnya salah: baris itu akan hilang
            if (barisSalah > 0)
                throw new IOException($"barang.txt punya {barisSalah} baris dengan format salah, contoh: {contohBarisSalah}\n" +
                    "Format yang benar: kode|nama|harga_beli|harga_jual|stok|status\n" +
                    "Perbaiki dulu file-nya agar data tidak hilang.");

            Directory.CreateDirectory(folder);
            File.WriteAllLines(FileBarang,
                daftar.Select(b => $"{b.Kode}|{b.Nama}|{b.HargaBeli}|{b.Harga}|{b.Stok}|{b.Status}"));
        }

        // Kode harus persis (B001); nama barang boleh huruf besar/kecil
        private static BarangData? CariBarang(List<BarangData> daftar, string kodeAtauNama)
        {
            string kunci = kodeAtauNama.Trim();
            return daftar.FirstOrDefault(b => b.Kode == kunci)
                ?? daftar.FirstOrDefault(b => b.Nama.Equals(kunci, StringComparison.OrdinalIgnoreCase));
        }

        // Tambah baris ke transaksi.txt (format: waktu|nama|kode|jumlah|total)
        // Hanya menambah di akhir file, tidak membaca dan menulis ulang seluruh file,
        // jadi tetap cepat walaupun riwayat transaksi sudah banyak.
        private void SimpanTransaksi(string waktu)
        {
            Directory.CreateDirectory(folder);

            // Pastikan baris baru tidak menempel di baris terakhir jika file tidak berakhir dengan newline
            bool perluBarisBaru = false;
            if (File.Exists(FileTransaksi))
            {
                using var fs = new FileStream(FileTransaksi, FileMode.Open, FileAccess.Read, FileShare.ReadWrite);
                if (fs.Length > 0)
                {
                    fs.Seek(-1, SeekOrigin.End);
                    perluBarisBaru = fs.ReadByte() != '\n';
                }
            }

            using var sw = new StreamWriter(FileTransaksi, append: true);
            if (perluBarisBaru) sw.WriteLine();

            foreach (ItemBeli item in keranjang)
                sw.WriteLine($"{waktu}|{item.Nama}|{item.Kode}|{item.Jumlah}|{item.Subtotal}");
        }

        // ==========================================
        // KERANJANG
        // ==========================================
        private static string Rp(int angka) => "Rp" + angka.ToString("N0");

        private int TotalBelanja() => keranjang.Sum(i => i.Subtotal);

        private void MuatKeranjang()
        {
            gridKeranjang.Rows.Clear();
            foreach (ItemBeli item in keranjang)
                gridKeranjang.Rows.Add(item.Nama, item.Jumlah.ToString(), Rp(item.Subtotal));

            lblTotal.Text = Rp(TotalBelanja());
            HitungKembalian();
        }

        private void HitungKembalian()
        {
            int total = TotalBelanja();

            if (!int.TryParse(txtUangBayar.Text.Trim(), out int bayar))
                lblKembalian.Text = "Kembalian: Rp0";
            else if (bayar < total)
                lblKembalian.Text = "Uang kurang: " + Rp(total - bayar);
            else
                lblKembalian.Text = "Kembalian: " + Rp(bayar - total);
        }

        private void Peringatan(string pesan) =>
            MessageBox.Show(pesan, "Peringatan", MessageBoxButtons.OK, MessageBoxIcon.Warning);

        // Tombol "Tambah": masukkan barang (kode atau nama) ke keranjang
        private void btnTambah_Click(object? sender, EventArgs e)
        {
            string kodeAtauNama = hopeTextBox1.Text.Trim();
            if (kodeAtauNama == "")
            {
                Peringatan("Masukkan kode atau nama barang.");
                return;
            }

            if (!int.TryParse(txtJumlah.Text.Trim(), out int jumlah))
            {
                Peringatan("Jumlah harus berupa angka.");
                return;
            }

            BarangData? barang = CariBarang(BacaBarang(), kodeAtauNama);
            if (barang == null || barang.Status != "aktif")
            {
                Peringatan("Barang tidak ditemukan atau sudah nonaktif.");
                return;
            }

            if (jumlah <= 0)
            {
                Peringatan("Jumlah tidak valid.");
                return;
            }

            int sudahDiKeranjang = keranjang.Where(i => i.Kode == barang.Kode).Sum(i => i.Jumlah);
            if (jumlah > barang.Stok - sudahDiKeranjang)
            {
                Peringatan("Stok tidak mencukupi.");
                return;
            }

            keranjang.Add(new ItemBeli
            {
                Kode = barang.Kode,
                Nama = barang.Nama,
                Harga = barang.Harga,
                Jumlah = jumlah
            });

            hopeTextBox1.Clear();
            txtJumlah.Text = "1";
            MuatKeranjang();
            hopeTextBox1.Focus();
        }

        private void txtUangBayar_TextChanged(object? sender, EventArgs e)
        {
            HitungKembalian();
        }

        // ==========================================
        // PEMBAYARAN
        // ==========================================
        // Tombol "Bayar dan cetak struk"
        private void btnBayar_Click(object? sender, EventArgs e)
        {
            if (keranjang.Count == 0)
            {
                Peringatan("Keranjang masih kosong.");
                return;
            }

            if (!int.TryParse(txtUangBayar.Text.Trim(), out int bayar))
            {
                Peringatan("Pembayaran harus berupa angka.");
                return;
            }

            int total = TotalBelanja();
            if (bayar < total)
            {
                Peringatan("Uang kurang, silakan masukkan jumlah yang pas/lebih.");
                return;
            }

            // Pastikan stok masih cukup (barang.txt bisa berubah dari Python)
            List<BarangData> daftar = BacaBarang();
            foreach (ItemBeli item in keranjang)
            {
                BarangData? barang = daftar.FirstOrDefault(b => b.Kode == item.Kode);
                int butuh = keranjang.Where(i => i.Kode == item.Kode).Sum(i => i.Jumlah);
                if (barang == null || barang.Status != "aktif" || butuh > barang.Stok)
                {
                    Peringatan($"Stok {item.Nama} tidak mencukupi.");
                    return;
                }
            }

            string waktu = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss", System.Globalization.CultureInfo.InvariantCulture);
            int kembalian = bayar - total;

            try
            {
                foreach (ItemBeli item in keranjang)
                    daftar.First(b => b.Kode == item.Kode).Stok -= item.Jumlah;

                SimpanBarang(daftar);
                SimpanTransaksi(waktu);
            }
            catch (IOException ex)
            {
                Peringatan("Gagal menyimpan data: " + ex.Message);
                return;
            }

            TampilkanStruk(waktu, total, bayar, kembalian);

            MessageBox.Show($"Transaksi berhasil.\nKembalian: {Rp(kembalian)}", "Sukses",
                MessageBoxButtons.OK, MessageBoxIcon.Information);

            keranjang.Clear();
            txtUangBayar.Clear();
            MuatKeranjang();
        }

        // Tombol "Batal": kosongkan keranjang (stok baru berkurang saat transaksi selesai)
        private void btnBatal_Click(object? sender, EventArgs e)
        {
            if (keranjang.Count > 0)
            {
                DialogResult konfirmasi = MessageBox.Show(
                    "Batalkan transaksi ini?",
                    "Konfirmasi",
                    MessageBoxButtons.YesNo,
                    MessageBoxIcon.Question);

                if (konfirmasi != DialogResult.Yes) return;
            }

            keranjang.Clear();
            hopeTextBox1.Clear();
            txtJumlah.Text = "1";
            txtUangBayar.Clear();
            lblStruk.Text = "";
            MuatKeranjang();
        }

        // ==========================================
        // STRUK
        // ==========================================
        private const int LebarStruk = 26;

        private static string Rata(string kiri, string kanan)
        {
            int maks = LebarStruk - kanan.Length - 1;
            if (kiri.Length > maks) kiri = kiri.Substring(0, Math.Max(0, maks));
            return kiri.PadRight(LebarStruk - kanan.Length) + kanan;
        }

        private void TampilkanStruk(string waktu, int total, int bayar, int kembalian)
        {
            string garis = new string('-', LebarStruk);
            var baris = new List<string>
            {
                "SMK MART",
                waktu.Length >= 16 ? waktu.Substring(0, 16) : waktu,
                garis
            };

            foreach (ItemBeli item in keranjang)
                baris.Add(Rata($"{item.Nama} x{item.Jumlah}", item.Subtotal.ToString("N0")));

            baris.Add(garis);
            baris.Add(Rata("Total", total.ToString("N0")));
            baris.Add(Rata("Bayar", bayar.ToString("N0")));
            baris.Add(Rata("Kembali", kembalian.ToString("N0")));

            lblStruk.Text = string.Join(Environment.NewLine, baris);
        }

        // ==========================================
        // NAVIGASI
        // ==========================================
        private void parrotButton3_Click(object? sender, EventArgs e)
        {
            FormMenuAdmin halamanMenu = new FormMenuAdmin();
            halamanMenu.Show();
            this.Close();
        }

        private void parrotButton1_Click(object? sender, EventArgs e)
        {
            DialogResult konfirmasi = MessageBox.Show(
                "Apakah Anda yakin ingin Log out dari akun ini?",
                "Konfirmasi Log Out",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Question
            );

            if (konfirmasi == DialogResult.Yes)
            {
                FormLogin halamanLogin = new FormLogin();
                halamanLogin.Show();
                this.Close();
            }
        }
    }
}
