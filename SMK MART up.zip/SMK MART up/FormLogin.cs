﻿namespace SMK_MART
{
    public partial class FormLogin : Form
    {
        // ==========================================
        // DATA & FILE (tanpa DataStore)
        // ==========================================
        private class UserData
        {
            public string Id = "";
            public string Nama = "";
            public string Password = "";
            public string Posisi = "";
            public string Status = "aktif";
            public bool Aktif => Status == "aktif";
        }

        private readonly string folder = Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.UserProfile),
            @"Downloads\Ngoding\Pyhton SMK MART");

        private string FileUsers => Path.Combine(folder, "users.txt");

        public FormLogin()
        {
            InitializeComponent();
        }

        // Baca users.txt (format: id|nama|password|posisi|status; format lama tanpa status dianggap aktif)
        private List<UserData> BacaUsers()
        {
            var hasil = new List<UserData>();
            if (!File.Exists(FileUsers)) return hasil;

            try
            {
                using var fs = new FileStream(FileUsers, FileMode.Open, FileAccess.Read, FileShare.ReadWrite);
                using var sr = new StreamReader(fs);
                string? baris;
                while ((baris = sr.ReadLine()) != null)
                {
                    string[] d = baris.Trim().Split('|');
                    if (d.Length == 4 || d.Length == 5)
                        hasil.Add(new UserData
                        {
                            Id = d[0],
                            Nama = d[1],
                            Password = d[2],
                            Posisi = d[3],
                            Status = d.Length == 5 ? d[4] : "aktif"
                        });
                }
            }
            catch (IOException) { }

            return hasil;
        }

        private UserData? CariUser(string id, string password)
        {
            return BacaUsers().FirstOrDefault(u => u.Id == id.Trim() && u.Password == password.Trim());
        }










        // Latar gradien pada panel brand (kiri)
        private void panelBrand_Paint(object? sender, PaintEventArgs e)
        {
            if (panelBrand.Width <= 0 || panelBrand.Height <= 0) return;
            using var kuas = new System.Drawing.Drawing2D.LinearGradientBrush(
                panelBrand.ClientRectangle,
                Color.FromArgb(8, 12, 90),
                Color.FromArgb(41, 57, 178),
                45F);
            e.Graphics.FillRectangle(kuas, panelBrand.ClientRectangle);
        }

        private void panelBrand_Resize(object? sender, EventArgs e) => panelBrand.Invalidate();

        private void chkTampilkan_CheckedChanged(object? sender, EventArgs e)
        {
            hopeTextBox2.UseSystemPasswordChar = !chkTampilkan.Checked;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            // 1. Cek kolom kosong
            if (string.IsNullOrWhiteSpace(hopeTextBox1.Text) || string.IsNullOrWhiteSpace(hopeTextBox2.Text))
            {
                MessageBox.Show("ID user dan Password wajib diisi!", "Peringatan", MessageBoxButtons.OK, MessageBoxIcon.Warning);

                if (string.IsNullOrWhiteSpace(hopeTextBox1.Text))
                    hopeTextBox1.Focus();
                else
                    hopeTextBox2.Focus();

                return;
            }

            // 2. Pastikan users.txt ada
            if (!File.Exists(FileUsers))
            {
                MessageBox.Show("File data user tidak ditemukan:\n" + FileUsers,
                    "Peringatan", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // 3. Cocokkan ID & password dengan users.txt
            UserData? user = CariUser(hopeTextBox1.Text, hopeTextBox2.Text);

            if (user == null)
            {
                MessageBox.Show("ID user atau Password salah!", "Peringatan", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                hopeTextBox2.Clear();
                hopeTextBox2.Focus();
                return;
            }

            if (!user.Aktif)
            {
                MessageBox.Show("Akun ini sudah dinonaktifkan. Hubungi admin.", "Peringatan", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                hopeTextBox2.Clear();
                return;
            }

            MessageBox.Show($"Login berhasil! Selamat datang, {user.Nama} ({user.Posisi}).",
                "Informasi", MessageBoxButtons.OK, MessageBoxIcon.Information);

            FormMenuAdmin halamanAdmin = new FormMenuAdmin();
            halamanAdmin.Show();
            this.Close();
        }

        private void lblFooter_Click(object sender, EventArgs e)
        {

        }
    }
}
