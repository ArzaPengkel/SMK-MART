﻿using System.Globalization;

namespace SMK_MART
{
    public partial class FormAktivitasGudang : Form
    {
        // ==========================================
        // DATA & FILE
        // ==========================================
        private class Catatan
        {
            public DateTime? Tanggal;
            public string Nama = "";
            public string Kode = "";
            public int Jumlah;
            public string Alasan = "";
            public int Urutan;
        }

        private const string FormatTanggal = "yyyy-MM-dd HH:mm";

        private readonly string folder = Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.UserProfile),
            @"Downloads\Ngoding\Pyhton SMK MART");

        private string FileBarangMasuk => Path.Combine(folder, "barang_masuk.txt");
        private string FileBarangKeluar => Path.Combine(folder, "barang_keluar.txt");

        private List<Catatan> semuaMasuk = new();
        private List<Catatan> semuaKeluar = new();

        public FormAktivitasGudang()
        {
            InitializeComponent();

            SiapkanTabel(gridMasuk, false, Color.FromArgb(5, 150, 105));
            SiapkanTabel(gridKeluar, true, Color.FromArgb(220, 38, 38));

            // Bawaan: 30 hari terakhir sampai hari ini
            dateTimePicker2.Value = DateTime.Today;
            dateTimePicker1.Value = DateTime.Today.AddDays(-30);

            parrotButton3.Click += Kembali_Click;
            parrotButton4.Click += LogOut_Click;
            btnMuatUlang.Click += (s, e) => { MuatData(); Terapkan(); };
            btnReset.Click += Reset_Click;

            dateTimePicker1.ValueChanged += (s, e) => Terapkan();
            dateTimePicker2.ValueChanged += (s, e) => Terapkan();
            txtCari.TextChanged += (s, e) => Terapkan();

            Load += (s, e) => { MuatData(); Terapkan(); };
            Activated += (s, e) => { MuatData(); Terapkan(); };

            AktifkanDoubleBuffer(gridMasuk);
            AktifkanDoubleBuffer(gridKeluar);
        }

        // Baca barang_masuk.txt  : nama|kode|jumlah[|tanggal]
        // Baca barang_keluar.txt : nama|kode|jumlah|alasan[|tanggal]
        // Baris lama (tanpa tanggal) tetap terbaca dan ditampilkan dengan tanggal "-".
        private List<Catatan> BacaCatatan(string path, bool keluar)
        {
            var hasil = new List<Catatan>();
            if (!File.Exists(path)) return hasil;

            try
            {
                using var fs = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.ReadWrite);
                using var sr = new StreamReader(fs);
                string? baris;
                int urutan = 0;
                while ((baris = sr.ReadLine()) != null)
                {
                    string teks = baris.Trim();
                    if (teks == "") continue;

                    string[] d = teks.Split('|');
                    if (d.Length < 3 || !int.TryParse(d[2].Trim(), out int jumlah)) continue;

                    int idxTanggal = keluar ? 4 : 3;
                    DateTime? tanggal = null;
                    if (d.Length > idxTanggal &&
                        DateTime.TryParseExact(d[idxTanggal].Trim(), FormatTanggal,
                            CultureInfo.InvariantCulture, DateTimeStyles.None, out DateTime t))
                        tanggal = t;

                    hasil.Add(new Catatan
                    {
                        Nama = d[0].Trim(),
                        Kode = d[1].Trim(),
                        Jumlah = jumlah,
                        Alasan = keluar && d.Length > 3 ? d[3].Trim() : "",
                        Tanggal = tanggal,
                        Urutan = urutan++
                    });
                }
            }
            catch (IOException) { }

            return hasil;
        }

        private void MuatData()
        {
            semuaMasuk = BacaCatatan(FileBarangMasuk, false);
            semuaKeluar = BacaCatatan(FileBarangKeluar, true);
        }

        // ==========================================
        // TAMPILAN
        // ==========================================
        private static void SiapkanTabel(DataGridView tabel, bool keluar, Color warnaJumlah)
        {
            tabel.Columns.Clear();
            tabel.Columns.Add("Tanggal", "Tanggal");
            tabel.Columns.Add("Kode", "Kode");
            tabel.Columns.Add("Nama", "Nama Barang");
            tabel.Columns.Add("Jumlah", "Jumlah");
            if (keluar) tabel.Columns.Add("Alasan", "Alasan");

            tabel.Columns["Tanggal"]!.FillWeight = 28;
            tabel.Columns["Kode"]!.FillWeight = 14;
            tabel.Columns["Nama"]!.FillWeight = keluar ? 30 : 38;
            tabel.Columns["Jumlah"]!.FillWeight = 16;
            if (keluar) tabel.Columns["Alasan"]!.FillWeight = 22;

            var gayaJumlah = tabel.Columns["Jumlah"]!.DefaultCellStyle;
            gayaJumlah.Alignment = DataGridViewContentAlignment.MiddleRight;
            gayaJumlah.ForeColor = warnaJumlah;
            gayaJumlah.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            tabel.Columns["Jumlah"]!.HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleRight;
        }

        private static void AktifkanDoubleBuffer(DataGridView tabel)
        {
            typeof(DataGridView).GetProperty("DoubleBuffered",
                System.Reflection.BindingFlags.Instance | System.Reflection.BindingFlags.NonPublic)
                ?.SetValue(tabel, true);
        }

        private static List<Catatan> Saring(List<Catatan> sumber, DateTime dari, DateTime sampai, string kunci)
        {
            return sumber
                // Catatan lama tanpa tanggal selalu ikut ditampilkan
                .Where(c => c.Tanggal == null || (c.Tanggal.Value.Date >= dari && c.Tanggal.Value.Date <= sampai))
                .Where(c => kunci == "" ||
                            c.Kode.Contains(kunci, StringComparison.OrdinalIgnoreCase) ||
                            c.Nama.Contains(kunci, StringComparison.OrdinalIgnoreCase))
                .OrderByDescending(c => c.Tanggal ?? DateTime.MinValue)
                .ThenByDescending(c => c.Urutan)
                .ToList();
        }

        private void Terapkan()
        {
            DateTime dari = dateTimePicker1.Value.Date;
            DateTime sampai = dateTimePicker2.Value.Date;
            if (dari > sampai) (dari, sampai) = (sampai, dari);
            string kunci = txtCari.Text.Trim();

            List<Catatan> masuk = Saring(semuaMasuk, dari, sampai, kunci);
            List<Catatan> keluar = Saring(semuaKeluar, dari, sampai, kunci);

            IsiTabel(gridMasuk, masuk, false);
            IsiTabel(gridKeluar, keluar, true);

            lblRingkasMasuk.Text = Ringkasan(masuk);
            lblRingkasKeluar.Text = Ringkasan(keluar);
        }

        private static string Ringkasan(List<Catatan> daftar)
        {
            if (daftar.Count == 0) return "Belum ada catatan pada filter ini";
            return $"{daftar.Count} catatan  •  Total {daftar.Sum(c => c.Jumlah)} unit";
        }

        private static void IsiTabel(DataGridView tabel, List<Catatan> daftar, bool keluar)
        {
            var baris = new List<DataGridViewRow>(daftar.Count);
            foreach (Catatan c in daftar)
            {
                string tgl = c.Tanggal?.ToString("dd/MM/yyyy HH:mm", CultureInfo.InvariantCulture) ?? "-";
                var row = new DataGridViewRow();
                if (keluar)
                    row.CreateCells(tabel, tgl, c.Kode, c.Nama, c.Jumlah.ToString(), c.Alasan == "" ? "-" : c.Alasan);
                else
                    row.CreateCells(tabel, tgl, c.Kode, c.Nama, c.Jumlah.ToString());
                baris.Add(row);
            }

            tabel.SuspendLayout();
            tabel.Rows.Clear();
            tabel.Rows.AddRange(baris.ToArray());
            tabel.ClearSelection();
            tabel.ResumeLayout();
        }

        private void Reset_Click(object? sender, EventArgs e)
        {
            txtCari.Clear();
            dateTimePicker2.Value = DateTime.Today;
            dateTimePicker1.Value = DateTime.Today.AddDays(-30);
            Terapkan();
        }

        // ==========================================
        // NAVIGASI
        // ==========================================
        private void Kembali_Click(object? sender, EventArgs e)
        {
            FormMenuAdmin halamanMenu = new FormMenuAdmin();
            halamanMenu.Show();
            this.Close();
        }

        private void LogOut_Click(object? sender, EventArgs e)
        {
            DialogResult konfirmasi = MessageBox.Show(
                "Apakah Anda yakin ingin Log out dari akun ini?",
                "Konfirmasi Log Out",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Question
            );

            if (konfirmasi == DialogResult.Yes)
            {
                FormLogin halamanLogin = new FormLogin();
                halamanLogin.Show();
                this.Close();
            }
        }
    }
}
