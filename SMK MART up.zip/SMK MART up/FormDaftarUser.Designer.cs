﻿namespace SMK_MART
{
    partial class FormDaftarUser
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            DataGridViewCellStyle dataGridViewCellStyle1 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle2 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle3 = new DataGridViewCellStyle();
            panel3 = new Panel();
            parrotButton5 = new ReaLTaiizor.Controls.ParrotButton();
            parrotButton2 = new ReaLTaiizor.Controls.ParrotButton();
            parrotButton3 = new ReaLTaiizor.Controls.ParrotButton();
            parrotButton1 = new ReaLTaiizor.Controls.ParrotButton();
            label3 = new Label();
            tableLayoutPanel1 = new TableLayoutPanel();
            panel1 = new Panel();
            poisonDataGridView2 = new ReaLTaiizor.Controls.PoisonDataGridView();
            Column2 = new DataGridViewTextBoxColumn();
            Column3 = new DataGridViewTextBoxColumn();
            Column1 = new DataGridViewTextBoxColumn();
            Column5 = new DataGridViewTextBoxColumn();
            Column6 = new DataGridViewTextBoxColumn();
            panel4 = new Panel();
            label1 = new Label();
            panel2 = new Panel();
            hopeTextBox1 = new ReaLTaiizor.Controls.HopeTextBox();
            btnBatalEdit = new ReaLTaiizor.Controls.ParrotButton();
            btnStatusUser = new ReaLTaiizor.Controls.ParrotButton();
            parrotButton4 = new ReaLTaiizor.Controls.ParrotButton();
            panelPosisi = new FlowLayoutPanel();
            radioKasir = new RadioButton();
            radioAdmin = new RadioButton();
            radioGudang = new RadioButton();
            label7 = new Label();
            label6 = new Label();
            label5 = new Label();
            label4 = new Label();
            hopeTextBox3 = new ReaLTaiizor.Controls.HopeTextBox();
            hopeTextBox2 = new ReaLTaiizor.Controls.HopeTextBox();
            panel5 = new Panel();
            label2 = new Label();
            panel3.SuspendLayout();
            tableLayoutPanel1.SuspendLayout();
            panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)poisonDataGridView2).BeginInit();
            panel2.SuspendLayout();
            panelPosisi.SuspendLayout();
            SuspendLayout();
            // 
            // panel3
            // 
            panel3.BackColor = Color.Navy;
            panel3.Controls.Add(parrotButton5);
            panel3.Controls.Add(parrotButton2);
            panel3.Controls.Add(parrotButton3);
            panel3.Controls.Add(parrotButton1);
            panel3.Controls.Add(label3);
            panel3.Dock = DockStyle.Top;
            panel3.Location = new Point(0, 0);
            panel3.Name = "panel3";
            panel3.Size = new Size(899, 55);
            panel3.TabIndex = 5;
            // 
            // parrotButton5
            // 
            parrotButton5.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            parrotButton5.BackgroundColor = Color.Gold;
            parrotButton5.ButtonImage = null;
            parrotButton5.ButtonStyle = ReaLTaiizor.Controls.ParrotButton.Style.MaterialRounded;
            parrotButton5.ButtonText = "Log out";
            parrotButton5.ClickBackColor = Color.FromArgb(195, 195, 195);
            parrotButton5.ClickTextColor = Color.Black;
            parrotButton5.CornerRadius = 10;
            parrotButton5.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            parrotButton5.Horizontal_Alignment = StringAlignment.Center;
            parrotButton5.HoverBackgroundColor = Color.FromArgb(225, 225, 225);
            parrotButton5.HoverTextColor = Color.DodgerBlue;
            parrotButton5.ImagePosition = ReaLTaiizor.Controls.ParrotButton.ImgPosition.Left;
            parrotButton5.Location = new Point(796, 9);
            parrotButton5.Name = "parrotButton5";
            parrotButton5.Size = new Size(88, 37);
            parrotButton5.SmoothingType = System.Drawing.Drawing2D.SmoothingMode.HighQuality;
            parrotButton5.TabIndex = 7;
            parrotButton5.TextColor = Color.Black;
            parrotButton5.TextRenderingType = System.Drawing.Text.TextRenderingHint.ClearTypeGridFit;
            parrotButton5.Vertical_Alignment = StringAlignment.Center;
            parrotButton5.Click += parrotButton5_Click;
            // 
            // parrotButton2
            // 
            parrotButton2.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            parrotButton2.BackgroundColor = Color.Gold;
            parrotButton2.ButtonImage = null;
            parrotButton2.ButtonStyle = ReaLTaiizor.Controls.ParrotButton.Style.MaterialRounded;
            parrotButton2.ButtonText = "Log out";
            parrotButton2.ClickBackColor = Color.FromArgb(195, 195, 195);
            parrotButton2.ClickTextColor = Color.Black;
            parrotButton2.CornerRadius = 10;
            parrotButton2.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            parrotButton2.Horizontal_Alignment = StringAlignment.Center;
            parrotButton2.HoverBackgroundColor = Color.FromArgb(225, 225, 225);
            parrotButton2.HoverTextColor = Color.DodgerBlue;
            parrotButton2.ImagePosition = ReaLTaiizor.Controls.ParrotButton.ImgPosition.Left;
            parrotButton2.Location = new Point(1999, 9);
            parrotButton2.Name = "parrotButton2";
            parrotButton2.Size = new Size(88, 37);
            parrotButton2.SmoothingType = System.Drawing.Drawing2D.SmoothingMode.HighQuality;
            parrotButton2.TabIndex = 5;
            parrotButton2.TextColor = Color.Black;
            parrotButton2.TextRenderingType = System.Drawing.Text.TextRenderingHint.ClearTypeGridFit;
            parrotButton2.Vertical_Alignment = StringAlignment.Center;
            // 
            // parrotButton3
            // 
            parrotButton3.BackgroundColor = Color.Gold;
            parrotButton3.ButtonImage = null;
            parrotButton3.ButtonStyle = ReaLTaiizor.Controls.ParrotButton.Style.MaterialRounded;
            parrotButton3.ButtonText = "Kembali";
            parrotButton3.ClickBackColor = Color.FromArgb(195, 195, 195);
            parrotButton3.ClickTextColor = Color.DodgerBlue;
            parrotButton3.CornerRadius = 5;
            parrotButton3.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            parrotButton3.Horizontal_Alignment = StringAlignment.Center;
            parrotButton3.HoverBackgroundColor = Color.FromArgb(225, 225, 225);
            parrotButton3.HoverTextColor = Color.DodgerBlue;
            parrotButton3.ImagePosition = ReaLTaiizor.Controls.ParrotButton.ImgPosition.Left;
            parrotButton3.Location = new Point(18, 9);
            parrotButton3.Name = "parrotButton3";
            parrotButton3.Size = new Size(95, 37);
            parrotButton3.SmoothingType = System.Drawing.Drawing2D.SmoothingMode.HighQuality;
            parrotButton3.TabIndex = 4;
            parrotButton3.TextColor = Color.Black;
            parrotButton3.TextRenderingType = System.Drawing.Text.TextRenderingHint.ClearTypeGridFit;
            parrotButton3.Vertical_Alignment = StringAlignment.Center;
            // 
            // parrotButton1
            // 
            parrotButton1.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            parrotButton1.BackgroundColor = Color.Gold;
            parrotButton1.ButtonImage = null;
            parrotButton1.ButtonStyle = ReaLTaiizor.Controls.ParrotButton.Style.MaterialRounded;
            parrotButton1.ButtonText = "Log out";
            parrotButton1.ClickBackColor = Color.FromArgb(195, 195, 195);
            parrotButton1.ClickTextColor = Color.Black;
            parrotButton1.CornerRadius = 10;
            parrotButton1.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            parrotButton1.Horizontal_Alignment = StringAlignment.Center;
            parrotButton1.HoverBackgroundColor = Color.FromArgb(225, 225, 225);
            parrotButton1.HoverTextColor = Color.DodgerBlue;
            parrotButton1.ImagePosition = ReaLTaiizor.Controls.ParrotButton.ImgPosition.Left;
            parrotButton1.Location = new Point(2701, 9);
            parrotButton1.Name = "parrotButton1";
            parrotButton1.Size = new Size(88, 37);
            parrotButton1.SmoothingType = System.Drawing.Drawing2D.SmoothingMode.HighQuality;
            parrotButton1.TabIndex = 3;
            parrotButton1.TextColor = Color.Black;
            parrotButton1.TextRenderingType = System.Drawing.Text.TextRenderingHint.ClearTypeGridFit;
            parrotButton1.Vertical_Alignment = StringAlignment.Center;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI", 20.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label3.ForeColor = Color.Gold;
            label3.Location = new Point(119, 9);
            label3.Name = "label3";
            label3.Size = new Size(161, 37);
            label3.TabIndex = 0;
            label3.Text = "SMK MART";
            label3.Click += label3_Click;
            // 
            // tableLayoutPanel1
            // 
            tableLayoutPanel1.BackColor = Color.Gainsboro;
            tableLayoutPanel1.ColumnCount = 2;
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 66.35731F));
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 33.6426926F));
            tableLayoutPanel1.Controls.Add(panel1, 0, 0);
            tableLayoutPanel1.Controls.Add(panel2, 1, 0);
            tableLayoutPanel1.Dock = DockStyle.Fill;
            tableLayoutPanel1.Location = new Point(0, 55);
            tableLayoutPanel1.Name = "tableLayoutPanel1";
            tableLayoutPanel1.RowCount = 1;
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 100F));
            tableLayoutPanel1.Size = new Size(899, 513);
            tableLayoutPanel1.TabIndex = 6;
            // 
            // panel1
            // 
            panel1.BackColor = Color.White;
            panel1.Controls.Add(poisonDataGridView2);
            panel1.Controls.Add(panel4);
            panel1.Controls.Add(label1);
            panel1.Dock = DockStyle.Fill;
            panel1.Location = new Point(15, 10);
            panel1.Margin = new Padding(15, 10, 15, 10);
            panel1.Name = "panel1";
            panel1.Size = new Size(566, 493);
            panel1.TabIndex = 0;
            // 
            // poisonDataGridView2
            // 
            poisonDataGridView2.AllowUserToAddRows = false;
            poisonDataGridView2.AllowUserToResizeRows = false;
            poisonDataGridView2.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            poisonDataGridView2.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            poisonDataGridView2.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.DisplayedCellsExceptHeaders;
            poisonDataGridView2.BackgroundColor = Color.FromArgb(255, 255, 255);
            poisonDataGridView2.BorderStyle = BorderStyle.None;
            poisonDataGridView2.CellBorderStyle = DataGridViewCellBorderStyle.None;
            poisonDataGridView2.ColumnHeadersBorderStyle = DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle1.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = Color.Gainsboro;
            dataGridViewCellStyle1.Font = new Font("Segoe UI Semibold", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            dataGridViewCellStyle1.ForeColor = Color.Navy;
            dataGridViewCellStyle1.SelectionBackColor = Color.Gainsboro;
            dataGridViewCellStyle1.SelectionForeColor = Color.Navy;
            dataGridViewCellStyle1.WrapMode = DataGridViewTriState.True;
            poisonDataGridView2.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            poisonDataGridView2.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            poisonDataGridView2.Columns.AddRange(new DataGridViewColumn[] { Column2, Column3, Column1, Column5, Column6 });
            dataGridViewCellStyle2.Alignment = DataGridViewContentAlignment.TopLeft;
            dataGridViewCellStyle2.BackColor = Color.FromArgb(255, 255, 255);
            dataGridViewCellStyle2.Font = new Font("Segoe UI", 15.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            dataGridViewCellStyle2.ForeColor = Color.FromArgb(64, 64, 64);
            dataGridViewCellStyle2.Padding = new Padding(3);
            dataGridViewCellStyle2.SelectionBackColor = Color.DarkGray;
            dataGridViewCellStyle2.SelectionForeColor = Color.FromArgb(64, 64, 64);
            dataGridViewCellStyle2.WrapMode = DataGridViewTriState.False;
            poisonDataGridView2.DefaultCellStyle = dataGridViewCellStyle2;
            poisonDataGridView2.EnableHeadersVisualStyles = false;
            poisonDataGridView2.Font = new Font("Segoe UI", 11F, FontStyle.Regular, GraphicsUnit.Pixel);
            poisonDataGridView2.GridColor = Color.Silver;
            poisonDataGridView2.Location = new Point(15, 61);
            poisonDataGridView2.Name = "poisonDataGridView2";
            poisonDataGridView2.RowHeadersBorderStyle = DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle3.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = Color.FromArgb(0, 174, 219);
            dataGridViewCellStyle3.Font = new Font("Segoe UI", 11F, FontStyle.Regular, GraphicsUnit.Pixel);
            dataGridViewCellStyle3.ForeColor = Color.FromArgb(255, 255, 255);
            dataGridViewCellStyle3.SelectionBackColor = Color.FromArgb(0, 198, 247);
            dataGridViewCellStyle3.SelectionForeColor = Color.FromArgb(17, 17, 17);
            dataGridViewCellStyle3.WrapMode = DataGridViewTriState.True;
            poisonDataGridView2.RowHeadersDefaultCellStyle = dataGridViewCellStyle3;
            poisonDataGridView2.RowHeadersVisible = false;
            poisonDataGridView2.RowHeadersWidthSizeMode = DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            poisonDataGridView2.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            poisonDataGridView2.Size = new Size(533, 322);
            poisonDataGridView2.TabIndex = 7;
            poisonDataGridView2.CellContentClick += poisonDataGridView2_CellContentClick;
            // 
            // Column2
            // 
            Column2.HeaderText = "ID";
            Column2.Name = "Column2";
            // 
            // Column3
            // 
            Column3.FillWeight = 150F;
            Column3.HeaderText = "Nama";
            Column3.Name = "Column3";
            // 
            // Column1
            // 
            Column1.FillWeight = 185F;
            Column1.HeaderText = "Password";
            Column1.Name = "Column1";
            // 
            // Column5
            // 
            Column5.FillWeight = 150F;
            Column5.HeaderText = "Posisi";
            Column5.Name = "Column5";
            // 
            // Column6
            // 
            Column6.FillWeight = 150F;
            Column6.HeaderText = "Status";
            Column6.Name = "Column6";
            // 
            // panel4
            // 
            panel4.BackColor = Color.Navy;
            panel4.Dock = DockStyle.Top;
            panel4.Location = new Point(0, 0);
            panel4.Name = "panel4";
            panel4.Size = new Size(566, 10);
            panel4.TabIndex = 1;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI Semibold", 24F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.ForeColor = Color.Navy;
            label1.Location = new Point(15, 13);
            label1.Name = "label1";
            label1.Size = new Size(188, 45);
            label1.TabIndex = 0;
            label1.Text = "Daftar User";
            // 
            // panel2
            // 
            panel2.BackColor = Color.White;
            panel2.Controls.Add(hopeTextBox1);
            panel2.Controls.Add(btnBatalEdit);
            panel2.Controls.Add(btnStatusUser);
            panel2.Controls.Add(parrotButton4);
            panel2.Controls.Add(panelPosisi);
            panel2.Controls.Add(label7);
            panel2.Controls.Add(label6);
            panel2.Controls.Add(label5);
            panel2.Controls.Add(label4);
            panel2.Controls.Add(hopeTextBox3);
            panel2.Controls.Add(hopeTextBox2);
            panel2.Controls.Add(panel5);
            panel2.Controls.Add(label2);
            panel2.Dock = DockStyle.Fill;
            panel2.Location = new Point(611, 10);
            panel2.Margin = new Padding(15, 10, 15, 10);
            panel2.Name = "panel2";
            panel2.Size = new Size(273, 493);
            panel2.TabIndex = 1;
            // 
            // hopeTextBox1
            // 
            hopeTextBox1.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            hopeTextBox1.BackColor = Color.White;
            hopeTextBox1.BaseColor = Color.White;
            hopeTextBox1.BorderColorA = Color.DarkGray;
            hopeTextBox1.BorderColorB = Color.DarkGray;
            hopeTextBox1.Font = new Font("Segoe UI", 12F);
            hopeTextBox1.ForeColor = Color.FromArgb(48, 49, 51);
            hopeTextBox1.Hint = "";
            hopeTextBox1.Location = new Point(13, 95);
            hopeTextBox1.MaxLength = 32767;
            hopeTextBox1.Multiline = false;
            hopeTextBox1.Name = "hopeTextBox1";
            hopeTextBox1.PasswordChar = '\0';
            hopeTextBox1.ScrollBars = ScrollBars.None;
            hopeTextBox1.SelectedText = "";
            hopeTextBox1.SelectionLength = 0;
            hopeTextBox1.SelectionStart = 0;
            hopeTextBox1.Size = new Size(240, 38);
            hopeTextBox1.TabIndex = 12;
            hopeTextBox1.TabStop = false;
            hopeTextBox1.UseSystemPasswordChar = false;
            // 
            // btnBatalEdit
            // 
            btnBatalEdit.Anchor = AnchorStyles.Bottom | AnchorStyles.Left;
            btnBatalEdit.BackgroundColor = Color.Gainsboro;
            btnBatalEdit.ButtonImage = null;
            btnBatalEdit.ButtonStyle = ReaLTaiizor.Controls.ParrotButton.Style.MaterialRounded;
            btnBatalEdit.ButtonText = "Batal";
            btnBatalEdit.ClickBackColor = Color.FromArgb(195, 195, 195);
            btnBatalEdit.ClickTextColor = Color.DodgerBlue;
            btnBatalEdit.CornerRadius = 5;
            btnBatalEdit.Font = new Font("Segoe UI", 11F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btnBatalEdit.Horizontal_Alignment = StringAlignment.Center;
            btnBatalEdit.HoverBackgroundColor = Color.FromArgb(225, 225, 225);
            btnBatalEdit.HoverTextColor = Color.DodgerBlue;
            btnBatalEdit.ImagePosition = ReaLTaiizor.Controls.ParrotButton.ImgPosition.Left;
            btnBatalEdit.Location = new Point(143, 422);
            btnBatalEdit.Name = "btnBatalEdit";
            btnBatalEdit.Size = new Size(110, 40);
            btnBatalEdit.SmoothingType = System.Drawing.Drawing2D.SmoothingMode.HighQuality;
            btnBatalEdit.TabIndex = 14;
            btnBatalEdit.TextColor = Color.Black;
            btnBatalEdit.TextRenderingType = System.Drawing.Text.TextRenderingHint.ClearTypeGridFit;
            btnBatalEdit.Vertical_Alignment = StringAlignment.Center;
            btnBatalEdit.Visible = false;
            // 
            // btnStatusUser
            // 
            btnStatusUser.Anchor = AnchorStyles.Bottom | AnchorStyles.Left;
            btnStatusUser.BackgroundColor = Color.FromArgb(220, 53, 69);
            btnStatusUser.ButtonImage = null;
            btnStatusUser.ButtonStyle = ReaLTaiizor.Controls.ParrotButton.Style.MaterialRounded;
            btnStatusUser.ButtonText = "Nonaktifkan";
            btnStatusUser.ClickBackColor = Color.FromArgb(195, 195, 195);
            btnStatusUser.ClickTextColor = Color.DodgerBlue;
            btnStatusUser.CornerRadius = 5;
            btnStatusUser.Font = new Font("Segoe UI", 11F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btnStatusUser.Horizontal_Alignment = StringAlignment.Center;
            btnStatusUser.HoverBackgroundColor = Color.FromArgb(225, 225, 225);
            btnStatusUser.HoverTextColor = Color.DodgerBlue;
            btnStatusUser.ImagePosition = ReaLTaiizor.Controls.ParrotButton.ImgPosition.Left;
            btnStatusUser.Location = new Point(13, 422);
            btnStatusUser.Name = "btnStatusUser";
            btnStatusUser.Size = new Size(110, 40);
            btnStatusUser.SmoothingType = System.Drawing.Drawing2D.SmoothingMode.HighQuality;
            btnStatusUser.TabIndex = 13;
            btnStatusUser.TextColor = Color.White;
            btnStatusUser.TextRenderingType = System.Drawing.Text.TextRenderingHint.ClearTypeGridFit;
            btnStatusUser.Vertical_Alignment = StringAlignment.Center;
            btnStatusUser.Visible = false;
            btnStatusUser.Click += btnStatusUser_Click_1;
            // 
            // parrotButton4
            // 
            parrotButton4.Anchor = AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            parrotButton4.BackgroundColor = Color.FromArgb(255, 128, 0);
            parrotButton4.ButtonImage = null;
            parrotButton4.ButtonStyle = ReaLTaiizor.Controls.ParrotButton.Style.MaterialRounded;
            parrotButton4.ButtonText = "Tambah";
            parrotButton4.ClickBackColor = Color.FromArgb(195, 195, 195);
            parrotButton4.ClickTextColor = Color.DodgerBlue;
            parrotButton4.CornerRadius = 5;
            parrotButton4.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            parrotButton4.Horizontal_Alignment = StringAlignment.Center;
            parrotButton4.HoverBackgroundColor = Color.FromArgb(225, 225, 225);
            parrotButton4.HoverTextColor = Color.DodgerBlue;
            parrotButton4.ImagePosition = ReaLTaiizor.Controls.ParrotButton.ImgPosition.Left;
            parrotButton4.Location = new Point(16, 374);
            parrotButton4.Name = "parrotButton4";
            parrotButton4.Size = new Size(240, 42);
            parrotButton4.SmoothingType = System.Drawing.Drawing2D.SmoothingMode.HighQuality;
            parrotButton4.TabIndex = 11;
            parrotButton4.TextColor = Color.Black;
            parrotButton4.TextRenderingType = System.Drawing.Text.TextRenderingHint.ClearTypeGridFit;
            parrotButton4.Vertical_Alignment = StringAlignment.Center;
            // 
            // panelPosisi
            // 
            panelPosisi.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            panelPosisi.BackColor = Color.Transparent;
            panelPosisi.Controls.Add(radioKasir);
            panelPosisi.Controls.Add(radioAdmin);
            panelPosisi.Controls.Add(radioGudang);
            panelPosisi.Location = new Point(13, 321);
            panelPosisi.Margin = new Padding(0);
            panelPosisi.Name = "panelPosisi";
            panelPosisi.Size = new Size(248, 40);
            panelPosisi.TabIndex = 10;
            panelPosisi.WrapContents = false;
            // 
            // radioKasir
            // 
            radioKasir.AutoSize = true;
            radioKasir.Font = new Font("Segoe UI", 12.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            radioKasir.ForeColor = Color.FromArgb(64, 64, 64);
            radioKasir.Location = new Point(3, 5);
            radioKasir.Margin = new Padding(3, 5, 3, 3);
            radioKasir.Name = "radioKasir";
            radioKasir.Size = new Size(64, 27);
            radioKasir.TabIndex = 1;
            radioKasir.Text = "Kasir";
            radioKasir.UseVisualStyleBackColor = true;
            // 
            // radioAdmin
            // 
            radioAdmin.AutoSize = true;
            radioAdmin.Font = new Font("Segoe UI", 12.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            radioAdmin.ForeColor = Color.FromArgb(64, 64, 64);
            radioAdmin.Location = new Point(73, 5);
            radioAdmin.Margin = new Padding(3, 5, 3, 3);
            radioAdmin.Name = "radioAdmin";
            radioAdmin.Size = new Size(78, 27);
            radioAdmin.TabIndex = 0;
            radioAdmin.Text = "Admin";
            radioAdmin.UseVisualStyleBackColor = true;
            // 
            // radioGudang
            // 
            radioGudang.AutoSize = true;
            radioGudang.Font = new Font("Segoe UI", 12.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            radioGudang.ForeColor = Color.FromArgb(64, 64, 64);
            radioGudang.Location = new Point(157, 5);
            radioGudang.Margin = new Padding(3, 5, 3, 3);
            radioGudang.Name = "radioGudang";
            radioGudang.Size = new Size(89, 27);
            radioGudang.TabIndex = 2;
            radioGudang.Text = "Gudang";
            radioGudang.UseVisualStyleBackColor = true;
            // 
            // label7
            // 
            label7.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left;
            label7.AutoSize = true;
            label7.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label7.ForeColor = Color.FromArgb(64, 64, 64);
            label7.Location = new Point(13, 300);
            label7.Name = "label7";
            label7.Size = new Size(49, 21);
            label7.TabIndex = 9;
            label7.Text = "Posisi";
            // 
            // label6
            // 
            label6.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left;
            label6.AutoSize = true;
            label6.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label6.ForeColor = Color.FromArgb(64, 64, 64);
            label6.Location = new Point(13, 224);
            label6.Name = "label6";
            label6.Size = new Size(76, 21);
            label6.TabIndex = 7;
            label6.Text = "Password";
            // 
            // label5
            // 
            label5.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left;
            label5.AutoSize = true;
            label5.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label5.ForeColor = Color.FromArgb(64, 64, 64);
            label5.Location = new Point(13, 145);
            label5.Name = "label5";
            label5.Size = new Size(52, 21);
            label5.TabIndex = 6;
            label5.Text = "Nama";
            // 
            // label4
            // 
            label4.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left;
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label4.ForeColor = Color.FromArgb(64, 64, 64);
            label4.Location = new Point(13, 71);
            label4.Name = "label4";
            label4.Size = new Size(61, 21);
            label4.TabIndex = 5;
            label4.Text = "ID User";
            // 
            // hopeTextBox3
            // 
            hopeTextBox3.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            hopeTextBox3.BackColor = Color.White;
            hopeTextBox3.BaseColor = Color.White;
            hopeTextBox3.BorderColorA = Color.DarkGray;
            hopeTextBox3.BorderColorB = Color.DarkGray;
            hopeTextBox3.Font = new Font("Segoe UI", 12F);
            hopeTextBox3.ForeColor = Color.FromArgb(48, 49, 51);
            hopeTextBox3.Hint = "";
            hopeTextBox3.Location = new Point(13, 248);
            hopeTextBox3.MaxLength = 32767;
            hopeTextBox3.Multiline = false;
            hopeTextBox3.Name = "hopeTextBox3";
            hopeTextBox3.PasswordChar = '\0';
            hopeTextBox3.ScrollBars = ScrollBars.None;
            hopeTextBox3.SelectedText = "";
            hopeTextBox3.SelectionLength = 0;
            hopeTextBox3.SelectionStart = 0;
            hopeTextBox3.Size = new Size(240, 38);
            hopeTextBox3.TabIndex = 4;
            hopeTextBox3.TabStop = false;
            hopeTextBox3.UseSystemPasswordChar = false;
            // 
            // hopeTextBox2
            // 
            hopeTextBox2.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            hopeTextBox2.BackColor = Color.White;
            hopeTextBox2.BaseColor = Color.White;
            hopeTextBox2.BorderColorA = Color.DarkGray;
            hopeTextBox2.BorderColorB = Color.DarkGray;
            hopeTextBox2.Font = new Font("Segoe UI", 12F);
            hopeTextBox2.ForeColor = Color.FromArgb(48, 49, 51);
            hopeTextBox2.Hint = "";
            hopeTextBox2.Location = new Point(13, 169);
            hopeTextBox2.MaxLength = 32767;
            hopeTextBox2.Multiline = false;
            hopeTextBox2.Name = "hopeTextBox2";
            hopeTextBox2.PasswordChar = '\0';
            hopeTextBox2.ScrollBars = ScrollBars.None;
            hopeTextBox2.SelectedText = "";
            hopeTextBox2.SelectionLength = 0;
            hopeTextBox2.SelectionStart = 0;
            hopeTextBox2.Size = new Size(240, 38);
            hopeTextBox2.TabIndex = 3;
            hopeTextBox2.TabStop = false;
            hopeTextBox2.UseSystemPasswordChar = false;
            // 
            // panel5
            // 
            panel5.BackColor = Color.FromArgb(5, 150, 105);
            panel5.Dock = DockStyle.Top;
            panel5.Location = new Point(0, 0);
            panel5.Name = "panel5";
            panel5.Size = new Size(273, 10);
            panel5.TabIndex = 1;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI Semibold", 24F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label2.ForeColor = Color.FromArgb(5, 150, 105);
            label2.Location = new Point(3, 13);
            label2.Name = "label2";
            label2.Size = new Size(210, 45);
            label2.TabIndex = 0;
            label2.Text = "Tambah User";
            // 
            // FormDaftarUser
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(899, 568);
            Controls.Add(tableLayoutPanel1);
            Controls.Add(panel3);
            Name = "FormDaftarUser";
            Text = "FormDaftarUser";
            WindowState = FormWindowState.Maximized;
            Load += FormDaftarUser_Load;
            panel3.ResumeLayout(false);
            panel3.PerformLayout();
            tableLayoutPanel1.ResumeLayout(false);
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)poisonDataGridView2).EndInit();
            panel2.ResumeLayout(false);
            panel2.PerformLayout();
            panelPosisi.ResumeLayout(false);
            panelPosisi.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private Panel panel3;
        private ReaLTaiizor.Controls.ParrotButton parrotButton2;
        private ReaLTaiizor.Controls.ParrotButton parrotButton3;
        private ReaLTaiizor.Controls.ParrotButton parrotButton1;
        private Label label3;
        private TableLayoutPanel tableLayoutPanel1;
        private Panel panel1;
        private Panel panel2;
        private Panel panel4;
        private Label label1;
        private Panel panel5;
        private Label label2;
        private ReaLTaiizor.Controls.PoisonDataGridView poisonDataGridView2;
        private ReaLTaiizor.Controls.HopeTextBox hopeTextBox3;
        private ReaLTaiizor.Controls.HopeTextBox hopeTextBox2;
        private Label label6;
        private Label label5;
        private Label label4;
        private DataGridViewTextBoxColumn Column2;
        private DataGridViewTextBoxColumn Column3;
        private DataGridViewTextBoxColumn Column1;
        private DataGridViewTextBoxColumn Column5;
        private DataGridViewTextBoxColumn Column6;
        private Label label7;
        private ReaLTaiizor.Controls.ParrotButton btnStatusUser;
        private ReaLTaiizor.Controls.ParrotButton btnBatalEdit;
        private RadioButton radioAdmin;
        private ReaLTaiizor.Controls.ParrotButton parrotButton4;
        private ReaLTaiizor.Controls.HopeTextBox hopeTextBox1;
        private ReaLTaiizor.Controls.ParrotButton parrotButton5;
        private FlowLayoutPanel panelPosisi;
        private RadioButton radioKasir;
        private RadioButton radioGudang;
    }
}