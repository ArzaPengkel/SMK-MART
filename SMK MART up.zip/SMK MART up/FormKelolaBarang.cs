﻿namespace SMK_MART
{
    public partial class FormKelolaBarang : Form
    {
        private class BarangData
        {
            public string Kode = "";
            public string Nama = "";
            public int Harga;       // harga jual
            public int HargaBeli;   // harga beli (modal)
            public int Stok;
            public string Status = "aktif";
        }

        private readonly string folder = Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.UserProfile),
            @"Downloads\Ngoding\Pyhton SMK MART");

        private string FileBarang => Path.Combine(folder, "barang.txt");

        // Baris barang.txt yang formatnya salah pada pembacaan terakhir (dicatat agar tidak hilang saat menyimpan)
        private int barisSalah = 0;
        private string contohBarisSalah = "";

        private bool sudahPeringatBarisSalah = false;

        private FileSystemWatcher? pemantauFile;
        private System.Windows.Forms.Timer? timerMuatUlang;   // menggabungkan beberapa kejadian file menjadi satu kali muat

        // Kondisi barang.txt saat terakhir dibaca (waktu ubah + ukuran), untuk mengenali perubahan dari luar
        private string tandaFileTerakhir = "";

        // Kode barang yang sedang diedit; null berarti sedang mode "Tambah"
        private string? kodeDiedit = null;

        public FormKelolaBarang()
        {
            InitializeComponent();

            // Klik baris tabel (selain kolom Aksi) -> edit barang tersebut
            poisonDataGridView1.ReadOnly = true;
            poisonDataGridView1.CellClick += poisonDataGridView1_CellClick;
            btnBatalEdit.Click += (s, e) => KeluarModeEdit();

            AktifkanDoubleBuffer(poisonDataGridView1);

            // Pemantau file selalu dimatikan saat form ditutup, apa pun caranya
            FormClosed += (s, e) => HentikanPemantauFile();
        }

        // ==========================================
        // BANTUAN TABEL (supaya cepat)
        // ==========================================
        // Menggambar tabel lewat buffer ganda: scroll dan muat ulang lebih halus
        private static void AktifkanDoubleBuffer(DataGridView tabel)
        {
            typeof(DataGridView).GetProperty("DoubleBuffered",
                System.Reflection.BindingFlags.Instance | System.Reflection.BindingFlags.NonPublic)
                ?.SetValue(tabel, true);
        }

        private static DataGridViewRow BuatBaris(DataGridView tabel, params object[] nilai)
        {
            var baris = new DataGridViewRow();
            baris.CreateCells(tabel, nilai);
            return baris;
        }

        // Mengisi tabel sekaligus: jauh lebih cepat daripada Rows.Add satu per satu
        private static void IsiTabel(DataGridView tabel, List<DataGridViewRow> isi)
        {
            int posisiGulir = tabel.FirstDisplayedScrollingRowIndex;   // -1 jika tabel kosong

            tabel.SuspendLayout();
            tabel.Rows.Clear();
            tabel.Rows.AddRange(isi.ToArray());
            tabel.ResumeLayout();

            // Tetap di posisi gulir yang sama, tidak loncat ke atas setelah diubah
            if (posisiGulir > 0 && posisiGulir < tabel.Rows.Count)
            {
                try { tabel.FirstDisplayedScrollingRowIndex = posisiGulir; }
                catch (InvalidOperationException) { }
            }
        }

        private string TandaFile()
        {
            try
            {
                var info = new FileInfo(FileBarang);
                return info.Exists ? info.LastWriteTimeUtc.Ticks + ":" + info.Length : "";
            }
            catch (IOException) { return ""; }
        }

        // ==========================================
        // FILE barang.txt (kode|nama|harga_beli|harga_jual|stok|status)
        // ==========================================
        private List<BarangData> BacaBarang()
        {
            var hasil = new List<BarangData>();
            barisSalah = 0;
            contohBarisSalah = "";
            if (!File.Exists(FileBarang)) return hasil;

            try
            {
                using var fs = new FileStream(FileBarang, FileMode.Open, FileAccess.Read, FileShare.ReadWrite);
                using var sr = new StreamReader(fs);
                string? baris;
                while ((baris = sr.ReadLine()) != null)
                {
                    string teks = baris.Trim();
                    if (teks == "") continue;

                    string[] d = teks.Split('|');
                    if (TryBacaBarang(d, out string kode, out string nama, out int hargaBeli, out int harga, out int stok, out string status))
                    {
                        hasil.Add(new BarangData { Kode = kode, Nama = nama, Harga = harga, HargaBeli = hargaBeli, Stok = stok, Status = status });
                    }
                    else
                    {
                        barisSalah++;
                        if (contohBarisSalah == "") contohBarisSalah = teks;
                    }
                }
            }
            catch (IOException) { }

            return hasil;
        }

        // Format barang.txt (hanya satu format): kode|nama|harga_beli|harga_jual|stok|status
        private static bool TryBacaBarang(string[] d, out string kode, out string nama,
            out int hargaBeli, out int harga, out int stok, out string status)
        {
            kode = nama = status = "";
            hargaBeli = harga = stok = 0;

            if (d.Length != 6) return false;

            kode = d[0];
            nama = d[1];
            status = d[5];

            return int.TryParse(d[2], out hargaBeli)
                && int.TryParse(d[3], out harga)
                && int.TryParse(d[4], out stok)
                && AdalahStatus(status);
        }

        private static bool AdalahStatus(string teks) => teks == "aktif" || teks == "nonaktif";

        private void SimpanBarang(List<BarangData> daftar)
        {
            // Jangan menimpa file jika ada baris yang formatnya salah: baris itu akan hilang
            if (barisSalah > 0)
                throw new IOException($"barang.txt punya {barisSalah} baris dengan format salah, contoh: {contohBarisSalah}\n" +
                    "Format yang benar: kode|nama|harga_beli|harga_jual|stok|status\n" +
                    "Perbaiki dulu file-nya agar data tidak hilang.");

            Directory.CreateDirectory(folder);
            File.WriteAllLines(FileBarang,
                daftar.Select(b => $"{b.Kode}|{b.Nama}|{b.HargaBeli}|{b.Harga}|{b.Stok}|{b.Status}"));
        }

        private static string BuatKodeBarang(List<BarangData> daftar)
        {
            int terbesar = 0;
            foreach (BarangData b in daftar)
            {
                if (b.Kode.Length > 1 && int.TryParse(b.Kode.Substring(1), out int angka))
                    terbesar = Math.Max(terbesar, angka);
            }
            return "B" + (terbesar + 1).ToString("D3");
        }

        private static string Bersihkan(string teks) => teks.Replace("|", "/").Trim();

        // ==========================================
        // TAMPILAN
        // ==========================================
        private void FormKelolaBarang_Load(object sender, EventArgs e)
        {
            // 1. Memuat data awal dari file .txt ke tabel
            MuatDataDariTxt();

            // 2. Mengaktifkan pemantau file otomatis (jika Python mengedit file .txt)
            MulaiPemantauFile();
        }

        private void MuatDataDariTxt()
        {
            tandaFileTerakhir = TandaFile();   // dicatat sebelum membaca
            List<BarangData> daftar = BacaBarang();

            var isi = new List<DataGridViewRow>(daftar.Count);
            foreach (BarangData b in daftar)
            {
                string hargaBeli = "Rp" + b.HargaBeli.ToString("N0");
                string hargaJual = "Rp" + b.Harga.ToString("N0");
                string teksTombol = (b.Status == "aktif") ? "Nonaktifkan" : "Aktifkan";
                isi.Add(BuatBaris(poisonDataGridView1, b.Kode, b.Nama, hargaBeli, hargaJual, b.Stok.ToString(), b.Status, teksTombol));
            }
            IsiTabel(poisonDataGridView1, isi);

            label4.Text = "Kode Barang: " + (kodeDiedit ?? BuatKodeBarang(daftar));

            if (barisSalah > 0 && !sudahPeringatBarisSalah)
            {
                sudahPeringatBarisSalah = true;
                MessageBox.Show(
                    $"{barisSalah} baris di barang.txt tidak sesuai format dan tidak ditampilkan.\nContoh: {contohBarisSalah}\n\n" +
                    "Format yang benar: kode|nama|harga_beli|harga_jual|stok|status\n" +
                    "Perbaiki dulu file-nya sebelum menambah atau mengedit barang.",
                    "Peringatan", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        // ==========================================
        // TAMBAH BARANG
        // ==========================================
        // Membaca isian H.Beli, H.Jual, dan Stok. Mengembalikan false (setelah menampilkan peringatan)
        // jika isiannya tidak valid atau pengguna membatalkan karena harga beli > harga jual.
        private bool AmbilInputAngka(out int hargaBeli, out int hargaJual, out int stok)
        {
            hargaBeli = hargaJual = stok = 0;

            if (!int.TryParse(TextHargaBeli.Text.Trim(), out hargaBeli) ||
                !int.TryParse(TextHargaJual.Text.Trim(), out hargaJual) ||
                !int.TryParse(TextStok.Text.Trim(), out stok))
            {
                Peringatan("Input harga beli, harga jual, dan stok harus berupa angka!");
                return false;
            }

            if (hargaBeli < 0 || hargaJual < 0 || stok < 0)
            {
                Peringatan("Harga beli, harga jual, dan stok tidak boleh negatif.");
                return false;
            }

            // Harga beli di atas harga jual berarti barang dijual rugi: minta konfirmasi
            if (hargaBeli > hargaJual)
            {
                DialogResult lanjut = MessageBox.Show(
                    "Harga beli lebih besar dari harga jual, barang ini akan dijual rugi.\nTetap simpan?",
                    "Konfirmasi", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
                if (lanjut != DialogResult.Yes) return false;
            }

            return true;
        }

        private bool SemuaIsianTerisi() =>
            !string.IsNullOrWhiteSpace(TextBarang.Text) &&
            !string.IsNullOrWhiteSpace(TextHargaBeli.Text) &&
            !string.IsNullOrWhiteSpace(TextHargaJual.Text) &&
            !string.IsNullOrWhiteSpace(TextStok.Text);

        private void BersihkanIsian()
        {
            TextBarang.Clear();
            TextHargaBeli.Clear();
            TextHargaJual.Clear();
            TextStok.Clear();
        }

        private void SimpanBarangBaru()
        {
            if (!SemuaIsianTerisi())
            {
                Peringatan("Semua kolom harus diisi!");
                return;
            }

            string nama = Bersihkan(TextBarang.Text).ToLower();
            if (nama == "")
            {
                Peringatan("Nama barang tidak boleh kosong.");
                return;
            }

            List<BarangData> daftar = BacaBarang();

            if (daftar.Any(b => b.Nama.ToLower() == nama))
            {
                Peringatan("Barang sudah ada dalam data.");
                return;
            }

            if (!AmbilInputAngka(out int hargaBeli, out int hargaJual, out int stok))
                return;

            string kodeBaru = BuatKodeBarang(daftar);
            string namaJudul = System.Globalization.CultureInfo.InvariantCulture.TextInfo.ToTitleCase(nama);

            daftar.Add(new BarangData
            {
                Kode = kodeBaru,
                Nama = namaJudul,
                Harga = hargaJual,
                HargaBeli = hargaBeli,
                Stok = stok,
                Status = "aktif"
            });

            try
            {
                SimpanBarang(daftar);
            }
            catch (IOException ex)
            {
                Peringatan("Gagal menyimpan data: " + ex.Message);
                return;
            }

            BersihkanIsian();
            MuatDataDariTxt();

            MessageBox.Show($"Barang {namaJudul} ({kodeBaru}) berhasil disimpan!", "Sukses");
        }

        private void Peringatan(string pesan) =>
            MessageBox.Show(pesan, "Peringatan", MessageBoxButtons.OK, MessageBoxIcon.Warning);

        private void btnSimpanBarang_Click(object sender, EventArgs e)
        {
            ProsesSimpan();
        }

        // Tombol utama: "Tambah Barang" (mode tambah) atau "Simpan Perubahan" (mode edit)
        private void parrotButton2_Click(object sender, EventArgs e)
        {
            ProsesSimpan();
        }

        private void ProsesSimpan()
        {
            if (kodeDiedit == null)
                SimpanBarangBaru();
            else
                SimpanPerubahanBarang();
        }

        // ==========================================
        // EDIT BARANG
        // ==========================================
        private void poisonDataGridView1_CellClick(object? sender, DataGridViewCellEventArgs e)
        {
            // Kolom ke-6 adalah tombol Aktifkan/Nonaktifkan, bukan untuk edit
            if (e.RowIndex < 0 || e.ColumnIndex == 6) return;

            string kode = poisonDataGridView1.Rows[e.RowIndex].Cells[0].Value?.ToString() ?? "";
            BarangData? barang = BacaBarang().FirstOrDefault(b => b.Kode == kode);
            if (barang != null) MasukModeEdit(barang);
        }

        private void MasukModeEdit(BarangData barang)
        {
            kodeDiedit = barang.Kode;

            TextBarang.Text = barang.Nama;
            TextHargaBeli.Text = barang.HargaBeli.ToString();
            TextHargaJual.Text = barang.Harga.ToString();
            TextStok.Text = barang.Stok.ToString();

            label2.Text = "Edit Barang";
            label4.Text = "Kode Barang: " + barang.Kode;
            parrotButton2.ButtonText = "Simpan Perubahan";
            btnBatalEdit.Visible = true;
        }

        private void KeluarModeEdit()
        {
            kodeDiedit = null;

            BersihkanIsian();

            label2.Text = "Tambahkan Barang";
            parrotButton2.ButtonText = "Tambah Barang";
            btnBatalEdit.Visible = false;

            poisonDataGridView1.ClearSelection();
            MuatDataDariTxt();
        }

        private void SimpanPerubahanBarang()
        {
            if (!SemuaIsianTerisi())
            {
                Peringatan("Semua kolom harus diisi!");
                return;
            }

            string nama = Bersihkan(TextBarang.Text).ToLower();
            if (nama == "")
            {
                Peringatan("Nama barang tidak boleh kosong.");
                return;
            }

            List<BarangData> daftar = BacaBarang();
            BarangData? barang = daftar.FirstOrDefault(b => b.Kode == kodeDiedit);
            if (barang == null)
            {
                Peringatan("Barang tidak ditemukan.");
                KeluarModeEdit();
                return;
            }

            // Nama tidak boleh sama dengan barang lain
            if (daftar.Any(b => b.Kode != kodeDiedit && b.Nama.ToLower() == nama))
            {
                Peringatan("Nama barang sudah dipakai barang lain.");
                return;
            }

            if (!AmbilInputAngka(out int hargaBeli, out int hargaJual, out int stok))
                return;

            string namaJudul = System.Globalization.CultureInfo.InvariantCulture.TextInfo.ToTitleCase(nama);
            string kode = barang.Kode;

            barang.Nama = namaJudul;
            barang.Harga = hargaJual;
            barang.HargaBeli = hargaBeli;
            barang.Stok = stok;

            try
            {
                SimpanBarang(daftar);
            }
            catch (IOException ex)
            {
                Peringatan("Gagal menyimpan data: " + ex.Message);
                return;
            }

            KeluarModeEdit();

            MessageBox.Show($"Barang {namaJudul} ({kode}) berhasil diperbarui!", "Sukses");
        }

        private void hopeTextBox3_Click(object sender, EventArgs e)
        {

        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        // ==========================================
        // AKTIFKAN / NONAKTIFKAN
        // ==========================================
        private void poisonDataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            // Kolom tombol Aksi (indeks kolom ke-6): tukar status aktif <-> nonaktif
            if (e.RowIndex >= 0 && e.ColumnIndex == 6)
            {
                string kodeDipilih = poisonDataGridView1.Rows[e.RowIndex].Cells[0].Value?.ToString() ?? "";

                List<BarangData> daftar = BacaBarang();
                BarangData? barang = daftar.FirstOrDefault(b => b.Kode == kodeDipilih);
                if (barang != null)
                {
                    barang.Status = (barang.Status == "aktif") ? "nonaktif" : "aktif";

                    try
                    {
                        SimpanBarang(daftar);
                    }
                    catch (IOException ex)
                    {
                        Peringatan("Gagal menyimpan data: " + ex.Message);
                        return;
                    }
                }

                MuatDataDariTxt();
            }
        }

        // ==========================================
        // PEMANTAU FILE
        // ==========================================
        private void MulaiPemantauFile()
        {
            if (!Directory.Exists(folder) || pemantauFile != null) return;

            // Satu penyimpanan file memicu beberapa kejadian "Changed". Timer ini menunggu sebentar
            // lalu memuat ulang SEKALI, dan hanya jika isi file memang berbeda dari yang sudah tampil.
            timerMuatUlang = new System.Windows.Forms.Timer { Interval = 300 };
            timerMuatUlang.Tick += (s, ev) =>
            {
                timerMuatUlang?.Stop();
                if (TandaFile() != tandaFileTerakhir) MuatDataDariTxt();
            };

            pemantauFile = new FileSystemWatcher(folder, "barang.txt");
            pemantauFile.NotifyFilter = NotifyFilters.LastWrite | NotifyFilters.Size;
            pemantauFile.Changed += (s, ev) =>
            {
                try
                {
                    if (IsHandleCreated && !IsDisposed)
                        BeginInvoke((MethodInvoker)(() =>
                        {
                            timerMuatUlang?.Stop();
                            timerMuatUlang?.Start();
                        }));
                }
                catch (InvalidOperationException) { }   // form sedang ditutup
            };
            pemantauFile.EnableRaisingEvents = true;
        }

        private void HentikanPemantauFile()
        {
            if (pemantauFile != null)
            {
                pemantauFile.EnableRaisingEvents = false;
                pemantauFile.Dispose();
                pemantauFile = null;
            }

            if (timerMuatUlang != null)
            {
                timerMuatUlang.Stop();
                timerMuatUlang.Dispose();
                timerMuatUlang = null;
            }
        }

        // ==========================================
        // NAVIGASI
        // ==========================================
        private void parrotButton1_Click(object sender, EventArgs e)
        {
            DialogResult konfirmasi = MessageBox.Show(
                "Apakah Anda yakin ingin Log out dari akun ini?",
                "Konfirmasi Log Out",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Question
            );

            if (konfirmasi == DialogResult.Yes)
            {
                HentikanPemantauFile();

                FormLogin halamanLogin = new FormLogin();
                halamanLogin.Show();
                this.Close();
            }
        }

        private void parrotButton3_Click(object sender, EventArgs e)
        {
            HentikanPemantauFile();

            FormMenuAdmin halamanMenu = new FormMenuAdmin();
            halamanMenu.Show();
            this.Close();
        }

        private void panel6_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
