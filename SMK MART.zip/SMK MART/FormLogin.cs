﻿namespace SMK_MART
{
    public partial class FormLogin : Form
    {
        // ==========================================
        // DATA & FILE (tanpa DataStore)
        // ==========================================
        private class UserData
        {
            public string Id = "";
            public string Nama = "";
            public string Password = "";
            public string Posisi = "";
            public string Status = "aktif";
            public bool Aktif => Status == "aktif";
        }

        private readonly string folder = Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.UserProfile),
            @"Downloads\Ngoding\Pyhton SMK MART");

        private string FileUsers => Path.Combine(folder, "users.txt");

        public FormLogin()
        {
            InitializeComponent();
        }

        // Baca users.txt (format: id|nama|password|posisi|status; format lama tanpa status dianggap aktif)
        private List<UserData> BacaUsers()
        {
            var hasil = new List<UserData>();
            if (!File.Exists(FileUsers)) return hasil;

            try
            {
                using var fs = new FileStream(FileUsers, FileMode.Open, FileAccess.Read, FileShare.ReadWrite);
                using var sr = new StreamReader(fs);
                string? baris;
                while ((baris = sr.ReadLine()) != null)
                {
                    string[] d = baris.Trim().Split('|');
                    if (d.Length == 4 || d.Length == 5)
                        hasil.Add(new UserData
                        {
                            Id = d[0],
                            Nama = d[1],
                            Password = d[2],
                            Posisi = d[3],
                            Status = d.Length == 5 ? d[4] : "aktif"
                        });
                }
            }
            catch (IOException) { }

            return hasil;
        }

        private UserData? CariUser(string id, string password)
        {
            return BacaUsers().FirstOrDefault(u => u.Id == id.Trim() && u.Password == password.Trim());
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void textBox1_TextChanged_1(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {

        }

        private void panel1_Paint_1(object sender, PaintEventArgs e)
        {

        }

        private void label8_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            // 1. Cek kolom kosong
            if (string.IsNullOrWhiteSpace(hopeTextBox1.Text) || string.IsNullOrWhiteSpace(hopeTextBox2.Text))
            {
                MessageBox.Show("ID user dan Password wajib diisi!", "Peringatan", MessageBoxButtons.OK, MessageBoxIcon.Warning);

                if (string.IsNullOrWhiteSpace(hopeTextBox1.Text))
                    hopeTextBox1.Focus();
                else
                    hopeTextBox2.Focus();

                return;
            }

            // 2. Pastikan users.txt ada
            if (!File.Exists(FileUsers))
            {
                MessageBox.Show("File data user tidak ditemukan:\n" + FileUsers,
                    "Peringatan", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // 3. Cocokkan ID & password dengan users.txt
            UserData? user = CariUser(hopeTextBox1.Text, hopeTextBox2.Text);

            if (user == null)
            {
                MessageBox.Show("ID user atau Password salah!", "Peringatan", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                hopeTextBox2.Clear();
                hopeTextBox2.Focus();
                return;
            }

            if (!user.Aktif)
            {
                MessageBox.Show("Akun ini sudah dinonaktifkan. Hubungi admin.", "Peringatan", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                hopeTextBox2.Clear();
                return;
            }

            MessageBox.Show($"Login berhasil! Selamat datang, {user.Nama} ({user.Posisi}).",
                "Informasi", MessageBoxButtons.OK, MessageBoxIcon.Information);

            FormMenuAdmin halamanAdmin = new FormMenuAdmin();
            halamanAdmin.Show();
            this.Close();
        }

        private void hopeTextBox1_Click(object sender, EventArgs e)
        {

        }

        private void hopeTextBox2_Click(object sender, EventArgs e)
        {

        }

        private void label10_Click(object sender, EventArgs e)
        {

        }

        private void panel2_Paint_1(object sender, PaintEventArgs e)
        {

        }
    }
}
