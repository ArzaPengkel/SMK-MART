﻿namespace SMK_MART
{
    partial class FormTampilkanBarang
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            DataGridViewCellStyle dataGridViewCellStyle4 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle5 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle6 = new DataGridViewCellStyle();
            panel3 = new Panel();
            parrotButton2 = new ReaLTaiizor.Controls.ParrotButton();
            parrotButton3 = new ReaLTaiizor.Controls.ParrotButton();
            parrotButton1 = new ReaLTaiizor.Controls.ParrotButton();
            label3 = new Label();
            tableLayoutPanel1 = new TableLayoutPanel();
            panel2 = new Panel();
            poisonDataGridView2 = new ReaLTaiizor.Controls.PoisonDataGridView();
            Column1 = new DataGridViewTextBoxColumn();
            Column2 = new DataGridViewTextBoxColumn();
            Column3 = new DataGridViewTextBoxColumn();
            Column4 = new DataGridViewTextBoxColumn();
            panel4 = new Panel();
            label1 = new Label();
            cyberTextBox1 = new ReaLTaiizor.Controls.CyberTextBox();
            label2 = new Label();
            parrotButton4 = new ReaLTaiizor.Controls.ParrotButton();
            panel1 = new Panel();
            panel3.SuspendLayout();
            tableLayoutPanel1.SuspendLayout();
            panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)poisonDataGridView2).BeginInit();
            panel1.SuspendLayout();
            SuspendLayout();
            // 
            // panel3
            // 
            panel3.BackColor = Color.Navy;
            panel3.Controls.Add(parrotButton2);
            panel3.Controls.Add(parrotButton3);
            panel3.Controls.Add(parrotButton1);
            panel3.Controls.Add(label3);
            panel3.Dock = DockStyle.Top;
            panel3.Location = new Point(0, 0);
            panel3.Name = "panel3";
            panel3.Size = new Size(800, 60);
            panel3.TabIndex = 3;
            // 
            // parrotButton2
            // 
            parrotButton2.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            parrotButton2.BackgroundColor = Color.Gold;
            parrotButton2.ButtonImage = null;
            parrotButton2.ButtonStyle = ReaLTaiizor.Controls.ParrotButton.Style.MaterialRounded;
            parrotButton2.ButtonText = "Log out";
            parrotButton2.ClickBackColor = Color.FromArgb(195, 195, 195);
            parrotButton2.ClickTextColor = Color.Black;
            parrotButton2.CornerRadius = 10;
            parrotButton2.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            parrotButton2.Horizontal_Alignment = StringAlignment.Center;
            parrotButton2.HoverBackgroundColor = Color.FromArgb(225, 225, 225);
            parrotButton2.HoverTextColor = Color.DodgerBlue;
            parrotButton2.ImagePosition = ReaLTaiizor.Controls.ParrotButton.ImgPosition.Left;
            parrotButton2.Location = new Point(700, 9);
            parrotButton2.Name = "parrotButton2";
            parrotButton2.Size = new Size(88, 37);
            parrotButton2.SmoothingType = System.Drawing.Drawing2D.SmoothingMode.HighQuality;
            parrotButton2.TabIndex = 5;
            parrotButton2.TextColor = Color.Black;
            parrotButton2.TextRenderingType = System.Drawing.Text.TextRenderingHint.ClearTypeGridFit;
            parrotButton2.Vertical_Alignment = StringAlignment.Center;
            parrotButton2.Click += parrotButton2_Click;
            // 
            // parrotButton3
            // 
            parrotButton3.BackgroundColor = Color.Gold;
            parrotButton3.ButtonImage = null;
            parrotButton3.ButtonStyle = ReaLTaiizor.Controls.ParrotButton.Style.MaterialRounded;
            parrotButton3.ButtonText = "Kembali";
            parrotButton3.ClickBackColor = Color.FromArgb(195, 195, 195);
            parrotButton3.ClickTextColor = Color.DodgerBlue;
            parrotButton3.CornerRadius = 5;
            parrotButton3.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            parrotButton3.Horizontal_Alignment = StringAlignment.Center;
            parrotButton3.HoverBackgroundColor = Color.FromArgb(225, 225, 225);
            parrotButton3.HoverTextColor = Color.DodgerBlue;
            parrotButton3.ImagePosition = ReaLTaiizor.Controls.ParrotButton.ImgPosition.Left;
            parrotButton3.Location = new Point(18, 9);
            parrotButton3.Name = "parrotButton3";
            parrotButton3.Size = new Size(95, 37);
            parrotButton3.SmoothingType = System.Drawing.Drawing2D.SmoothingMode.HighQuality;
            parrotButton3.TabIndex = 4;
            parrotButton3.TextColor = Color.Black;
            parrotButton3.TextRenderingType = System.Drawing.Text.TextRenderingHint.ClearTypeGridFit;
            parrotButton3.Vertical_Alignment = StringAlignment.Center;
            parrotButton3.Click += parrotButton3_Click;
            // 
            // parrotButton1
            // 
            parrotButton1.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            parrotButton1.BackgroundColor = Color.Gold;
            parrotButton1.ButtonImage = null;
            parrotButton1.ButtonStyle = ReaLTaiizor.Controls.ParrotButton.Style.MaterialRounded;
            parrotButton1.ButtonText = "Log out";
            parrotButton1.ClickBackColor = Color.FromArgb(195, 195, 195);
            parrotButton1.ClickTextColor = Color.Black;
            parrotButton1.CornerRadius = 10;
            parrotButton1.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            parrotButton1.Horizontal_Alignment = StringAlignment.Center;
            parrotButton1.HoverBackgroundColor = Color.FromArgb(225, 225, 225);
            parrotButton1.HoverTextColor = Color.DodgerBlue;
            parrotButton1.ImagePosition = ReaLTaiizor.Controls.ParrotButton.ImgPosition.Left;
            parrotButton1.Location = new Point(1402, 9);
            parrotButton1.Name = "parrotButton1";
            parrotButton1.Size = new Size(88, 37);
            parrotButton1.SmoothingType = System.Drawing.Drawing2D.SmoothingMode.HighQuality;
            parrotButton1.TabIndex = 3;
            parrotButton1.TextColor = Color.Black;
            parrotButton1.TextRenderingType = System.Drawing.Text.TextRenderingHint.ClearTypeGridFit;
            parrotButton1.Vertical_Alignment = StringAlignment.Center;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI", 20.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label3.ForeColor = Color.Gold;
            label3.Location = new Point(119, 9);
            label3.Name = "label3";
            label3.Size = new Size(161, 37);
            label3.TabIndex = 0;
            label3.Text = "SMK MART";
            label3.Click += label3_Click;
            // 
            // tableLayoutPanel1
            // 
            tableLayoutPanel1.BackColor = Color.Gainsboro;
            tableLayoutPanel1.ColumnCount = 1;
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
            tableLayoutPanel1.Controls.Add(panel2, 0, 1);
            tableLayoutPanel1.Controls.Add(panel1, 0, 0);
            tableLayoutPanel1.Dock = DockStyle.Fill;
            tableLayoutPanel1.Location = new Point(0, 60);
            tableLayoutPanel1.Name = "tableLayoutPanel1";
            tableLayoutPanel1.RowCount = 2;
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 30F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 70F));
            tableLayoutPanel1.Size = new Size(800, 390);
            tableLayoutPanel1.TabIndex = 4;
            // 
            // panel2
            // 
            panel2.BackColor = Color.White;
            panel2.Controls.Add(poisonDataGridView2);
            panel2.Controls.Add(panel4);
            panel2.Controls.Add(label1);
            panel2.Dock = DockStyle.Fill;
            panel2.Location = new Point(15, 122);
            panel2.Margin = new Padding(15, 5, 15, 5);
            panel2.Name = "panel2";
            panel2.Size = new Size(770, 263);
            panel2.TabIndex = 1;
            // 
            // poisonDataGridView2
            // 
            poisonDataGridView2.AllowUserToAddRows = false;
            poisonDataGridView2.AllowUserToDeleteRows = false;
            poisonDataGridView2.AllowUserToResizeRows = false;
            poisonDataGridView2.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            poisonDataGridView2.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            poisonDataGridView2.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.DisplayedCellsExceptHeaders;
            poisonDataGridView2.BackgroundColor = Color.FromArgb(255, 255, 255);
            poisonDataGridView2.BorderStyle = BorderStyle.None;
            poisonDataGridView2.CellBorderStyle = DataGridViewCellBorderStyle.None;
            poisonDataGridView2.ColumnHeadersBorderStyle = DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle4.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle4.BackColor = Color.Gainsboro;
            dataGridViewCellStyle4.Font = new Font("Segoe UI Semibold", 15.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            dataGridViewCellStyle4.ForeColor = Color.Navy;
            dataGridViewCellStyle4.SelectionBackColor = Color.Gainsboro;
            dataGridViewCellStyle4.SelectionForeColor = Color.Navy;
            dataGridViewCellStyle4.WrapMode = DataGridViewTriState.True;
            poisonDataGridView2.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle4;
            poisonDataGridView2.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            poisonDataGridView2.Columns.AddRange(new DataGridViewColumn[] { Column1, Column2, Column3, Column4 });
            dataGridViewCellStyle5.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle5.BackColor = Color.FromArgb(255, 255, 255);
            dataGridViewCellStyle5.Font = new Font("Segoe UI", 15.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            dataGridViewCellStyle5.ForeColor = Color.FromArgb(64, 64, 64);
            dataGridViewCellStyle5.SelectionBackColor = Color.DarkGray;
            dataGridViewCellStyle5.SelectionForeColor = Color.FromArgb(64, 64, 64);
            dataGridViewCellStyle5.WrapMode = DataGridViewTriState.False;
            poisonDataGridView2.DefaultCellStyle = dataGridViewCellStyle5;
            poisonDataGridView2.EnableHeadersVisualStyles = false;
            poisonDataGridView2.Font = new Font("Segoe UI", 11F, FontStyle.Regular, GraphicsUnit.Pixel);
            poisonDataGridView2.GridColor = Color.Silver;
            poisonDataGridView2.Location = new Point(22, 58);
            poisonDataGridView2.Name = "poisonDataGridView2";
            poisonDataGridView2.ReadOnly = true;
            poisonDataGridView2.RowHeadersBorderStyle = DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle6.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle6.BackColor = Color.FromArgb(0, 174, 219);
            dataGridViewCellStyle6.Font = new Font("Segoe UI", 11F, FontStyle.Regular, GraphicsUnit.Pixel);
            dataGridViewCellStyle6.ForeColor = Color.FromArgb(255, 255, 255);
            dataGridViewCellStyle6.SelectionBackColor = Color.FromArgb(0, 198, 247);
            dataGridViewCellStyle6.SelectionForeColor = Color.FromArgb(17, 17, 17);
            dataGridViewCellStyle6.WrapMode = DataGridViewTriState.True;
            poisonDataGridView2.RowHeadersDefaultCellStyle = dataGridViewCellStyle6;
            poisonDataGridView2.RowHeadersVisible = false;
            poisonDataGridView2.RowHeadersWidthSizeMode = DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            poisonDataGridView2.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            poisonDataGridView2.Size = new Size(743, 198);
            poisonDataGridView2.TabIndex = 2;
            poisonDataGridView2.CellContentClick += poisonDataGridView2_CellContentClick;
            // 
            // Column1
            // 
            Column1.FillWeight = 70F;
            Column1.HeaderText = "Kode";
            Column1.Name = "Column1";
            Column1.ReadOnly = true;
            // 
            // Column2
            // 
            Column2.FillWeight = 180F;
            Column2.HeaderText = "Nama";
            Column2.Name = "Column2";
            Column2.ReadOnly = true;
            // 
            // Column3
            // 
            Column3.FillWeight = 90F;
            Column3.HeaderText = "Harga";
            Column3.Name = "Column3";
            Column3.ReadOnly = true;
            // 
            // Column4
            // 
            Column4.FillWeight = 90F;
            Column4.HeaderText = "Stok";
            Column4.Name = "Column4";
            Column4.ReadOnly = true;
            // 
            // panel4
            // 
            panel4.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            panel4.BackColor = Color.FromArgb(5, 150, 105);
            panel4.Location = new Point(3, -2);
            panel4.Name = "panel4";
            panel4.Size = new Size(767, 10);
            panel4.TabIndex = 1;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI Semibold", 24F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.ForeColor = Color.FromArgb(5, 150, 105);
            label1.Location = new Point(0, 11);
            label1.Name = "label1";
            label1.Size = new Size(279, 45);
            label1.TabIndex = 0;
            label1.Text = "Data Barang Aktif";
            // 
            // cyberTextBox1
            // 
            cyberTextBox1.Alpha = 20;
            cyberTextBox1.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            cyberTextBox1.BackColor = Color.Transparent;
            cyberTextBox1.Background_WidthPen = 3F;
            cyberTextBox1.BackgroundPen = true;
            cyberTextBox1.ColorBackground = Color.White;
            cyberTextBox1.ColorBackground_Pen = Color.Silver;
            cyberTextBox1.ColorLighting = Color.Silver;
            cyberTextBox1.ColorPen_1 = Color.White;
            cyberTextBox1.ColorPen_2 = Color.White;
            cyberTextBox1.CyberTextBoxStyle = ReaLTaiizor.Enum.Cyber.StateStyle.Custom;
            cyberTextBox1.Font = new Font("Arial", 9F);
            cyberTextBox1.ForeColor = Color.FromArgb(245, 245, 245);
            cyberTextBox1.Lighting = false;
            cyberTextBox1.LinearGradientPen = false;
            cyberTextBox1.Location = new Point(14, 43);
            cyberTextBox1.Margin = new Padding(5);
            cyberTextBox1.Name = "cyberTextBox1";
            cyberTextBox1.PenWidth = 15;
            cyberTextBox1.RGB = false;
            cyberTextBox1.Rounding = true;
            cyberTextBox1.RoundingInt = 60;
            cyberTextBox1.Size = new Size(201, 37);
            cyberTextBox1.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.HighQuality;
            cyberTextBox1.TabIndex = 3;
            cyberTextBox1.Tag = "Cyber";
            cyberTextBox1.TextAlign = HorizontalAlignment.Left;
            cyberTextBox1.TextButton = "Cyber Text";
            cyberTextBox1.TextRenderingHint = System.Drawing.Text.TextRenderingHint.ClearTypeGridFit;
            cyberTextBox1.Timer_RGB = 300;
            cyberTextBox1.Load += cyberTextBox1_Load;
            // 
            // label2
            // 
            label2.Anchor = AnchorStyles.Bottom | AnchorStyles.Left;
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 14.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label2.ForeColor = Color.FromArgb(64, 64, 64);
            label2.Location = new Point(22, 13);
            label2.Name = "label2";
            label2.Size = new Size(111, 25);
            label2.TabIndex = 0;
            label2.Text = "Cari Barang";
            // 
            // parrotButton4
            // 
            parrotButton4.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            parrotButton4.BackgroundColor = Color.FromArgb(255, 128, 0);
            parrotButton4.ButtonImage = null;
            parrotButton4.ButtonStyle = ReaLTaiizor.Controls.ParrotButton.Style.MaterialRounded;
            parrotButton4.ButtonText = "Terapkan";
            parrotButton4.ClickBackColor = Color.FromArgb(195, 195, 195);
            parrotButton4.ClickTextColor = Color.DodgerBlue;
            parrotButton4.CornerRadius = 5;
            parrotButton4.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            parrotButton4.Horizontal_Alignment = StringAlignment.Center;
            parrotButton4.HoverBackgroundColor = Color.FromArgb(225, 225, 225);
            parrotButton4.HoverTextColor = Color.DodgerBlue;
            parrotButton4.ImagePosition = ReaLTaiizor.Controls.ParrotButton.ImgPosition.Left;
            parrotButton4.Location = new Point(248, 43);
            parrotButton4.Margin = new Padding(5);
            parrotButton4.Name = "parrotButton4";
            parrotButton4.Size = new Size(104, 37);
            parrotButton4.SmoothingType = System.Drawing.Drawing2D.SmoothingMode.HighQuality;
            parrotButton4.TabIndex = 3;
            parrotButton4.TextColor = Color.Black;
            parrotButton4.TextRenderingType = System.Drawing.Text.TextRenderingHint.ClearTypeGridFit;
            parrotButton4.Vertical_Alignment = StringAlignment.Center;
            // 
            // panel1
            // 
            panel1.BackColor = Color.White;
            panel1.Controls.Add(parrotButton4);
            panel1.Controls.Add(cyberTextBox1);
            panel1.Controls.Add(label2);
            panel1.Dock = DockStyle.Fill;
            panel1.Location = new Point(15, 10);
            panel1.Margin = new Padding(15, 10, 15, 10);
            panel1.Name = "panel1";
            panel1.Size = new Size(770, 97);
            panel1.TabIndex = 2;
            // 
            // FormTampilkanBarang
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(tableLayoutPanel1);
            Controls.Add(panel3);
            Name = "FormTampilkanBarang";
            Text = "FormTampilkanBarang";
            WindowState = FormWindowState.Maximized;
            panel3.ResumeLayout(false);
            panel3.PerformLayout();
            tableLayoutPanel1.ResumeLayout(false);
            panel2.ResumeLayout(false);
            panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)poisonDataGridView2).EndInit();
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private Panel panel3;
        private ReaLTaiizor.Controls.ParrotButton parrotButton3;
        private ReaLTaiizor.Controls.ParrotButton parrotButton1;
        private Label label3;
        private ReaLTaiizor.Controls.ParrotButton parrotButton2;
        private TableLayoutPanel tableLayoutPanel1;
        private Panel panel2;
        private Label label1;
        private Panel panel4;
        private ReaLTaiizor.Controls.PoisonDataGridView poisonDataGridView2;
        private DataGridViewTextBoxColumn Column1;
        private DataGridViewTextBoxColumn Column2;
        private DataGridViewTextBoxColumn Column3;
        private DataGridViewTextBoxColumn Column4;
        private Panel panel1;
        private ReaLTaiizor.Controls.ParrotButton parrotButton4;
        private ReaLTaiizor.Controls.CyberTextBox cyberTextBox1;
        private Label label2;
    }
}