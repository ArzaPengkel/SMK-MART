﻿namespace SMK_MART
{
    public partial class FormStok : Form
    {
        // ==========================================
        // DATA & FILE (tanpa DataStore)
        // ==========================================
        private class BarangData
        {
            public string Kode = "";
            public string Nama = "";
            public int Harga;
            public int HargaBeli;
            public int Stok;
            public string Status = "aktif";
            public bool Aktif => Status == "aktif";
        }

        private readonly string folder = Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.UserProfile),
            @"Downloads\Ngoding\Pyhton SMK MART");

        private string FileBarang => Path.Combine(folder, "barang.txt");

        // Baris barang.txt yang formatnya salah pada pembacaan terakhir (dicatat agar tidak hilang saat menyimpan)
        private int barisSalah = 0;
        private string contohBarisSalah = "";
        private string FileBarangMasuk => Path.Combine(folder, "barang_masuk.txt");
        private string FileBarangKeluar => Path.Combine(folder, "barang_keluar.txt");
        private string FileStokMinimum => Path.Combine(folder, "stok_minimum.txt");

        private int stokMinimum = 5;

        // Menunda penyimpanan batas stok sampai pengguna berhenti mengetik
        private readonly System.Windows.Forms.Timer timerBatas = new() { Interval = 600 };

        public FormStok()
        {
            InitializeComponent();

            cyberComboBox1.Items.AddRange(new object[] { "Barang Masuk", "Barang Keluar" });
            cyberComboBox1.SelectedIndex = 0;

            parrotButton1.Click += LogOut_Click;
            parrotButton2.Click += LogOut_Click;
            parrotButton3.Click += Kembali_Click;
            hopeButton1.Click += hopeButton1_Click;

            hopeTextBox3.TextChanged += hopeTextBox3_TextChanged;
            hopeTextBox3.Leave += hopeTextBox3_Leave;

            Load += FormStok_Load;

            timerBatas.Tick += (s, e) =>
            {
                timerBatas.Stop();
                TerapkanBatasMinimum();
            };
            FormClosed += (s, e) => timerBatas.Dispose();

            AktifkanDoubleBuffer(poisonDataGridView1);
        }

        // Baca barang.txt (format: kode|nama|harga_beli|harga_jual|stok|status)
        private List<BarangData> BacaBarang()
        {
            var hasil = new List<BarangData>();
            barisSalah = 0;
            contohBarisSalah = "";
            if (!File.Exists(FileBarang)) return hasil;

            try
            {
                // FileShare.ReadWrite supaya tetap bisa dibaca saat Python sedang menulis
                using var fs = new FileStream(FileBarang, FileMode.Open, FileAccess.Read, FileShare.ReadWrite);
                using var sr = new StreamReader(fs);
                string? baris;
                while ((baris = sr.ReadLine()) != null)
                {
                    string teks = baris.Trim();
                    if (teks == "") continue;

                    string[] d = teks.Split('|');
                    if (TryBacaBarang(d, out string kode, out string nama, out int hargaBeli, out int harga, out int stok, out string status))
                    {
                        hasil.Add(new BarangData { Kode = kode, Nama = nama, Harga = harga, HargaBeli = hargaBeli, Stok = stok, Status = status });
                    }
                    else
                    {
                        barisSalah++;
                        if (contohBarisSalah == "") contohBarisSalah = teks;
                    }
                }
            }
            catch (IOException) { }

            return hasil;
        }

        // Format barang.txt (hanya satu format): kode|nama|harga_beli|harga_jual|stok|status
        private static bool TryBacaBarang(string[] d, out string kode, out string nama,
            out int hargaBeli, out int harga, out int stok, out string status)
        {
            kode = nama = status = "";
            hargaBeli = harga = stok = 0;

            if (d.Length != 6) return false;

            kode = d[0];
            nama = d[1];
            status = d[5];

            return int.TryParse(d[2], out hargaBeli)
                && int.TryParse(d[3], out harga)
                && int.TryParse(d[4], out stok)
                && AdalahStatus(status);
        }

        private static bool AdalahStatus(string teks) => teks == "aktif" || teks == "nonaktif";

        private void SimpanBarang(List<BarangData> daftar)
        {
            // Jangan menimpa file jika ada baris yang formatnya salah: baris itu akan hilang
            if (barisSalah > 0)
                throw new IOException($"barang.txt punya {barisSalah} baris dengan format salah, contoh: {contohBarisSalah}\n" +
                    "Format yang benar: kode|nama|harga_beli|harga_jual|stok|status\n" +
                    "Perbaiki dulu file-nya agar data tidak hilang.");

            Directory.CreateDirectory(folder);
            File.WriteAllLines(FileBarang,
                daftar.Select(b => $"{b.Kode}|{b.Nama}|{b.HargaBeli}|{b.Harga}|{b.Stok}|{b.Status}"));
        }

        // Menambah SATU baris di akhir file (tidak membaca dan menulis ulang seluruh file),
        // jadi tetap cepat walaupun catatan sudah banyak.
        private void TambahBaris(string path, string baris)
        {
            Directory.CreateDirectory(folder);

            // Pastikan baris baru tidak menempel di baris terakhir jika file tidak berakhir dengan newline
            bool perluBarisBaru = false;
            if (File.Exists(path))
            {
                using var fs = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.ReadWrite);
                if (fs.Length > 0)
                {
                    fs.Seek(-1, SeekOrigin.End);
                    perluBarisBaru = fs.ReadByte() != '\n';
                }
            }

            using var sw = new StreamWriter(path, append: true);
            if (perluBarisBaru) sw.WriteLine();
            sw.WriteLine(baris);
        }

        // stok_minimum.txt
        private void BacaStokMinimum()
        {
            stokMinimum = 0;
            try
            {
                if (File.Exists(FileStokMinimum) &&
                    int.TryParse(File.ReadAllText(FileStokMinimum).Trim(), out int batas) && batas >= 0)
                    stokMinimum = batas;
            }
            catch (IOException) { }
        }

        private void SimpanStokMinimum(int batas)
        {
            if (batas < 0) return;
            stokMinimum = batas;
            Directory.CreateDirectory(folder);
            File.WriteAllText(FileStokMinimum, batas.ToString());
        }

        // Kode harus persis (B001); nama barang boleh huruf besar/kecil
        private static BarangData? CariBarang(List<BarangData> daftar, string kodeAtauNama)
        {
            string kunci = kodeAtauNama.Trim();
            return daftar.FirstOrDefault(b => b.Kode == kunci)
                ?? daftar.FirstOrDefault(b => b.Nama.Equals(kunci, StringComparison.OrdinalIgnoreCase));
        }

        private static string Bersihkan(string teks) => teks.Replace("|", "/").Trim();

        // ==========================================
        // TAMPILAN
        // ==========================================
        private void FormStok_Load(object? sender, EventArgs e)
        {
            BacaStokMinimum();
            hopeTextBox3.Text = stokMinimum.ToString();
            MuatPeringatan();
        }

        // Peringatan stok minimum: barang aktif dengan stok <= batas
        private void MuatPeringatan()
        {
            var isi = new List<DataGridViewRow>();
            foreach (BarangData b in BacaBarang().Where(b => b.Aktif && b.Stok <= stokMinimum))
                isi.Add(BuatBaris(poisonDataGridView1, b.Kode, b.Nama, b.Stok.ToString()));

            IsiTabel(poisonDataGridView1, isi);
        }

        // ==========================================
        // BANTUAN TABEL (supaya cepat)
        // ==========================================
        // Menggambar tabel lewat buffer ganda: scroll dan muat ulang lebih halus
        private static void AktifkanDoubleBuffer(DataGridView tabel)
        {
            typeof(DataGridView).GetProperty("DoubleBuffered",
                System.Reflection.BindingFlags.Instance | System.Reflection.BindingFlags.NonPublic)
                ?.SetValue(tabel, true);
        }

        private static DataGridViewRow BuatBaris(DataGridView tabel, params object[] nilai)
        {
            var baris = new DataGridViewRow();
            baris.CreateCells(tabel, nilai);
            return baris;
        }

        // Mengisi tabel sekaligus: jauh lebih cepat daripada Rows.Add satu per satu
        private static void IsiTabel(DataGridView tabel, List<DataGridViewRow> isi)
        {
            tabel.SuspendLayout();
            tabel.Rows.Clear();
            tabel.Rows.AddRange(isi.ToArray());
            tabel.ResumeLayout();
        }

        // Batas disimpan setelah berhenti mengetik sebentar (bukan di setiap ketikan)
        private void hopeTextBox3_TextChanged(object? sender, EventArgs e)
        {
            timerBatas.Stop();
            timerBatas.Start();
        }

        private void TerapkanBatasMinimum()
        {
            if (!int.TryParse(hopeTextBox3.Text.Trim(), out int batas) || batas < 0) return;
            if (batas == stokMinimum) return;

            try
            {
                SimpanStokMinimum(batas);
            }
            catch (IOException ex)
            {
                Peringatan("Gagal menyimpan batas stok: " + ex.Message);
                return;
            }

            MuatPeringatan();
        }

        private void hopeTextBox3_Leave(object? sender, EventArgs e)
        {
            timerBatas.Stop();

            // Jika isian tidak valid, kembalikan ke batas yang tersimpan; jika valid, terapkan sekarang
            if (!int.TryParse(hopeTextBox3.Text.Trim(), out int batas) || batas < 0)
                hopeTextBox3.Text = stokMinimum.ToString();
            else
                TerapkanBatasMinimum();
        }

        private void Peringatan(string pesan) =>
            MessageBox.Show(pesan, "Peringatan", MessageBoxButtons.OK, MessageBoxIcon.Warning);

        // ==========================================
        // CATAT BARANG MASUK / KELUAR
        // ==========================================
        // Mengembalikan pesan error, atau null jika berhasil
        private string? CatatBarangMasuk(string kode, int jumlah, out int stokSekarang)
        {
            stokSekarang = 0;
            List<BarangData> daftar = BacaBarang();
            BarangData? barang = CariBarang(daftar, kode);

            if (barang == null) return "Barang tidak ditemukan.";
            if (!barang.Aktif) return "Barang berstatus nonaktif. Aktifkan terlebih dahulu.";
            if (jumlah <= 0) return "Jumlah tidak valid.";

            barang.Stok += jumlah;

            SimpanBarang(daftar);
            TambahBaris(FileBarangMasuk, $"{barang.Nama}|{barang.Kode}|{jumlah}");

            stokSekarang = barang.Stok;
            return null;
        }

        private string? CatatBarangKeluar(string kode, int jumlah, string alasan, out int stokSekarang)
        {
            stokSekarang = 0;
            List<BarangData> daftar = BacaBarang();
            BarangData? barang = CariBarang(daftar, kode);

            if (barang == null) return "Barang tidak ditemukan.";
            if (!barang.Aktif) return "Barang berstatus nonaktif. Aktifkan terlebih dahulu.";
            if (jumlah <= 0) return "Jumlah tidak valid.";
            if (jumlah > barang.Stok) return "Stok tidak mencukupi.";

            barang.Stok -= jumlah;

            SimpanBarang(daftar);
            TambahBaris(FileBarangKeluar, $"{barang.Nama}|{barang.Kode}|{jumlah}|{Bersihkan(alasan)}");

            stokSekarang = barang.Stok;
            return null;
        }

        // Tombol "Catat"
        private void hopeButton1_Click(object? sender, EventArgs e)
        {
            if (cyberComboBox1.SelectedIndex < 0 ||
                string.IsNullOrWhiteSpace(hopeTextBox2.Text) ||
                string.IsNullOrWhiteSpace(hopeTextBox1.Text))
            {
                Peringatan("Semua kolom harus diisi!");
                return;
            }

            if (!int.TryParse(hopeTextBox1.Text.Trim(), out int jumlah))
            {
                Peringatan("Jumlah harus berupa angka.");
                return;
            }

            string kode = hopeTextBox2.Text.Trim();
            bool masuk = cyberComboBox1.SelectedIndex == 0;

            string? error;
            int stokSekarang;
            try
            {
                // Kolom alasan tidak ada di form, jadi alasan barang keluar dikosongkan
                error = masuk
                    ? CatatBarangMasuk(kode, jumlah, out stokSekarang)
                    : CatatBarangKeluar(kode, jumlah, "", out stokSekarang);
            }
            catch (IOException ex)
            {
                Peringatan("Gagal menyimpan data: " + ex.Message);
                return;
            }

            if (error != null)
            {
                Peringatan(error);
                return;
            }

            MessageBox.Show(
                (masuk ? "Barang masuk" : "Barang keluar") + $" berhasil dicatat.\nStok sekarang: {stokSekarang}",
                "Sukses", MessageBoxButtons.OK, MessageBoxIcon.Information);

            hopeTextBox1.Clear();
            hopeTextBox2.Clear();
            MuatPeringatan();
        }

        // ==========================================
        // NAVIGASI
        // ==========================================
        private void Kembali_Click(object? sender, EventArgs e)
        {
            FormMenuAdmin halamanMenu = new FormMenuAdmin();
            halamanMenu.Show();
            this.Close();
        }

        private void LogOut_Click(object? sender, EventArgs e)
        {
            DialogResult konfirmasi = MessageBox.Show(
                "Apakah Anda yakin ingin Log out dari akun ini?",
                "Konfirmasi Log Out",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Question
            );

            if (konfirmasi == DialogResult.Yes)
            {
                FormLogin halamanLogin = new FormLogin();
                halamanLogin.Show();
                this.Close();
            }
        }
    }
}
